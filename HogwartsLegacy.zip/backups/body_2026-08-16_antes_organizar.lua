--[[
	body.lua — Corpo VR (IK) para Hogwarts Legacy

	Corpo em primeira pessoa a partir do esqueleto do personagem, via libs/ik.lua:
	o IK copia as malhas num PoseableMesh preso ao pawn, dois solvers de Two Bone
	giram os braços atrás dos controles e as poses de dedo do perfil
	(helpers/hand_animations.lua) são reaproveitadas nas mãos do corpo.

	Ajustes: painel "Corpo VR" e painel "IK Dev Config" (data/ik_parameters.json).
	O PORQUÊ de cada decisão e a lista de armadilhas estão no LEIAME_CORPO_VR.md;
	aqui os comentários só dizem o que o código faz.
]]--

local uevrUtils      = require("libs/uevr_utils")
local configui       = require("libs/configui")
local animation      = require("libs/animation")
local controllers    = require("libs/controllers")
local hands          = require("libs/hands")
local ik             = require("libs/ik")
local bodyYaw        = require("libs/body_yaw")
local handAnimations = require("helpers/hand_animations")
local mounts         = require("helpers/mounts")
require("libs/enums/unreal")

-- EVisibilityBasedAnimTickOption::AlwaysTickPoseAndRefreshBones (falta no enums da lib)
local ALWAYS_TICK_POSE_AND_REFRESH_BONES = 0

-- Painel "IK Dev Config" (ajuste fino) na UI do UEVR.
local SHOW_DEV_UI = true

-- Palpite inicial; se não existir na malha, a detecção automática corrige.
local HEAD_BONE = "Head"

-- Filhos de Pawn.Mesh que nunca entram no corpo (nome parcial, sem caixa).
local EXCLUDED_MESHES = { "preview", "shadowproxy" }

local currentRig    = nil   -- instância do rig de IK ativa
local bodyMeshes    = {}    -- cópias PoseableMesh criadas pelo IK
local meshTags      = {}    -- tags de animação encontradas na última criação
local headBone      = HEAD_BONE -- nome real do osso da cabeça nesta malha

local function log(text, level)
	uevrUtils.print("[body] " .. text, level or LogLevel.Info)
end

-- Sem isto NADA de Lua chega no log.txt: o uevr_utils nasce com logToFile = false.
-- Não enche o arquivo — o filtro de nível continua valendo, e o padrão é Error.
uevrUtils.setLogToFile(true)

-- Marcos que PRECISAM aparecer no log.txt. O filtro do perfil é Error, então
-- mensagem Info não chega no arquivo: estes vão como Error de propósito.
local function logMilestone(text)
	uevrUtils.print("[body] " .. text, LogLevel.Error)
end

local function isEnabled()
	return configui.getValue("body_enabled") == true
end

--------------------------------------------------------------------------
-- Seleção das malhas que formam o corpo
--------------------------------------------------------------------------

local function shortName(component)
	local fullName = component:get_full_name()
	return fullName:match("([^%.]+)$") or fullName
end

local function isExcluded(name)
	local lowerName = string.lower(name)
	for _, excluded in ipairs(EXCLUDED_MESHES) do
		if string.find(lowerName, excluded, 1, true) ~= nil then
			return true
		end
	end
	return false
end

local function isSkeletalMesh(component)
	if uevrUtils.getValid(component) == nil then return false end
	local class = uevrUtils.get_class("Class /Script/Engine.SkeletalMeshComponent")
	if class ~= nil and component.is_a ~= nil and not component:is_a(class) then
		return false
	end
	-- só interessa se realmente tem uma malha carregada (UE4 x UE5)
	return uevrUtils.getValid(component, {"SkeletalMesh"}) ~= nil
		or uevrUtils.getValid(component, {"SkeletalMeshAsset"}) ~= nil
end

--------------------------------------------------------------------------
-- A malha viva que serve de origem para o corpo.
--
-- Montado numa criatura o pawn é a CRIATURA: a malha tem de sair do
-- RiderCharacter, senão o corpo VR vira o bicho. A pé é no-op.
--------------------------------------------------------------------------
local function getPlayerBodyMesh(shouldLog)
	local playerPawn = uevrUtils.getValid(pawn)
	local baseMesh = playerPawn ~= nil and uevrUtils.getValid(playerPawn, {"Mesh"}) or nil

	if playerPawn ~= nil and not mounts.isWalking() then
		local rider = uevrUtils.getValid(mounts.getMountPawn(playerPawn))
		local riderMesh = rider ~= nil and uevrUtils.getValid(rider, {"Mesh"}) or nil
		if riderMesh ~= nil and riderMesh ~= baseMesh then
			baseMesh = riderMesh
			if shouldLog then
				logMilestone("Montado: corpo criado a partir da malha do personagem, nao da criatura")
			end
		end
	end

	return baseMesh
end

-- Chamada pelo ik.lua com "animation_mesh" = Custom. Tem de ser a mesma malha de
-- origem do corpo: o CopyPoseFromSkeletalComponent exige esqueletos iguais.
function getCustomAnimationIKComponent(rigID)
	return getPlayerBodyMesh(false)
end

-- Chamada pelo ik.lua com "mesh" = Custom: as malhas que formam o corpo. A
-- primeira precisa ser a do esqueleto completo (Pawn.Mesh), que os solvers usam
-- como referência.
function getCustomIKComponent(rigID)
	meshTags = {}

	local baseMesh = getPlayerBodyMesh(true)

	if baseMesh == nil then
		log("Pawn.Mesh indisponível, corpo não foi criado", LogLevel.Warning)
		return {}
	end

	local templates = {}
	table.insert(templates, { descriptor = "Pawn.Mesh", instance = baseMesh, animation = "Body" })
	meshTags["Body"] = true

	-- As malhas filhas (roupa, luvas, braços) entram SEMPRE. Quem escolhe a malha
	-- de origem é o parâmetro "mesh" do IK Dev Config (armadilha 8).
	do
		local children = baseMesh.AttachChildren
		if children ~= nil then
			for _, child in ipairs(children) do
				if isSkeletalMesh(child) then
					local name = shortName(child)
					if isExcluded(name) then
						log("Malha ignorada: " .. name)
					else
						local tag = nil
						if string.find(name, "Arm") ~= nil then
							tag = "Arms"
						elseif string.find(name, "Glove") ~= nil then
							tag = "Gloves"
						end
						if tag ~= nil and meshTags[tag] == true then
							tag = nil -- só a primeira malha de cada tipo recebe as animações de dedo
						end
						if tag ~= nil then meshTags[tag] = true end

						table.insert(templates, {
							descriptor = "Pawn.Mesh(" .. name .. ")",
							instance = child,
							animation = tag,
							optional = true,
						})
						log("Malha do corpo: " .. name .. (tag ~= nil and (" [" .. tag .. "]") or ""))
					end
				end
			end
		end
	end

	log("Total de malhas no corpo: " .. #templates)
	return templates
end

--------------------------------------------------------------------------
-- Animação dos dedos reaproveitando as poses do perfil
--------------------------------------------------------------------------

-- Os IDs do hands_animation são "<mão>_<alvo>": "body", "hand", "glove".
local function buildAnimationTable()
	local profile = {}
	local targets = { Body = "body", Arms = "hand", Gloves = "glove" }
	for tag, target in pairs(targets) do
		if meshTags[tag] == true then
			profile[tag] = {
				Left  = { AnimationID = "left_"  .. target },
				Right = { AnimationID = "right_" .. target },
			}
		end
	end
	return { animations = { Shared = handAnimations }, profiles = { Main = profile } }
end

--------------------------------------------------------------------------
-- Detecção automática dos ossos
--
-- Nome de osso que não existe na malha faz o ik.lua descartar o solver EM
-- SILÊNCIO. Conferimos os nomes contra a malha real; nome que já funciona fica.
--------------------------------------------------------------------------

-- palavras que descartam um osso como sendo a mão (dedos e ossos auxiliares)
local NOT_A_HAND = {
	"index", "middle", "ring", "pinky", "thumb", "finger", "twist", "roll",
	"ik", "attach", "socket", "weapon", "prop", "end", "tip", "ctrl", "helper",
}

local NOT_A_HEAD = { "top", "end", "attach", "socket", "ik", "ctrl", "helper", "hat", "wear" }

-- nomes exatos mais comuns, em ordem de preferência (minúsculas)
local HAND_NAMES = {
	[Handed.Right] = { "righthand", "hand_r", "r_hand", "hand_right", "bip01 r hand", "bip01_r_hand", "mixamorig:righthand" },
	[Handed.Left]  = { "lefthand",  "hand_l", "l_hand", "hand_left",  "bip01 l hand", "bip01_l_hand", "mixamorig:lefthand"  },
}

local HEAD_NAMES = { "head", "bip01 head", "bip01_head", "mixamorig:head", "b_head", "head_01" }

local function toBoneSet(names)
	local set = {}
	for _, name in ipairs(names) do
		set[string.lower(name)] = name
	end
	return set
end

local function containsAny(lowerName, words)
	for _, word in ipairs(words) do
		if string.find(lowerName, word, 1, true) ~= nil then return true end
	end
	return false
end

-- separadores usados pelas convenções de nome: hand_r, hand.r, hand-r, "Bip01 R Hand"
local SEPARATOR = "[_%.%-%s]"

local function hasSideMarker(lowerName, side)
	local word, letter = "left", "l"
	if side == Handed.Right then word, letter = "right", "r" end
	return string.find(lowerName, word, 1, true) ~= nil
		or string.match(lowerName, SEPARATOR .. letter .. "$") ~= nil
		or string.match(lowerName, SEPARATOR .. letter .. SEPARATOR) ~= nil
end

-- Osso da mão: nomes conhecidos, depois qualquer "hand"/"wrist" do lado certo.
-- Entre candidatos vence o nome mais curto, que é a raiz da mão.
local function detectHandBone(names, set, side)
	for _, candidate in ipairs(HAND_NAMES[side]) do
		if set[candidate] ~= nil then return set[candidate] end
	end

	for _, keyword in ipairs({ "hand", "wrist" }) do
		local best = nil
		for _, name in ipairs(names) do
			local lower = string.lower(name)
			if string.find(lower, keyword, 1, true) ~= nil
				and not containsAny(lower, NOT_A_HAND)
				and hasSideMarker(lower, side)
				and (best == nil or #name < #best)
			then
				best = name
			end
		end
		if best ~= nil then return best end
	end

	return nil
end

local function detectHeadBone(names, set)
	for _, candidate in ipairs(HEAD_NAMES) do
		if set[candidate] ~= nil then return set[candidate] end
	end
	local best = nil
	for _, name in ipairs(names) do
		local lower = string.lower(name)
		if string.find(lower, "head", 1, true) ~= nil
			and not containsAny(lower, NOT_A_HEAD)
			and (best == nil or #name < #best)
		then
			best = name
		end
	end
	return best
end

-- Cadeia do osso até a raiz: {osso, pai, avô, ...}. Versão com limite — a
-- Cadeia do osso até a raiz: {osso, pai, avô, ...}. Com teto, porque o
-- uevrUtils.getAncestorBones roda um while sem limite.
local function getBoneChain(mesh, boneName, maxDepth)
	local chain = { boneName }
	local current = boneName
	for _ = 1, (maxDepth or 6) do
		local parent = mesh:GetParentBone(current)
		if parent == nil then break end
		parent = parent:to_string()
		if parent == "" or parent == "None" or parent == current then break end
		table.insert(chain, parent)
		current = parent
	end
	return chain
end

-- Corrige os ossos de um solver; true se mudou algo. Braço e antebraço saem da
-- hierarquia da malha, só a mão é adivinhada.
local function fixSolverBones(rig, mesh, names, set, solverId, solverParams)
	local side = Handed.Right
	if solverParams["end_control_type"] == 0 then side = Handed.Left end

	local endBone = solverParams["end_bone"] or ""
	if endBone ~= "" and set[string.lower(endBone)] ~= nil then
		return false -- o nome configurado existe na malha, não mexe
	end

	local detected = detectHandBone(names, set, side)
	-- se um lado foi achado e o outro não, espelha o nome
	if detected == nil then
		local other = detectHandBone(names, set, side == Handed.Right and Handed.Left or Handed.Right)
		if other ~= nil then
			detected = uevrUtils.findOppositeBone(other, side == Handed.Right, names)
		end
	end

	if detected == nil then
		log("Não achei o osso da mão " .. (side == Handed.Right and "direita" or "esquerda")
			.. " para o solver '" .. tostring(solverId) .. "'. Use 'Listar ossos no log' e "
			.. "escolha na aba IK Dev Config.", LogLevel.Warning)
		return false
	end

	local chain = getBoneChain(mesh, detected, 5)
	if #chain < 3 then
		log("Osso '" .. detected .. "' não tem antebraço e braço acima dele, ignorado", LogLevel.Warning)
		return false
	end

	log("Solver '" .. tostring(solverId) .. "': usando " .. chain[3] .. " -> " .. chain[2] .. " -> " .. chain[1])
	rig:setConfigParameter({ "solvers", solverId, "end_bone" }, chain[1], true)
	rig:setConfigParameter({ "solvers", solverId, "joint_bone" }, chain[2], true)
	rig:setConfigParameter({ "solvers", solverId, "start_bone" }, chain[3], true)

	-- ombro e espinha (usados só pelo modo "Somente braços") saem da mesma cadeia
	local shoulderKey = side == Handed.Right and "right_shoulder_bone_name" or "left_shoulder_bone_name"
	if chain[4] ~= nil then
		rig:setConfigParameter(shoulderKey, chain[4], true)
		if chain[5] ~= nil then
			rig:setConfigParameter("spine_bone_name", chain[5], true)
		end
	end

	return true
end

-- Devolve true se algum osso foi corrigido (nesse caso o corpo é reconstruído).
local function detectBones(rig, force)
	local mesh = bodyMeshes[1]
	if uevrUtils.getValid(mesh) == nil then return false end

	local names = uevrUtils.getBoneNames(mesh)
	if names == nil or #names == 0 then
		log("A malha do corpo não devolveu nenhum osso", LogLevel.Warning)
		return false
	end
	local set = toBoneSet(names)

	-- cabeça (não faz parte do rig, aplica na hora)
	if set[string.lower(headBone)] == nil or force then
		local detectedHead = detectHeadBone(names, set)
		if detectedHead ~= nil then
			if detectedHead ~= headBone then
				log("Osso da cabeça: " .. detectedHead)
			end
			headBone = detectedHead
		else
			log("Não achei o osso da cabeça; 'Esconder a cabeça' não vai funcionar", LogLevel.Warning)
		end
	end

	-- braços: os solvers saem do arquivo, não do rig — com o nome errado o ik.lua
	-- descarta o solver e ele nem aparece em rig.activeSolvers
	if json == nil then return false end
	local params = json.load_file("ik_parameters.json")
	local rigParams = params ~= nil and params[rig.rigId or ""] or nil
	local solvers = rigParams ~= nil and rigParams.solvers or nil
	if solvers == nil then return false end

	local changed = false
	for solverId, solverParams in pairs(solvers) do
		if force then solverParams["end_bone"] = "" end
		if fixSolverBones(rig, mesh, names, set, solverId, solverParams) then
			changed = true
		end
	end
	return changed
end

--------------------------------------------------------------------------
-- Visibilidade
--------------------------------------------------------------------------

-- Roda por frame com a animação ligada, então usa o struct reutilizável.
--
-- SEMPRE ATIVO: em primeira pessoa a câmera fica DENTRO da cabeça. O osso é
-- encolhido (escala 0,001), não movido — a posição continua valendo, e é dela
-- que sai a câmera atracada à cabeça.
local function applyHeadVisibility()
	local scale = uevrUtils.vector(0.001, 0.001, 0.001, true)
	for _, mesh in ipairs(bodyMeshes) do
		if uevrUtils.getValid(mesh) ~= nil and mesh.SetBoneScaleByName ~= nil then
			mesh:SetBoneScaleByName(uevrUtils.fname_from_string(headBone), scale, EBoneSpaces.ComponentSpace)
		end
	end
end

local function applyShadowSetting()
	local castShadow = configui.getValue("body_shadow") == true
	for _, mesh in ipairs(bodyMeshes) do
		if uevrUtils.getValid(mesh) ~= nil then
			mesh.bCastDynamicShadow = castShadow
			-- BoundsScale grande evita o corpo ser descartado pelo frustum quando a
			-- origem da malha (nos pés) sai de vista. O ik.lua já põe 16 na criação.
			mesh.BoundsScale = 16.0
			-- bRenderInDepthPass não é forçado: em Native Stereo, candidato a artefato.
		end
	end
end

-- O corpo some em terceira pessoa e em cinemática, quando o jogo mostra o
-- personagem original. NA MONTARIA NÃO SOME: o perfil já esconde o jogador em
-- primeira pessoa, e todo o trabalho da montaria existe para o corpo aparecer lá.
local function shouldHideBody()
	if configui.getValue("isFP") == false then return true end
	local playerPawn = uevrUtils.getValid(pawn)
	if playerPawn == nil then return true end
	if playerPawn.InCinematic == true then return true end
	return false
end

-- O ik.lua consulta este callback a cada 200 ms. pawn.InCinematic oscila, e uma
-- resposta que oscila vira pisca-pisca a 5 Hz: só escondemos depois de duas
-- leituras seguidas pedindo isso. Voltar a aparecer continua imediato.
local hideStreak = 0
local bodyHidden = false

-- Estado JÁ FILTRADO: é este que o resto do arquivo usa, nunca o shouldHideBody()
-- cru (chamá-lo por frame dava "flicada" no corpo e salto de câmera).
local function isBodyHidden()
	return bodyHidden
end

uevrUtils.registerUEVRCallback("is_hands_hidden", function()
	if not isEnabled() then return nil end
	if shouldHideBody() then
		hideStreak = hideStreak + 1
	else
		hideStreak = 0
	end
	bodyHidden = hideStreak >= 2
	return bodyHidden, 20
end)

--------------------------------------------------------------------------
-- 1. Animação das pernas (receita do perfil do Silent Hill f, restrita)
--
-- O ik.lua cria o corpo em pose de referência e só mexe nos braços. Copiamos a
-- pose apenas da subárvore das pernas (coxa para baixo), reancorada no quadril
-- da cópia — a pose inteira levaria tronco, cabeça e dedos, que são do VR.
-- As malhas de origem precisam continuar animando escondidas, daí o
-- VisibilityBasedAnimTickOption. Ver LEIAME, "Pernas animadas".
--------------------------------------------------------------------------

local RTS_COMPONENT = 2 -- ERelativeTransformSpace::RTS_Component

local FOOT_NAMES = {
	[Handed.Right] = { "rightfoot", "foot_r", "r_foot", "bip01 r foot", "mixamorig:rightfoot" },
	[Handed.Left]  = { "leftfoot",  "foot_l", "l_foot", "bip01 l foot", "mixamorig:leftfoot"  },
}
local NOT_A_FOOT = { "toe", "ball", "ik", "attach", "socket", "twist", "roll", "ctrl", "helper", "end", "tip" }

local legBones = nil       -- { {name=..., fname=...}, ... } coxa para baixo
local legAnchorFName = nil -- quadril: a âncora das pernas

-- Quadril na POSE DE REFERÊNCIA, capturado quando o corpo nasce. A conta parte
-- sempre dele, nunca do valor lido de volta do osso (armadilha 4).
local referenceHip = nil
-- Altura do quadril na malha de ORIGEM com o personagem em pé, capturada no
-- primeiro frame. É contra esta que o agachamento é medido: a pose de referência
-- é bind pose (perna reta) e não coincide com o "em pé" animado.
local standingSourceHipZ = nil
-- O quanto o quadril está abaixado agora (0 = em pé), suavizado.
local hipDrop = 0

-- O quanto o quadril escrito neste quadro saiu da pose de referência. A cintura
-- é escrita em espaço de componente (posição ABSOLUTA no esqueleto), então soma
-- isto para acompanhar o quadril como filha dele.
local hipShift = { X = 0, Y = 0, Z = 0 }

-- O quadril da animação balança 2-4 cm por passo e o tronco é filho dele. Abaixo
-- da zona morta é balanço e vira zero; um agachamento passa de 30 cm. Sem lerp —
-- amortecer aqui só atrasa a vista (armadilha 6).
local HIP_DROP_DEADZONE = 8.0

local function keepSourceMeshesAnimating(rig)
	for _, template in pairs(rig.meshTemplates or {}) do
		local source = template.instance
		if uevrUtils.getValid(source) ~= nil and source.VisibilityBasedAnimTickOption ~= nil then
			source.VisibilityBasedAnimTickOption = ALWAYS_TICK_POSE_AND_REFRESH_BONES
		end
	end
end

local function detectFootBone(names, set, side)
	for _, candidate in ipairs(FOOT_NAMES[side]) do
		if set[candidate] ~= nil then return set[candidate] end
	end
	for _, keyword in ipairs({ "foot", "ankle" }) do
		local best = nil
		for _, name in ipairs(names) do
			local lower = string.lower(name)
			if string.find(lower, keyword, 1, true) ~= nil
				and not containsAny(lower, NOT_A_FOOT)
				and hasSideMarker(lower, side)
				and (best == nil or #name < #best)
			then
				best = name
			end
		end
		if best ~= nil then return best end
	end
	return nil
end

-- Pé -> canela -> coxa -> quadril. A lista final é coxa + todos os descendentes.
local function detectLegBones(mesh)
	legBones, legAnchorFName = nil, nil
	referenceHip, standingSourceHipZ, hipDrop = nil, nil, 0
	hipShift.X, hipShift.Y, hipShift.Z = 0, 0, 0
	if uevrUtils.getValid(mesh) == nil then return end

	local names = uevrUtils.getBoneNames(mesh)
	if names == nil or #names == 0 then return end
	local set = toBoneSet(names)

	local bones, anchor = {}, nil
	for _, side in ipairs({ Handed.Right, Handed.Left }) do
		local foot = detectFootBone(names, set, side)
		if foot ~= nil then
			local chain = getBoneChain(mesh, foot, 4) -- {pé, canela, coxa, quadril}
			if #chain >= 4 then
				local thigh = chain[3]
				anchor = anchor or chain[4]
				table.insert(bones, thigh)
				for _, descendant in ipairs(animation.getDescendantBones(mesh, thigh, false)) do
					table.insert(bones, descendant)
				end
			end
		end
	end

	if #bones == 0 or anchor == nil then
		log("Não achei os ossos das pernas — a animação das pernas fica desligada", LogLevel.Warning)
		return
	end

	legBones = {}
	for _, name in ipairs(bones) do
		table.insert(legBones, { name = name, fname = uevrUtils.fname_from_string(name) })
	end
	legAnchorFName = uevrUtils.fname_from_string(anchor)

	-- A cópia ainda está na pose de referência aqui, então este é o único momento
	-- em que dá para ler a posição "de pé" do quadril.
	local hipTransform = mesh:GetBoneTransformByName(legAnchorFName, EBoneSpaces.ComponentSpace)
	if hipTransform ~= nil and hipTransform.Translation ~= nil then
		referenceHip = {
			X = hipTransform.Translation.X,
			Y = hipTransform.Translation.Y,
			Z = hipTransform.Translation.Z,
		}
	end

	logMilestone("Pernas: " .. #legBones .. " ossos, ancoradas em " .. anchor
		.. ", quadril de pe em Z=" .. (referenceHip and string.format("%.1f", referenceHip.Z) or "?"))
end

-- A malha de origem da cópia principal é quem carrega a animação do jogo.
local function getSourceMesh()
	if currentRig == nil then return nil end
	local reference = bodyMeshes[1]
	if reference == nil then return nil end
	for _, template in pairs(currentRig.meshTemplates or {}) do
		if template.mesh == reference then return template.instance end
	end
	return nil
end

local function copyLegPose(engine, delta)
	-- Sem cópia de pernas o quadril fica na pose de referência: zerar o hipShift
	-- evita que um valor velho continue empurrando o tronco.
	if not isEnabled() or currentRig == nil or legBones == nil
		or configui.getValue("body_animate") == false
		or configui.getValue("body_onlyArms") == true
		or isBodyHidden()
	then
		hipShift.X, hipShift.Y, hipShift.Z = 0, 0, 0
		return
	end

	local reference = bodyMeshes[1]
	if uevrUtils.getValid(reference) == nil or reference.SetBoneTransformByName == nil then return end

	local source = getSourceMesh()
	if uevrUtils.getValid(source) == nil or source.GetSocketTransform == nil then return end

	local sourceAnchor = source:GetSocketTransform(legAnchorFName, RTS_COMPONENT)
	local targetAnchor = reference:GetBoneTransformByName(legAnchorFName, EBoneSpaces.ComponentSpace)
	if sourceAnchor == nil or targetAnchor == nil then return end

	-- O quadril é ÂNCORA: a animação só move a ALTURA dele, e só em agachamento de
	-- verdade (HIP_DROP_DEADZONE). X, Y e rotação vêm da pose de referência — girá-lo
	-- giraria o tronco inteiro, e reler o osso realimentaria o frame anterior.
	-- A linha do "em pé" é medida só a pé: criada no hipogrifo, gravaria a sela.
	if standingSourceHipZ == nil and mounts.isWalking() then
		standingSourceHipZ = sourceAnchor.Translation.Z
	end

	-- MONTADO: o quadril vai inteiro para onde a animação do jogo o põe. A prudência
	-- acima existe pelo balanço do andar, que montado não há.
	local mounted = not mounts.isWalking()

	if mounted or referenceHip ~= nil then
		if mounted then
			targetAnchor.Translation.X = sourceAnchor.Translation.X
			targetAnchor.Translation.Y = sourceAnchor.Translation.Y
			targetAnchor.Translation.Z = sourceAnchor.Translation.Z
			hipDrop = 0
		else
			hipDrop = 0
			if configui.getValue("body_followCrouch") ~= false and standingSourceHipZ ~= nil then
				-- só para baixo, e só o que passar da folga: andar não é agachar
				hipDrop = math.min(0, sourceAnchor.Translation.Z - standingSourceHipZ + HIP_DROP_DEADZONE)
			end

				-- escrito sempre, inclusive com hipDrop = 0: é assim que o quadril volta
				-- para a altura de pé quando o agachamento é desligado no painel
			targetAnchor.Translation.X = referenceHip.X
			targetAnchor.Translation.Y = referenceHip.Y
			targetAnchor.Translation.Z = referenceHip.Z + hipDrop
		end

		-- guardado para a cintura acompanhar (ver hipShift)
		if referenceHip ~= nil then
			hipShift.X = targetAnchor.Translation.X - referenceHip.X
			hipShift.Y = targetAnchor.Translation.Y - referenceHip.Y
			hipShift.Z = targetAnchor.Translation.Z - referenceHip.Z
		end

		for _, component in ipairs(bodyMeshes) do
			if uevrUtils.getValid(component) ~= nil and component.SetBoneTransformByName ~= nil then
				component:SetBoneTransformByName(legAnchorFName, targetAnchor, EBoneSpaces.ComponentSpace)
			end
		end
	end

	-- As pernas são reancoradas no quadril, então continuam rigidamente presas a
	-- ele — sem rasgo na cintura. Andando sobra a diferença do balanço, que é o
	-- deslizezinho de pé que o método sempre teve.
	local align = kismet_math_library:ComposeTransforms(
		kismet_math_library:InvertTransform(sourceAnchor), targetAnchor)

	-- Ajuste manual do painel, depois da reancoragem: empurra coxa, canela, pé e
	-- dedos juntos. OS EIXOS SÃO OS DO COMPONENTE — o esqueleto está girado -90°,
	-- então a frente do personagem cai no +Y e o lado direito no -X.
	local legOffset = configui.getValue("body_legOffset")
	local lx = legOffset and (legOffset.x or legOffset.X or 0) or 0
	local ly = legOffset and (legOffset.y or legOffset.Y or 0) or 0
	local lz = legOffset and (legOffset.z or legOffset.Z or 0) or 0
	local hasLegOffset = (lx ~= 0 or ly ~= 0 or lz ~= 0)

	for _, bone in ipairs(legBones) do
		local transform = source:GetSocketTransform(bone.fname, RTS_COMPONENT)
		if transform ~= nil then
			local aligned = kismet_math_library:ComposeTransforms(transform, align)
			if hasLegOffset and aligned.Translation ~= nil then
				aligned.Translation.X = aligned.Translation.X + lx
				aligned.Translation.Y = aligned.Translation.Y + ly
				aligned.Translation.Z = aligned.Translation.Z + lz
			end
			for _, component in ipairs(bodyMeshes) do
				if uevrUtils.getValid(component) ~= nil and component.SetBoneTransformByName ~= nil then
					component:SetBoneTransformByName(bone.fname, aligned, EBoneSpaces.ComponentSpace)
				end
			end
		end
	end
end

-- Prioridade 10 = antes do tick do ik.lua (0). Ele só mexe em braço, nós só em
-- perna, então os dois não se atropelam.
uevrUtils.registerPreEngineTickCallback(function(engine, delta)
	local ok, err = pcall(copyLegPose, engine, delta)
	if not ok then
		log("Falha ao animar as pernas: " .. tostring(err), LogLevel.Warning)
	end
end, 10)

--------------------------------------------------------------------------
-- 1b. SÓ MONTADO: apontar o ik.lua para o personagem e soltar o Z
--
-- Montado, o pawn controlado é a CRIATURA. `ik.setPawn` troca a referência que o
-- rig usa (a quem o corpo é anexado, ik.lua:493, e o CapsuleHalfHeight da conta
-- do Z, ik.lua:411) sem mexer em quem o jogo controla. E com `coupling = 2` o
-- ik.lua não escreve o Z (ik.lua:418): com a cápsula da criatura o alvo do
-- solver saía do alcance e a mão congelava. A pé tudo isto é no-op.
-- Ver LEIAME, armadilha 7.
--------------------------------------------------------------------------
local lastRigPawn = nil

local function updateRigPawn()
	local playerPawn = uevrUtils.getValid(pawn)
	if playerPawn == nil then
		-- sem pawn válido, o getPawn() do ik.lua cai sozinho no pawn global
		if lastRigPawn ~= nil then
			lastRigPawn = nil
			ik.setPawn(nil)
		end
		return
	end

	local rigPawn = uevrUtils.getValid(mounts.getMountPawn(playerPawn)) or playerPawn
	if rigPawn == lastRigPawn then return end
	lastRigPawn = rigPawn

	ik.setPawn(rigPawn)
	if rigPawn ~= playerPawn then
		logMilestone("Montado: ik.lua ancorado no personagem, nao na criatura")
	else
		logMilestone("ik.lua ancorado no pawn controlado")
	end
end

-- valor original do `coupling` do rig (vem de parent_type), guardado na criação
local rigCoupling = nil

-- SOMENTE BRAÇOS usa o mesmo destravamento: a conta do ik.lua:417 descreve um
-- corpo INTEIRO com os pés no chão e, sem tronco nem pernas, não descreve nada.
-- Dois donos escrevendo o mesmo Z é a receita do pisca (armadilha 10).
local function updateMountCoupling()
	if currentRig == nil then return end

	local wantFree = configui.getValue("body_onlyArms") == true
		or (not mounts.isWalking()
			and configui.getValue("body_mountArmsIK") ~= false)

	if wantFree then
		if currentRig.coupling ~= 2 then
			currentRig.coupling = 2
			logMilestone("Z do ik.lua liberado, quem posiciona a copia e o body.lua")
		end
	elseif rigCoupling ~= nil and currentRig.coupling ~= rigCoupling then
		currentRig.coupling = rigCoupling
		logMilestone("Z do ik.lua devolvido (coupling " .. tostring(rigCoupling) .. ")")
	end
end

-- Ossos do braço direito, só para os diagnósticos abaixo (sem efeito no jogo).
local diagArmBone, diagHandBone = nil, nil

local function detectDiagArmBones(mesh)
	diagArmBone, diagHandBone = nil, nil
	if uevrUtils.getValid(mesh) == nil then return end
	local names = uevrUtils.getBoneNames(mesh)
	if names == nil or #names == 0 then return end
	local hand = detectHandBone(names, toBoneSet(names), Handed.Right)
	if hand == nil then return end
	local chain = getBoneChain(mesh, hand, 5)
	diagHandBone = uevrUtils.fname_from_string(hand)
	if chain[3] ~= nil then diagArmBone = uevrUtils.fname_from_string(chain[3]) end
end

-- DIAGNÓSTICO DOS BRAÇOS, a cada 2 s e só montado. Anota o que decide se a mão
-- segue o controle: se algum callback `is_hands_animating_from_mesh` responder
-- true o ik.lua NEM CHAMA os solvers (ik.lua:435); e ombro->controle muito maior
-- que o braço satura o solver e congela a mão no limite do alcance.
local diagTimer = 0

local function logArmDiagnostics(delta)
	if mounts.isWalking() then diagTimer = 0 return end
	if currentRig == nil or #bodyMeshes == 0 then return end
	diagTimer = diagTimer + (delta or 0)
	if diagTimer < 2.0 then return end
	diagTimer = 0

	local mesh = bodyMeshes[1]
	if uevrUtils.getValid(mesh) == nil or mesh.GetBoneLocationByName == nil then return end

	local function fmt(v)
		if v == nil then return "nil" end
		return string.format("(%.0f, %.0f, %.0f)", v.X or 0, v.Y or 0, v.Z or 0)
	end

	local animLeft = uevrUtils.executeUEVRCallbacksWithPriorityBooleanResult(
		"is_hands_animating_from_mesh", Handed.Left)
	local animRight = uevrUtils.executeUEVRCallbacksWithPriorityBooleanResult(
		"is_hands_animating_from_mesh", Handed.Right)

	local shoulder = diagArmBone ~= nil and mesh:GetBoneLocationByName(diagArmBone, EBoneSpaces.WorldSpace) or nil
	local hand = diagHandBone ~= nil and mesh:GetBoneLocationByName(diagHandBone, EBoneSpaces.WorldSpace) or nil
	local controller = controllers.getController(1)
	local controllerLoc = uevrUtils.getValid(controller) ~= nil and controller:K2_GetComponentLocation() or nil

	local reach = "?"
	if shoulder ~= nil and controllerLoc ~= nil then
		reach = string.format("%.0f", kismet_math_library:Vector_Distance(shoulder, controllerLoc))
	end
	local erro = "?"
	if hand ~= nil and controllerLoc ~= nil then
		erro = string.format("%.0f", kismet_math_library:Vector_Distance(hand, controllerLoc))
	end

	local solvers = 0
	for _ in pairs(currentRig.activeSolvers or {}) do solvers = solvers + 1 end

	logMilestone("[bracos] solvers=" .. solvers
		.. ", animando pela malha: esq=" .. tostring(animLeft) .. " dir=" .. tostring(animRight)
		.. ", ombro=" .. fmt(shoulder) .. ", mao=" .. fmt(hand)
		.. ", controle=" .. fmt(controllerLoc)
		.. ", ombro->controle=" .. reach .. "cm, mao->controle=" .. erro .. "cm")
end

local lastLoggedMountType = nil

local function logMountStateChange()
	local mountType = mounts.getMountType()
	if mountType == lastLoggedMountType then return end
	lastLoggedMountType = mountType

	local function fmt(v)
		if v == nil then return "nil" end
		return string.format("(%.0f, %.0f, %.0f)", v.X or 0, v.Y or 0, v.Z or 0)
	end
	local function nameOf(obj)
		if uevrUtils.getValid(obj) == nil or obj.get_full_name == nil then return "nil" end
		local full = obj:get_full_name()
		return full:sub(-60)
	end

	-- O TIPO SAI PRIMEIRO, antes de qualquer leitura que possa estourar: com
	-- lastLoggedMountType já atualizado, a transição nunca mais seria registrada.
	logMilestone("--- montaria mudou: tipo=" .. tostring(mountType)
		.. ", voando=" .. tostring(mounts.getIsFlying()) .. " ---")

	local playerPawn = uevrUtils.getValid(pawn)
	local rider = playerPawn ~= nil and uevrUtils.getValid(mounts.getMountPawn(playerPawn)) or nil
	local source = getSourceMesh()
	local mesh = bodyMeshes[1]
	local hmd = controllers.getController(2)
	local root = uevrUtils.getValid(playerPawn, {"RootComponent"})
	logMilestone("  pawn=" .. nameOf(playerPawn) .. ", personagem=" .. nameOf(rider))
	logMilestone("  capsula=" .. tostring(root ~= nil and root.CapsuleHalfHeight or "nil")
		.. ", root=" .. fmt(root ~= nil and root:K2_GetComponentLocation() or nil))
	logMilestone("  malha do jogo=" .. nameOf(source) .. " em "
		.. fmt(uevrUtils.getValid(source) ~= nil and source:K2_GetComponentLocation() or nil))
	logMilestone("  copia=" .. fmt(uevrUtils.getValid(mesh) ~= nil and mesh:K2_GetComponentLocation() or nil)
		.. ", cabeca=" .. fmt(uevrUtils.getValid(mesh) ~= nil and mesh.GetSocketLocation ~= nil
			and mesh:GetSocketLocation(uevrUtils.fname_from_string(headBone)) or nil)
		.. ", HMD=" .. fmt(uevrUtils.getValid(hmd) ~= nil and hmd:K2_GetComponentLocation() or nil))
end

-- Falha de tick vai como marco (Error): em Warning não chega no log.txt e um
-- pcall que estoura todo frame ficava invisível. Cada mensagem sai uma vez só.
local loggedTickFailures = {}

local function logTickFailure(prefix, err)
	local text = prefix .. ": " .. tostring(err)
	if loggedTickFailures[text] then return end
	loggedTickFailures[text] = true
	logMilestone(text)
end

uevrUtils.registerPreEngineTickCallback(function(engine, delta)
	-- antes do coupling: quem for refazer o rig neste frame já pega o pawn certo
	local okPawn, errPawn = pcall(updateRigPawn)
	if not okPawn then
		logTickFailure("Falha ao apontar o pawn do rig", errPawn)
	end
	local ok, err = pcall(updateMountCoupling)
	if not ok then
		logTickFailure("Falha ao ajustar o coupling na montaria", err)
	end
	local okLog, errLog = pcall(logMountStateChange)
	if not okLog then
		logTickFailure("Falha ao registrar a mudanca de montaria", errLog)
	end
	local okArms, errArms = pcall(logArmDiagnostics, delta)
	if not okArms then
		logTickFailure("Falha no diagnostico dos bracos", errArms)
	end
end, 20)

--------------------------------------------------------------------------
-- 1c. SÓ MONTADO (criatura): postura do tronco
--
-- Montado o corpo não tem yaw próprio: herda a rotação da malha do jogo, que
-- aponta para onde a criatura aponta. Aqui a CINTURA (primeiro osso da coluna)
-- gira atrás do headset e recebe o "endireitar a coluna" — no quadril as pernas
-- iriam junto e sairiam do estribo. A conta parte sempre da pose de referência
-- capturada na criação, nunca do que está no osso.
--
-- Prioridade 5 = depois das pernas (10) e antes do IK (0). Ver LEIAME,
-- "Tronco acompanhando o headset" e "Endireitar a coluna".
--------------------------------------------------------------------------

local waistFName    = nil   -- primeiro osso da coluna (filho do quadril)
local waistRef      = nil   -- pose de referência dele, em números
local waistYawState = 0     -- torção já aplicada (suavizada)
local waistApplied  = false -- há uma torção escrita no osso agora?
local waistWarned   = false

local WAIST_LERP = 8.0

-- O endireitamento NÃO é suavizado de propósito: já é função direta da rotação da
-- criatura, que muda suave. Um lerp aqui só atrasaria a correção.

local function detectWaistBone(mesh)
	waistFName, waistRef, waistYawState, waistApplied = nil, nil, 0, false
	if uevrUtils.getValid(mesh) == nil or legAnchorFName == nil then return end
	if mesh.GetParentBone == nil or mesh.GetBoneTransformByName == nil then return end

	local names = uevrUtils.getBoneNames(mesh)
	if names == nil or #names == 0 then return end

	-- filho direto do quadril que não é perna. Entre candidatos vence o nome mais
	-- curto, que é a raiz da coluna (Spine, não Spine_twist_01).
	local isLeg = {}
	for _, bone in ipairs(legBones or {}) do isLeg[string.lower(bone.name)] = true end

	local hipName = legAnchorFName:to_string()
	local best = nil
	for _, name in ipairs(names) do
		if not isLeg[string.lower(name)] then
			local parent = mesh:GetParentBone(uevrUtils.fname_from_string(name))
			if parent ~= nil and parent:to_string() == hipName then
				if best == nil or #name < #best then best = name end
			end
		end
	end

	if best == nil then
		log("Não achei o osso da cintura — o tronco não vai acompanhar a visão na montaria", LogLevel.Warning)
		return
	end

	local fname = uevrUtils.fname_from_string(best)
	-- A cópia ainda está na pose de referência aqui: único momento em que dá para
	-- ler a pose "neutra" da cintura.
	local transform = mesh:GetBoneTransformByName(fname, EBoneSpaces.ComponentSpace)
	local q = transform ~= nil and transform.Rotation or nil
	if transform == nil or transform.Translation == nil or q == nil or q.W == nil then
		log("Não consegui ler a pose da cintura ('" .. best .. "')", LogLevel.Warning)
		return
	end

	local rot = uevrUtils.rotatorFromQuat(q.X, q.Y, q.Z, q.W)
	local scale = transform.Scale3D
	waistFName = fname
	-- guardado em NÚMEROS: struct do motor devolvida por Get... é reaproveitada
	waistRef = {
		lx = transform.Translation.X, ly = transform.Translation.Y, lz = transform.Translation.Z,
		pitch = rot.Pitch, yaw = rot.Yaw, roll = rot.Roll,
		sx = scale ~= nil and scale.X or 1, sy = scale ~= nil and scale.Y or 1,
		sz = scale ~= nil and scale.Z or 1,
	}

	logMilestone("Cintura: '" .. best .. "' (acima de '" .. hipName .. "')")
end

-- Rotação que, aplicada na cintura, tira da coluna a inclinação que veio da malha
-- do jogo; nil quando não há nada a fazer. A leitura é da MALHA DE ORIGEM e não
-- da nossa cópia: é a mesma fonte que a seção 4 usa, então as duas veem o mesmo
-- valor no mesmo quadro.
local function computeSpineCorrection()
	local amount = configui.getValue("body_mountSpineUpright") or 0
	local trim   = configui.getValue("body_mountSpineTrim") or 0
	if amount <= 0 and trim == 0 then return nil end

	local source = getSourceMesh()
	if uevrUtils.getValid(source) == nil or source.K2_GetComponentRotation == nil then return nil end
	local srcRot = source:K2_GetComponentRotation()
	if srcRot == nil then return nil end

	amount = math.max(0, math.min(1, amount))
	local withRoll = configui.getValue("body_mountSpineRoll") ~= false

	-- para onde a rotação do componente é puxada: mesmo yaw, pitch (e roll, se
	-- marcado) reduzidos. 0 = pose do jogo; 1 = tronco na vertical do mundo.
	local target = uevrUtils.rotator(
		srcRot.Pitch * (1 - amount),
		srcRot.Yaw,
		withRoll and (srcRot.Roll * (1 - amount)) or srcRot.Roll)

	-- Ajuste fino: uma inclinação a mais, no plano de quem está montado. Tem de ser
	-- em volta do eixo esquerda-direita DO PERSONAGEM, e tirar o "Mesh Rotation
	-- Offset" do yaw da malha dá justamente a direção para onde ele olha.
	if trim ~= 0 then
		local rigYaw = 0
		if currentRig ~= nil and currentRig.meshRotationOffset ~= nil then
			rigYaw = currentRig.meshRotationOffset.Yaw or 0
		end
		local facingYaw = srcRot.Yaw - rigYaw
		-- desgira -> inclina em pitch (agora o pitch é o do personagem) -> gira de volta
		local lean = kismet_math_library:ComposeRotators(
			kismet_math_library:ComposeRotators(
				uevrUtils.rotator(0, -facingYaw, 0),
				uevrUtils.rotator(trim, 0, 0)),
			uevrUtils.rotator(0, facingYaw, 0))
		target = kismet_math_library:ComposeRotators(target, lean)
	end

	-- Diferença entre "como o componente deveria estar" e "como ele está".
	-- Transform, não rotator: o inverso de um rotator não é o rotator negado.
	local one  = uevrUtils.vector(1, 1, 1)
	local zero = uevrUtils.vector(0, 0, 0)
	return kismet_math_library:ComposeTransforms(
		kismet_math_library:MakeTransform(zero, target, one),
		kismet_math_library:InvertTransform(
			kismet_math_library:MakeTransform(zero, uevrUtils.rotator(srcRot.Pitch, srcRot.Yaw, srcRot.Roll), one)))
end

-- Escreve a cintura. `correction` é o que computeSpineCorrection devolveu, ou nil.
-- A CABEÇA NÃO É TRATADA AQUI: reescrevê-la esticava o pescoço ("chiclete") e
-- descolava a vista. Ela é osso da coluna e anda com ela; quem reposiciona a
-- vista é o "Ajuste dos olhos".
local function writeWaist(yaw, correction)
	local rotation = uevrUtils.rotator(waistRef.pitch, waistRef.yaw, waistRef.roll)
	if yaw ~= 0 then
		rotation = kismet_math_library:ComposeRotators(rotation, uevrUtils.rotator(0, yaw, 0))
	end

	-- Translação = pose de referência MAIS o quanto o quadril saiu dela (hipShift).
	-- Em espaço de componente a escrita é absoluta: sem a soma, montado, o tronco
	-- ficaria na pose de pé enquanto as pernas sentam, e o corpo se partiria.
	local lx = waistRef.lx + hipShift.X
	local ly = waistRef.ly + hipShift.Y
	local lz = waistRef.lz + hipShift.Z

	local transform = kismet_math_library:MakeTransform(
		uevrUtils.vector(lx, ly, lz),
		rotation,
		uevrUtils.vector(waistRef.sx, waistRef.sy, waistRef.sz))

	if correction ~= nil then
		-- A correção entra DEPOIS da rotação do osso, remontada com a translação e a
		-- escala originais: giro puro na junta da cintura, sem deslocar nada.
		local rotated = kismet_math_library:ComposeTransforms(
			kismet_math_library:MakeTransform(uevrUtils.vector(0, 0, 0), rotation, uevrUtils.vector(1, 1, 1)),
			correction)
		local q = rotated ~= nil and rotated.Rotation or nil
		if q ~= nil and q.W ~= nil then
			transform = kismet_math_library:MakeTransform(
				uevrUtils.vector(lx, ly, lz),
				uevrUtils.rotatorFromQuat(q.X, q.Y, q.Z, q.W),
				uevrUtils.vector(waistRef.sx, waistRef.sy, waistRef.sz))
		end
	end

	for _, component in ipairs(bodyMeshes) do
		if uevrUtils.getValid(component) ~= nil and component.SetBoneTransformByName ~= nil then
			component:SetBoneTransformByName(waistFName, transform, EBoneSpaces.ComponentSpace)
		end
	end

end

-- Condições comuns ao giro atrás do headset e ao endireitar da coluna. Qual das
-- duas age é decidido no tick — cada uma tem o seu controle no painel.
local function waistControlActive()
	if waistFName == nil or waistRef == nil then return false end
	if not isEnabled() or currentRig == nil or #bodyMeshes == 0 then return false end
	if mounts.isWalking() then return false end
	-- vassoura fica de fora: lá a regra é não modificar nada
	if mounts.isOnBroom() then return false end
	if isBodyHidden() then return false end
	return true
end

local function updateWaistFollow(engine, delta)
	local active = waistControlActive()

	local correction = nil
	if active then
		local ok, result = pcall(computeSpineCorrection)
		if ok then correction = result end
	end

	local followYaw = active and configui.getValue("body_mountHipAlign") ~= false

	if not active or (not followYaw and correction == nil) then
		-- Desmontou (ou desligou tudo): devolve a cintura à pose de referência UMA
		-- vez, senão o osso guardaria a torção para sempre. A pé não escreve nada.
		if waistApplied then
			waistApplied = false
			waistYawState = 0
			local ok = pcall(writeWaist, 0, nil)
			if not ok and not waistWarned then
				waistWarned = true
				logMilestone("Cintura: nao consegui devolver a pose de referencia")
			end
		end
		return
	end

	local target = 0
	if followYaw then
		local hmd = controllers.getController(2)
		local mesh = bodyMeshes[1]
		if uevrUtils.getValid(hmd) == nil or uevrUtils.getValid(mesh) == nil then return end

		local hmdRot = hmd:K2_GetComponentRotation()
		local bodyRot = mesh:K2_GetComponentRotation()
		if hmdRot == nil or bodyRot == nil then return end

		-- Montado, a rotação do corpo é a da malha do jogo, então a torção é
		-- simplesmente a diferença entre o headset e ela.
		local diff = uevrUtils.clampAngle180(hmdRot.Yaw - bodyRot.Yaw)

		local deadzone = configui.getValue("body_mountHipDeadzone") or 0
		if math.abs(diff) > deadzone then
			local sign = diff >= 0 and 1 or -1
			target = (diff - sign * deadzone) * (configui.getValue("body_mountHipSensitivity") or 0)
			local limit = configui.getValue("body_mountHipMaxYaw") or 60
			target = math.max(-limit, math.min(limit, target))
		end
	end

	if delta ~= nil and delta > 0 then
		waistYawState = waistYawState + (target - waistYawState) * math.min(1, WAIST_LERP * delta)
	else
		waistYawState = target
	end

	waistApplied = true
	writeWaist(waistYawState, correction)
end

uevrUtils.registerPreEngineTickCallback(function(engine, delta)
	local ok, err = pcall(updateWaistFollow, engine, delta)
	if not ok then
		log("Falha ao girar a cintura: " .. tostring(err), LogLevel.Warning)
	end
end, 5)

--------------------------------------------------------------------------
-- 2. Altura do corpo
--
-- Sobrou só a linha de base do quadril. As duas correções que moravam aqui
-- (perseguir a malha do jogo, armadilha 3; "agachar de verdade" pelo HMD,
-- armadilha 2) foram removidas e não devem voltar. Quem trata agachamento é a
-- altura do QUADRIL (seção 1); a altura do corpo é inteiramente do ik.lua.
--------------------------------------------------------------------------

local function resetHeightCalibration()
	standingSourceHipZ = nil -- a linha do "em pé" do quadril (seção 1)
end

--------------------------------------------------------------------------
-- 3. Câmera atracada à cabeça do corpo
--
-- Por padrão a câmera deste perfil ORBITA o pawn (main.lua:130) e sobrava para o
-- corpo correr atrás dela. Aqui a câmera vai ao osso da cabeça, nos TRÊS EIXOS,
-- a pé e montado. Só a POSIÇÃO: a rotação continua do headset, e o roomscale é
-- somado pelo UEVR depois deste callback.
--
-- O registro sai de um uevrUtils.delay porque a ordem importa: o callback do
-- main.lua é registrado durante o carregamento e sobrescreveria o nosso.
-- Mundo deslizando ao virar o corpo = X/Y do `mesh_location_offset`, que é o
-- raio do arco descrito pelo osso.
--------------------------------------------------------------------------
local function headCameraActive()
	if not isEnabled() or currentRig == nil or #bodyMeshes == 0 then return false end
	if configui.getValue("body_headCamera") ~= true then return false end
	if configui.getValue("body_onlyArms") == true then return false end -- sem corpo, sem cabeça
	if isBodyHidden() then return false end
	return true
end

local function getHeadWorldLocation()
	local mesh = bodyMeshes[1]
	if uevrUtils.getValid(mesh) == nil or mesh.GetSocketLocation == nil then return nil end
	-- "Esconder a cabeca" encolhe o osso, não o move: a posição continua valendo.
	return mesh:GetSocketLocation(uevrUtils.fname_from_string(headBone))
end

--------------------------------------------------------------------------
-- OLHAR PARA BAIXO LEVA A VISTA UM POUCO PARA A FRENTE
--
-- Move só A CÂMERA, nenhum osso. Quanto mais para baixo você olha, mais a vista
-- avança; olhando reto, avanço nenhum. Só dentro de 60° para cada lado da frente
-- do corpo, e o avanço é na FRENTE DO CORPO, nunca na direção do olhar. Vale a
-- pé, na vassoura e em criatura. Ver LEIAME, "Olhar para baixo...".
--------------------------------------------------------------------------

local GAZE_ARC_CORE   = 45 -- até aqui o efeito é cheio
local GAZE_ARC_HALF   = 60 -- daqui para fora, zero (a janela de 120°)
local GAZE_PITCH_DEAD = 10 -- graus de olhar para baixo que ainda não movem nada

-- Devolve o yaw do olhar relativo à frente do corpo, o pitch contra o HORIZONTE
-- (negativo = olhando para baixo) e a direção do avanço, achatada no chão.
-- Tudo por vetor, nunca `.Yaw`/`.Pitch` de rotator, que se confundem com o roll
-- perto de 90° de pitch. Ver LEIAME, "Yaw contra o corpo, pitch contra o horizonte".
local function getGazeInBodySpace()
	local mesh = bodyMeshes[1]
	local hmd = controllers.getController(2)
	if uevrUtils.getValid(mesh) == nil or uevrUtils.getValid(hmd) == nil then return nil end
	if mesh.K2_GetComponentRotation == nil or hmd.K2_GetComponentRotation == nil then return nil end
	if kismet_math_library == nil or kismet_math_library.GetForwardVector == nil
		or kismet_math_library.GetRightVector == nil then return nil end

	local hmdRot  = hmd:K2_GetComponentRotation()
	local bodyRot = mesh:K2_GetComponentRotation()
	if hmdRot == nil or bodyRot == nil then return nil end

	-- copiar para números na hora: o motor reaproveita a mesma struct
	local v = kismet_math_library:GetForwardVector(hmdRot)
	if v == nil then return nil end
	local vx, vy, vz = v.X, v.Y, v.Z

	-- só X e Y: a janela e o avanço são medidos no chão
	local f = kismet_math_library:GetForwardVector(bodyRot)
	if f == nil then return nil end
	local fx, fy = f.X, f.Y

	local r = kismet_math_library:GetRightVector(bodyRot)
	if r == nil then return nil end
	local rx, ry = r.X, r.Y

	-- frente do ESQUELETO: eixos do componente girados por -meshRotationOffset.Yaw
	local rigYaw = 0
	if currentRig ~= nil and currentRig.meshRotationOffset ~= nil then
		rigYaw = currentRig.meshRotationOffset.Yaw or 0
	end
	local a = math.rad(-rigYaw)
	local ca, sa = math.cos(a), math.sin(a)
	local Fx, Fy = (fx * ca) + (rx * sa), (fy * ca) + (ry * sa)

	-- Os dois yaws saem da sombra no chão: achatar é o que faz a conta valer com o
	-- personagem reclinado (hipogrifo) ou deitado (vassoura).
	local bodyFlat = math.sqrt((Fx * Fx) + (Fy * Fy))
	local gazeFlat = math.sqrt((vx * vx) + (vy * vy))
	-- reto para cima/baixo: sem sombra para medir, e direção inventada seria pior
	if bodyFlat < 0.0001 or gazeFlat < 0.0001 then return nil end

	local bodyYawNow = math.deg(math.atan(Fy, Fx))
	local gazeYaw    = math.deg(math.atan(vy, vx))

	-- pitch CONTRA O HORIZONTE: é o pescoço de quem joga, não o peito do boneco
	local pitch = math.deg(math.atan(vz, gazeFlat))

	-- avanço: frente do corpo achatada e normalizada, para ser sempre horizontal —
	-- na frente crua, montado, ele apontaria para o chão ou para o céu
	return gazeYaw - bodyYawNow, pitch, Fx / bodyFlat, Fy / bodyFlat, 0
end

-- Quantos centímetros a vista avança agora, e para onde; nil quando não há avanço
-- nenhum. Sem suavização: a conta já é contínua nas duas bordas, e amortecer o
-- que alimenta a câmera é atraso na vista (armadilha 6).
local function gazeLeanPush()
	if configui.getValue("body_gazeLean") == false then return nil end
	-- sem a câmera na cabeça ninguém escreve posição; repetido aqui para o
	-- "Diagnostico no log" não anunciar um empurrão que não acontece
	if not headCameraActive() then return nil end

	local maximum = configui.getValue("body_gazeLeanMax") or 0
	if maximum <= 0 then return nil end

	local relYaw, relPitch, Fx, Fy, Fz = getGazeInBodySpace()
	if relYaw == nil then return nil end

	-- janela de 120°: cheio até 45°, cosseno até 60°, zero depois
	local away = math.abs(uevrUtils.clampAngle180(relYaw))
	if away >= GAZE_ARC_HALF then return nil end
	local gate = 1
	if away > GAZE_ARC_CORE then
		gate = 0.5 * (1 + math.cos(math.pi * (away - GAZE_ARC_CORE) / (GAZE_ARC_HALF - GAZE_ARC_CORE)))
	end

	-- rampa do pitch: 0 na zona morta, 1 reto para baixo — assim o painel é em cm
	local down = -relPitch - GAZE_PITCH_DEAD
	if down <= 0 then return nil end
	local ramp = down / (90 - GAZE_PITCH_DEAD)
	if ramp > 1 then ramp = 1 end

	return maximum * ramp * gate, Fx, Fy, Fz
end

-- Só para o "Diagnostico no log".
local function gazeLeanDistance()
	local push = gazeLeanPush()
	return push or 0
end

-- Tudo é lido AQUI dentro, no mesmo instante em que a posição é escrita: nada vem
-- guardado do tick e não há teste de olho (armadilha 5).
local function applyHeadCamera(position, rotation)
	if not headCameraActive() then return end

	-- Osso da CÓPIA, não da malha do jogo: a câmera pega a cabeça que você vê. Sem
	-- osso não escrevemos nada e vale a câmera normal do perfil.
	local head = getHeadWorldLocation()
	if head == nil then return end

	local x, y, z = head.X, head.Y, head.Z

	-- olhar para baixo empurra a vista para a frente (bloco acima)
	local push, fx, fy, fz = gazeLeanPush()
	if push ~= nil then
		x, y, z = x + (fx * push), y + (fy * push), z + (fz * push)
	end

	-- ALTURA DOS OLHOS acima do osso da cabeça. Um só para tudo e só altura: o X/Y
	-- que existiu aqui girava pelo olhar e fazia a câmera andar em círculo.
	z = z + (configui.getValue("body_headCameraHeight") or 0)

	position.x = x
	position.y = y
	position.z = z
end

local headCameraRegistered = false

local function registerHeadCamera()
	if headCameraRegistered then return end
	headCameraRegistered = true

	uevr.params.sdk.callbacks.on_early_calculate_stereo_view_offset(
		function(device, view_index, world_to_meters, position, rotation, is_double)
			-- pcall obrigatório: roda no caminho da câmera, uma vez por olho
			local ok, err = pcall(applyHeadCamera, position, rotation)
			if not ok then
				-- Warning NÃO chega no log.txt e o erro ficaria invisível; logTickFailure
				-- manda como marco, uma vez por mensagem.
				logTickFailure("Falha na camera da cabeca", err)
			end
		end)

	logMilestone("Camera atracada a cabeca: callback registrado")
end

--------------------------------------------------------------------------
-- 4. Posição e giro do corpo
--
-- O corpo é filho do RootComponent, então gira com o PAWN — e este perfil usa yaw
-- desacoplado. O libs/body_yaw.lua gira o corpo atrás do yaw do HMD, com lerp e
-- zona morta. A posição é recalculada todo frame porque a câmera do perfil ORBITA
-- a origem do pawn (main.lua:130, raio ~19 cm) e o corpo, preso ao RootComponent,
-- não acompanharia. Só X e Y: o Z é do tick do ik.lua (prioridade 0), o valor
-- ajustado em "Posicao".
--------------------------------------------------------------------------

-- Para onde o corpo olha. Variável NOSSA, nunca lida de volta do componente: o
-- jogo gira o pawn no tick do motor, depois deste callback, e o corpo acabava
-- seguindo o analógico em vez do headset (armadilha 4).
local bodyYawState = nil

local function updateBodyTransform(engine, delta)
	if not isEnabled() or currentRig == nil or #bodyMeshes == 0 then return end
	if isBodyHidden() then return end

	local followView = configui.getValue("body_followView") ~= false
	-- SOMENTE BRAÇOS: os ombros penduram na SUA cabeça, não no chão. Neste modo o
	-- ik.lua encolhe o esqueleto e todos os ossos desabam na origem do componente
	-- (nos pés), então a posição inteira sai do HMD e "Altura dos bracos" é a
	-- distância dos olhos aos ombros. Ler o HMD aqui não é realimentação: sem
	-- cabeça para atracar, headCameraActive() é false (armadilha 2).
	local onlyArms = configui.getValue("body_onlyArms") == true

	local rootComponent = uevrUtils.getValid(pawn, {"RootComponent"})
	if rootComponent == nil then return end
	-- Montado, o `pawn` global é A CRIATURA, mas o corpo está preso ao RootComponent
	-- do PERSONAGEM (updateRigPawn / ik.setPawn), e é contra esse pai que
	-- RelativeLocation é medido. Só "somente bracos" chega aqui montado — o resto
	-- sai no bloco abaixo, que escreve em MUNDO. A pé é no-op.
	if onlyArms and not mounts.isWalking() then
		local rigRoot = uevrUtils.getValid(mounts.getMountPawn(pawn), {"RootComponent"})
		if rigRoot ~= nil then rootComponent = rigRoot end
	end
	local mesh = bodyMeshes[1]
	if uevrUtils.getValid(mesh) == nil then return end

	--------------------------------------------------------------------------
	-- MONTARIA (vassoura, hipogrifo): o corpo copia a malha do jogo, em MUNDO.
	--
	-- A conta normal pressupõe alguém EM PÉ (X/Y de um offset ajustado a pé, Z da
	-- cápsula, rotação só de yaw); na vassoura o jogo deita o personagem, então ela
	-- é abandonada. Em mundo porque montado o personagem é outro ator e não divide
	-- o pai com a cópia. "Somente bracos" não entra: copiar a malha é o que põe o
	-- TRONCO na sela, e ali os ombros ficam debaixo da sua cabeça.
	--------------------------------------------------------------------------
	if not mounts.isWalking() and not onlyArms then
		local source = getSourceMesh()
		if uevrUtils.getValid(source) ~= nil and source.K2_GetComponentLocation ~= nil then
			local srcLoc = source:K2_GetComponentLocation()
			local srcRot = source:K2_GetComponentRotation()
			if srcLoc ~= nil and srcRot ~= nil then
					-- Posição e rotação cruas da malha do jogo: cópia e malha têm o
					-- mesmo esqueleto e a mesma origem.
				for _, component in ipairs(bodyMeshes) do
					if uevrUtils.getValid(component) ~= nil and component.K2_SetWorldLocation ~= nil then
						component:K2_SetWorldLocation(
							uevrUtils.vector(srcLoc.X, srcLoc.Y, srcLoc.Z, true),
							false, reusable_hit_result, false)
						component:K2_SetWorldRotation(
							uevrUtils.rotator(srcRot.Pitch, srcRot.Yaw, srcRot.Roll),
							false, reusable_hit_result, false)
					end
				end

					-- o yaw livre perde o sentido montado; recomeça do pawn ao desmontar
				bodyYawState = nil
				return
			end
		end
	end

	local hmd = controllers.getController(2)
	local pawnYaw = rootComponent:K2_GetComponentRotation().Yaw
	-- O offset de yaw é da rotação da malha, não da direção para onde o corpo olha,
	-- então entra e sai da conta. Lido do rig (Mesh Rotation Offset): dono único é
	-- o painel IK Dev Config (armadilha 8).
	local meshYawOffset = 0
	if currentRig ~= nil and currentRig.meshRotationOffset ~= nil then
		meshYawOffset = currentRig.meshRotationOffset.Yaw or 0
	end

	-- 1) para onde o corpo olha
	local newYaw = pawnYaw
	if followView then
		if bodyYawState == nil then bodyYawState = pawnYaw end
		newYaw = bodyYawState
		if uevrUtils.getValid(hmd) ~= nil and delta ~= nil and delta > 0 then
			newYaw = bodyYaw.update(newYaw, hmd:K2_GetComponentRotation().Yaw, delta) or newYaw
		end
		bodyYawState = newYaw
	else
		-- desligado: o corpo volta a girar com o pawn, e recomeça de onde ele estiver
		bodyYawState = nil
	end

	-- 2) posição horizontal: base + o ajuste do painel, medido no espaço do CORPO,
	-- então ele gira junto — senão "um pouco para trás" viraria "para frente".
	local x, y = 0, 0
	local offset = currentRig.meshLocationOffset
	if offset ~= nil then
		local rotated = kismet_math_library:RotateAngleAxis(
			uevrUtils.vector(offset.X, offset.Y, 0), newYaw - pawnYaw, uevrUtils.vector(0, 0, 1))
		x, y = rotated.X, rotated.Y
	end

	-- "Somente bracos" mede tudo a partir do HMD, inclusive o ajuste do painel
	local armsOffset = nil
	if onlyArms then
		local value = configui.getValue("body_armsOffset")
		if value ~= nil then
			local rotated = kismet_math_library:RotateAngleAxis(
				uevrUtils.vector(value.x or value.X or 0, value.y or value.Y or 0, 0),
				newYaw - pawnYaw, uevrUtils.vector(0, 0, 1))
			x, y = x + rotated.X, y + rotated.Y
			armsOffset = value.z or value.Z or 0
		else
			armsOffset = 0
		end
	end

	local armsZ = nil
	if onlyArms and uevrUtils.getValid(hmd) ~= nil then
		local hmdLoc = hmd:K2_GetComponentLocation()
		local rootLoc = rootComponent:K2_GetComponentLocation()
		-- diferença em mundo -> espaço do pawn, que é onde RelativeLocation vive
		local inPawnSpace = kismet_math_library:RotateAngleAxis(
			uevrUtils.vector(hmdLoc.X - rootLoc.X, hmdLoc.Y - rootLoc.Y, 0),
			-pawnYaw, uevrUtils.vector(0, 0, 1))
		x = x + inPawnSpace.X
		y = y + inPawnSpace.Y
		if armsOffset ~= nil then
			-- altura relativa ao pawn; a conta da cápsula do ik.lua não entra aqui
			armsZ = (hmdLoc.Z - rootLoc.Z) + armsOffset
		end
	end

	-- 3) altura: é do ik.lua, que escreve RelativeLocation.Z no tick de prioridade
	-- 0, logo antes deste — lemos o valor dele e devolvemos igual (armadilha 2).
	-- Única exceção é "somente bracos" (armsZ), onde a cápsula não descreve nada.
	for _, component in ipairs(bodyMeshes) do
		if uevrUtils.getValid(component) ~= nil and component.K2_SetRelativeLocation ~= nil then
			local z = armsZ
			if z == nil then
				z = component.RelativeLocation ~= nil and component.RelativeLocation.Z or 0
			end
			component:K2_SetRelativeLocation(
				uevrUtils.vector(x, y, z, true), false, reusable_hit_result, false)
		end
	end

	-- Em "somente bracos" a rotação é escrita sempre: montado, o bloco que copiava
	-- a rotação da malha não roda, e sobraria a rotação da criatura.
	if followView or onlyArms then
		local rotation = uevrUtils.rotator(0, newYaw + meshYawOffset, 0)
		for _, component in ipairs(bodyMeshes) do
			if uevrUtils.getValid(component) ~= nil and component.K2_SetWorldRotation ~= nil then
				component:K2_SetWorldRotation(rotation, false, reusable_hit_result, false)
			end
		end
	end
end

--------------------------------------------------------------------------
-- SOMENTE BRAÇOS: repor o corpo escondido depois que o ik.lua copia a pose
--
-- O "esconder" deste modo mora na ESCALA dos ossos (armadilha 10) e dois pontos
-- do ik.lua a desfazem: animateFromMesh (ik.lua:677) e setInitialTransform
-- (ik.lua:440). Quem liga isso é o montage, que oscila — daí o corpo aparecer e
-- sumir parado. A reposição roda só nos frames com cópia de pose, mais um.
--------------------------------------------------------------------------
local reapplyCount = 0
local wasAnimatingLast = false

local function reapplyHiddenBodyScales()
	if currentRig == nil or #bodyMeshes == 0 then return end
	if configui.getValue("body_onlyArms") ~= true then
		wasAnimatingLast = false
		return
	end

	local animating = currentRig.wasAnimating == true
	-- nada aconteceu neste frame nem no anterior
	if not animating and not wasAnimatingLast then return end
	wasAnimatingLast = animating

	if currentRig.updateBonesVisibility == nil then return end
	currentRig:updateBonesVisibility()
	-- a cabeça é escondida do mesmo jeito (escala do osso), então cai junto
	applyHeadVisibility()

	reapplyCount = reapplyCount + 1
	-- só nas primeiras vezes: um pisca a 90 Hz encheria o log.txt
	if reapplyCount <= 5 then
		logMilestone("Somente bracos: pose do jogo copiada, corpo escondido reposto (" .. reapplyCount .. ")")
	end
end

-- Prioridade -10 = depois do tick do ik.lua, para a rotação final ser a nossa.
-- Continua no pré-tick: escrever transform no pós-tick fazia o corpo piscar.
uevrUtils.registerPreEngineTickCallback(function(engine, delta)
	-- escalas primeiro: os ossos que o posicionamento e os solvers usam já ficam
	-- certos neste mesmo frame
	local okScale, errScale = pcall(reapplyHiddenBodyScales)
	if not okScale then
		logTickFailure("Falha ao repor o corpo escondido", errScale)
	end

	local ok, err = pcall(updateBodyTransform, engine, delta)
	if not ok then
		log("Falha ao posicionar o corpo: " .. tostring(err), LogLevel.Warning)
	end
end, -10)

--------------------------------------------------------------------------
-- Criação do rig
--------------------------------------------------------------------------

-- O vínculo da varinha não sobrevive ao rig novo. Só DESCONECTAMOS — quem
-- reconecta é o poll do main.lua (linha 1009). pcall obrigatório: isto é chamado
-- de timers, que o uevr_utils roda sem proteção (uevr_utils:1123).
local function rebuildWand()
	if type(_G.disconnectWand) ~= "function" then return end
	local ok, err = pcall(_G.disconnectWand)
	if ok then
		log("Varinha desconectada para reconectar junto com o corpo")
	else
		log("Falha ao reconectar a varinha: " .. tostring(err), LogLevel.Warning)
	end
end

--------------------------------------------------------------------------
-- CORPOS FANTASMAS
--
-- Cópia PoseableMesh que sobrevive a um destroy fica órfã e congela onde estava:
-- é isso que dá "dois corpos" e z-fighting. Varremos as cópias penduradas no pawn
-- em dois momentos — depois do nosso destroyAll (keep vazio) e na criação do
-- corpo novo (keep = as malhas novas, que cobre os destroyAll do próprio ik.lua).
-- Desce pela árvore por causa do SpringArm do coupling 2, e destroyOwner = false
-- sempre, porque o dono é o pawn. Ver LEIAME, armadilha 9.
--------------------------------------------------------------------------
-- Lista as cópias, marcando com `mine` as de `keep`: o diagnóstico precisa das
-- duas (mais de uma = fantasma; só uma = briga de escrita).
local function collectPoseableCopies(keep)
	local found = {}

	local rootComponent = uevrUtils.getValid(pawn, {"RootComponent"})
	if rootComponent == nil then return found end

	local poseableClass = uevrUtils.get_class("Class /Script/Engine.PoseableMeshComponent")
	if poseableClass == nil then return found end

	local isMine = {}
	for _, mesh in ipairs(keep or {}) do isMine[mesh] = true end

	local function collect(component, depth)
		if depth > 4 then return end
		local children = component.AttachChildren
		if children == nil then return end
		for i = 1, #children do
			local child = children[i]
			if uevrUtils.getValid(child) ~= nil then
				if child.is_a ~= nil and child:is_a(poseableClass) then
					table.insert(found, { component = child, mine = isMine[child] == true })
				end
				collect(child, depth + 1)
			end
		end
	end
	collect(rootComponent, 0)

	return found
end

local function destroyGhostBodies(keep)
	-- corpo desligado: o perfil volta às mãos antigas, que também são PoseableMesh
	if not isEnabled() then return end

	local ghosts = {}
	for _, entry in ipairs(collectPoseableCopies(keep)) do
		if not entry.mine then table.insert(ghosts, entry.component) end
	end

	if #ghosts == 0 then return end
	for _, ghost in ipairs(ghosts) do
		pcall(uevrUtils.destroyComponent, ghost, false, true)
	end
	logMilestone("Corpos fantasmas removidos: " .. #ghosts)
end

local function rebuild()
	ik.destroyAll()
	-- o que sobrou de PoseableMesh no pawn agora é fantasma
	pcall(destroyGhostBodies)
	currentRig = nil
	bodyMeshes = {}
	bodyYawState = nil
	resetHeightCalibration()
	rebuildWand()
end

-- Aplica um parâmetro do rig e grava em data/ik_parameters.json. Sem fila de
-- espera: o que sobrou ("hide_body") não pode esperar, porque desligá-lo faz o
-- próprio módulo IK reconstruir o rig.
local function setRigParam(key, value)
	if currentRig ~= nil then
		currentRig:setConfigParameter(key, value, true)
	end
end

ik.registerOnMeshCreatedCallback(function(meshList, rig)
	currentRig = rig
	bodyMeshes = meshList or {}
	if #bodyMeshes == 0 then
		log("Nenhuma malha foi criada para o corpo", LogLevel.Warning)
		return
	end

	-- Único ponto por onde passam TODOS os caminhos de criação, inclusive os que o
	-- ik.lua dispara sozinho — por isso a varredura mora aqui também.
	pcall(destroyGhostBodies, bodyMeshes)

	-- Confere os nomes de osso contra a malha real: nome errado deixa os solvers
	-- nascendo mortos. MONTADO, NÃO: a detecção GRAVA no ik_parameters.json e
	-- persistiria os ossos da criatura por cima dos seus.
	if not mounts.isWalking() then
		rig.bodyBonesChecked = true
	end
	if configui.getValue("body_autoDetectBones") ~= false and not rig.bodyBonesChecked then
		rig.bodyBonesChecked = true
		if detectBones(rig, false) then
			log("Ossos corrigidos — reconstruindo o corpo")
			uevrUtils.delay(200, rebuild) -- fora do callback de criação
			return
		end
	end

	applyShadowSetting()
	applyHeadVisibility()
	keepSourceMeshesAnimating(rig)
	detectLegBones(bodyMeshes[1])
	-- o valor de fábrica do Z automático, para devolver ao desmontar (seção 1b)
	rigCoupling = rig.coupling or 1
	-- depois das pernas: a cintura é achada excluindo os ossos delas (seção 1c)
	detectWaistBone(bodyMeshes[1])
	detectDiagArmBones(bodyMeshes[1])

	-- reaproveita as poses de dedo do perfil nas mãos do corpo
	rig:setAnimationsFromHandsParametersFile(buildAnimationTable())
	rig:initHandAnimations(rig.meshTemplates)

	logMilestone("Corpo criado com " .. #bodyMeshes .. " malha(s)")

	-- cobre também os caminhos que não passam pelo botão "Reconstruir corpo"
	rebuildWand()
end)

ik.registerOnDestroyCallback(function()
	currentRig = nil
	bodyMeshes = {}
end)

--------------------------------------------------------------------------
-- As mãos antigas (presas aos controles) e o corpo não podem coexistir: as duas
-- usam os mesmos IDs de animação e as mãos ficariam duplicadas.
--------------------------------------------------------------------------

-- Quem decide se as mãos existem é a global showHands, lida pelo main.lua a cada
-- poll: mexemos direto nela e nas malhas, e repetimos de tempos em tempos. NÃO
-- usamos configui.setValue("showHands", ...), que dispara o onUpdate do main.lua
-- num momento arbitrário. O checkbox "Show Hands" continua marcado na tela.
local function enforceHandsOff()
	if not isEnabled() then return end
	if configui.getValue("body_replaceHands") == false then return end

	if _G.showHands ~= false then
		_G.showHands = false
		log("'Show Hands' desligado — as mãos agora vêm do corpo")
	end

	if hands.exists() then
		log("Destruindo as mãos antigas presas aos controles")
		hands.destroyHands()
		hands.reset()
	end
end

-- Quando o corpo é desligado, devolve as mãos do perfil.
local function restoreHands()
	if _G.showHands == false then
		log("Religando 'Show Hands'")
		_G.showHands = true
	end
end

uevrUtils.setInterval(2000, function()
	local ok, err = pcall(enforceHandsOff)
	if not ok then
		log("Falha ao desligar as mãos: " .. tostring(err), LogLevel.Warning)
	end
end)

--------------------------------------------------------------------------
-- Refazer o corpo ao mexer no inventário (para a roupa nova aparecer)
--
-- O corpo é uma cópia das malhas, tirada quando o rig nasce. A tela de
-- equipamento é reconhecida pelo UIManager (UI na tela + Guia de Campo na aba 1)
-- e o corpo é refeito nas duas bordas — quem resolve é a de saída, quando a roupa
-- nova já existe. Ver LEIAME, "Roupa nova".
--------------------------------------------------------------------------
local uiManagerCache = nil
local lastInGearScreen = false

local function isInGearScreen()
	if uevrUtils.getValid(uiManagerCache) == nil then
		uiManagerCache = uevrUtils.find_first_of("Class /Script/Phoenix.UIManager")
	end
	local uiManager = uevrUtils.getValid(uiManagerCache)
	if uiManager == nil then return false end
	if uiManager.GetIsUIShown == nil or uiManager:GetIsUIShown() ~= true then return false end

	local widget = uevrUtils.getValid(uiManager.FieldGuideWidget)
	if widget == nil then return false end
	return widget.CurrentTabIndex == 1
end

uevrUtils.setInterval(200, function()
	local ok, err = pcall(function()
		local inGear = isInGearScreen()
		if inGear == lastInGearScreen then return end
		lastInGearScreen = inGear

		-- corpo desligado ou ainda não criado: não há o que refazer
		if not isEnabled() or currentRig == nil then return end

		logMilestone(inGear and "Equipamento aberto: refazendo o corpo"
			or "Equipamento fechado: refazendo o corpo com a roupa nova")
		rebuild()
	end)
	if not ok then
		log("Falha ao refazer o corpo no inventario: " .. tostring(err), LogLevel.Warning)
	end
end)

--------------------------------------------------------------------------
-- Painel de configuração
--------------------------------------------------------------------------

-- "Ativar corpo VR" e "Usar as maos do corpo" andam juntos nos dois sentidos: um
-- marcado sem o outro mostrava um estado que não existe. Sem laço infinito, cada
-- função só escreve quando o valor é DIFERENTE. Quem chama restoreHands /
-- enforceHandsOff é o handler do body_replaceHands.
local function syncReplaceHands(enabled)
	if configui.getValue("body_replaceHands") == enabled then return end
	configui.setValue("body_replaceHands", enabled)
end

local function syncBodyEnabled(enabled)
	if configui.getValue("body_enabled") == enabled then return end
	configui.setValue("body_enabled", enabled)
end

configui.onCreateOrUpdate("body_enabled", function(value)
	ik.setAutoCreateArms(value == true)
	syncReplaceHands(value == true)
	if value ~= true then
		rebuild()
		restoreHands()
	else
		uevrUtils.delay(1000, enforceHandsOff)
	end
end)

configui.onCreateOrUpdate("body_replaceHands", function(value)
	syncBodyEnabled(value == true)
	if value == false then
		restoreHands()
	else
		uevrUtils.delay(1000, enforceHandsOff)
	end
end)

configui.onCreateOrUpdate("body_shadow", function(value)
	applyShadowSetting()
end)

configui.onCreateOrUpdate("body_followViewDeadzone", function(value)
	bodyYaw.setMinAngularDeviation(value)
end)

--------------------------------------------------------------------------
-- PADRÕES DO PAINEL — a calibragem aprovada em jogo. Uma lista só serve de
-- initialValue e de alvo do botão "Restaurar padroes". Posição e rotação do corpo
-- não entram: dono único é o painel IK Dev Config (armadilha 8).
--------------------------------------------------------------------------
local PANEL_DEFAULTS = {
	body_devMode             = false,
	body_enabled             = true,
	body_replaceHands        = true,
	body_shadow              = true,
	body_onlyArms            = false,
	body_armsOffset          = { 0, 0, -15 },
	body_animate             = true,
	body_followCrouch        = true,
	body_headCamera          = true,
	body_headCameraHeight    = 9,
	body_gazeLean            = true,
	body_gazeLeanMax         = 25.6,
	body_followView          = true,
	body_followViewDeadzone  = 1,
	body_legOffset           = { 0, 9.5, 0 },
	body_mountArmsIK         = true,
	body_mountHipAlign       = true,
	body_mountHipSensitivity = 0,
	body_mountHipDeadzone    = 0,
	body_mountHipMaxYaw      = 0,
	body_mountSpineUpright   = 0.785,
	body_mountSpineRoll      = true,
	body_mountSpineTrim      = -1.45,
	body_autoDetectBones     = true,
}

-- Vetor vem do configui como struct (X/Y/Z) e o padrão é lista de três.
local function nearEnough(a, b)
	if type(a) ~= "number" or type(b) ~= "number" then return a == b end
	-- o painel guarda float e devolve 25.621999…, então == acusaria diferença num
	-- valor que para o jogador é o mesmo
	return math.abs(a - b) < 0.0005
end

local function sameAsDefault(current, wanted)
	if type(wanted) == "table" then
		if type(current) ~= "table" and type(current) ~= "userdata" then return false end
		local ok, cx, cy, cz = pcall(function()
			local x = current.X or current.x or current[1]
			local y = current.Y or current.y or current[2]
			local z = current.Z or current.z or current[3]
			return x, y, z
		end)
		if not ok then return false end
		return nearEnough(cx, wanted[1]) and nearEnough(cy, wanted[2]) and nearEnough(cz, wanted[3])
	end
	return nearEnough(current, wanted)
end

--------------------------------------------------------------------------
-- MODO DESENVOLVEDOR
--
-- Esconde os interruptores internos (todos já no ponto certo) e a aba "IK Dev
-- Config". É um `begin_group` com `isHidden`: o drawUI pula até o `end_group`
-- (configui.lua:614). A aba do IK é criada sempre; o modo só a mostra ou esconde,
-- pelo nome do arquivo de save.
--------------------------------------------------------------------------
local IK_DEV_PANEL_ID = "dev/ik_config_dev"

local function applyDevMode()
	local on = configui.getValue("body_devMode") == true
	configui.hideWidget("body_devGroup", not on)
	-- pcall: na primeira passada o painel do IK pode ainda não existir
	pcall(configui.hidePanel, IK_DEV_PANEL_ID, not on)
end

configui.onUpdate("body_devMode", applyDevMode)

-- SÓ ESCREVE O QUE ESTÁ DIFERENTE: setValue dispara os onUpdate sem comparar, e o
-- do body_onlyArms mexe no hide_body (armadilha 9). Cada valor no seu próprio
-- pcall e ordem fixa: um erro num onUpdate abortava o laço, em silêncio.
local RESET_ORDER = {
	"body_headCameraHeight", "body_gazeLeanMax", "body_followViewDeadzone",
	"body_legOffset", "body_armsOffset",
	"body_mountSpineUpright", "body_mountSpineTrim", "body_mountSpineRoll",
	"body_mountHipAlign", "body_mountHipSensitivity", "body_mountHipDeadzone",
	"body_mountHipMaxYaw", "body_mountArmsIK",
	"body_animate", "body_followCrouch", "body_followView",
	"body_headCamera", "body_gazeLean", "body_shadow", "body_autoDetectBones",
	"body_replaceHands", "body_enabled", "body_onlyArms", "body_devMode",
}

configui.onUpdate("body_resetDefaults", function()
	local changed, failed = 0, {}

	local function restore(id)
		local wanted = PANEL_DEFAULTS[id]
		if wanted == nil or sameAsDefault(configui.getValue(id), wanted) then return end
		local ok, err = pcall(configui.setValue, id, wanted)
		if ok then
			changed = changed + 1
		else
			table.insert(failed, id .. " (" .. tostring(err) .. ")")
		end
	end

	local done = {}
	for _, id in ipairs(RESET_ORDER) do
		done[id] = true
		restore(id)
	end
		-- rede de segurança: padrão fora da lista de ordem ainda é restaurado
	for id in pairs(PANEL_DEFAULTS) do
		if not done[id] then restore(id) end
	end

	logMilestone("Padroes restaurados: " .. changed .. " valor(es) mudado(s)")
	if #failed > 0 then
		logMilestone("Padroes que falharam: " .. table.concat(failed, ", "))
	end
end)

-- onUpdate (e não onCreateOrUpdate) de propósito: quem manda na posição do corpo
-- é o data/ik_parameters.json; o painel só grava quando o jogador mexe.
configui.onUpdate("body_onlyArms", function(value)
	setRigParam("hide_body", value == true)

	-- DESMARCAR cai no destroyAll do ik.lua:899 e o rig é recriado pelo temporizador
	-- de 1 s — a varredura espera o corpo novo existir (armadilha 9).
	uevrUtils.delay(1500, function()
		if currentRig == nil or #bodyMeshes == 0 then return end
		pcall(destroyGhostBodies, bodyMeshes)
	end)
end)

configui.onUpdate("body_rebuild", function()
	log("Reconstruindo o corpo")
	rebuild()
end)

-- Fique de pé, na altura em que você joga, e clique.
configui.onUpdate("body_recalibrate", function()
	resetHeightCalibration()
	logMilestone("Altura recalibrada")
end)

configui.onUpdate("body_detectBones", function()
	if currentRig == nil then
		log("Corpo não está criado", LogLevel.Warning)
		return
	end
	if detectBones(currentRig, true) then
		log("Ossos redetectados — reconstruindo o corpo")
		uevrUtils.delay(200, rebuild)
	else
		applyHeadVisibility()
	end
end)

-- Despeja no log.txt o estado que interessa quando a câmera ou a altura estão
-- erradas. Vai como Error de propósito: é para ser lido depois, no arquivo.
local function logDiagnostics()
	local function fmt(v)
		if v == nil then return "nil" end
		return string.format("(%.1f, %.1f, %.1f)", v.X or v.x or 0, v.Y or v.y or 0, v.Z or v.z or 0)
	end

	logMilestone("--- diagnostico ---")
	logMilestone("corpo criado: " .. tostring(currentRig ~= nil) .. ", malhas: " .. #bodyMeshes
		.. ", escondido (filtrado): " .. tostring(isBodyHidden())
		.. ", escondido (cru): " .. tostring(shouldHideBody()))
	logMilestone("headCamera marcado: " .. tostring(configui.getValue("body_headCamera"))
		.. ", ativo agora: " .. tostring(headCameraActive()))
	logMilestone("montaria: tipo=" .. tostring(mounts.getMountType())
		.. ", voando=" .. tostring(mounts.getIsFlying()))

	-- SOMENTE BRAÇOS: separa as três causas do "está noutra posição e pisca" — mais
	-- de uma cópia na lista = fantasma; coupling ~= 2 = o ik.lua ainda escreve o Z
	-- da cápsula; reposições > 0 = o jogo copiou a pose por cima e desfez o
	-- encolhimento.
	logMilestone("somente bracos: " .. tostring(configui.getValue("body_onlyArms"))
		.. ", coupling=" .. tostring(currentRig ~= nil and currentRig.coupling or "?")
		.. ", animando pela malha=" .. tostring(currentRig ~= nil and currentRig.wasAnimating == true)
		.. ", reposicoes do corpo escondido=" .. reapplyCount)

	local copies = collectPoseableCopies(bodyMeshes)
	logMilestone("copias PoseableMesh no pawn: " .. #copies .. " (esperado: " .. #bodyMeshes .. ")")
	for _, entry in ipairs(copies) do
		local loc = entry.component.K2_GetComponentLocation ~= nil
			and entry.component:K2_GetComponentLocation() or nil
		logMilestone("  " .. (entry.mine and "[do corpo] " or "[FANTASMA] ")
			.. shortName(entry.component) .. " em " .. fmt(loc))
	end

	local rootComponent = uevrUtils.getValid(pawn, {"RootComponent"})
	if rootComponent ~= nil then
		logMilestone("pawn root: " .. fmt(rootComponent:K2_GetComponentLocation())
			.. ", CapsuleHalfHeight: " .. tostring(rootComponent.CapsuleHalfHeight))
	end

	local hmd = controllers.getController(2)
	if uevrUtils.getValid(hmd) ~= nil then
		logMilestone("HMD: " .. fmt(hmd:K2_GetComponentLocation()))
	end

	logMilestone("altura: quadril abaixado=" .. string.format("%.1f", hipDrop)
		.. ", deslocamento do quadril=" .. string.format("%.1f", hipShift.Z)
		.. ", quadril de pe (origem)=" .. (standingSourceHipZ and string.format("%.1f", standingSourceHipZ) or "nil")
		.. ", quadril na pose de referencia=" .. (referenceHip and string.format("%.1f", referenceHip.Z) or "nil"))

	local source = getSourceMesh()
	if uevrUtils.getValid(source) ~= nil then
		logMilestone("malha de origem no mundo: " .. fmt(source:K2_GetComponentLocation()))
		-- É desta rotação que sai a reclinada do tronco montado. Pitch e roll perto de
		-- zero com o corpo aparecendo deitado = a inclinação vem de outro lugar.
		local srcRot = source:K2_GetComponentRotation()
		if srcRot ~= nil then
			logMilestone(string.format(
				"rotacao da malha de origem: pitch=%.1f, yaw=%.1f, roll=%.1f",
				srcRot.Pitch, srcRot.Yaw, srcRot.Roll))
		end
	end

	logMilestone("coluna: endireitar=" .. tostring(configui.getValue("body_mountSpineUpright"))
		.. ", lateral=" .. tostring(configui.getValue("body_mountSpineRoll"))
		.. ", ajuste fino=" .. tostring(configui.getValue("body_mountSpineTrim"))
		.. ", corrigindo agora=" .. tostring(computeSpineCorrection() ~= nil))

	-- OLHAR PARA BAIXO: o yaw diz se você está dentro da janela de 120°, o pitch
	-- quanto olha para baixo. Tudo zero com yaw grande é a janela agindo.
	local relYaw, relPitch = getGazeInBodySpace()
	logMilestone("olhar: yaw=" .. (relYaw ~= nil and string.format("%.0f", relYaw) or "?")
		.. ", pitch=" .. (relPitch ~= nil and string.format("%.0f", relPitch) or "?")
		.. ", empurrao=" .. string.format("%.1f", gazeLeanDistance())
		.. " cm, marcado=" .. tostring(configui.getValue("body_gazeLean")))

	local mesh = bodyMeshes[1]
	if uevrUtils.getValid(mesh) ~= nil then
		logMilestone("corpo relativo: " .. fmt(mesh.RelativeLocation)
			.. ", mundo: " .. fmt(mesh:K2_GetComponentLocation()))

		-- Alturas lado a lado, para separar "o corpo está no lugar errado" de "há mais
		-- de um corpo". A malha do jogo diz onde os pés realmente estão.
		if rootComponent ~= nil and uevrUtils.getValid(source) ~= nil then
			local srcLoc = source:K2_GetComponentLocation()
			local rootLoc = rootComponent:K2_GetComponentLocation()
			if srcLoc ~= nil and rootLoc ~= nil then
				logMilestone(string.format("altura: malha do jogo-root=%.1f, corpo-root=%.1f, Z de Posicao=%s",
					srcLoc.Z - rootLoc.Z,
					mesh:K2_GetComponentLocation().Z - rootLoc.Z,
					tostring(currentRig ~= nil and currentRig.meshLocationOffset ~= nil
						and currentRig.meshLocationOffset.Z or "?")))
			end
		end

		-- DOIS CORPOS: o ik.lua guarda os rigs numa LISTA e o getCurrentMesh devolve o
		-- do ÚLTIMO criado; o body.lua rastreia o que veio no callback de criação.
		-- Malhas diferentes = mais de um rig vivo.
		local ikMesh = ik.getCurrentMesh and ik.getCurrentMesh(1) or nil
		local ikName = uevrUtils.getValid(ikMesh) ~= nil and shortName(ikMesh) or "nil"
		logMilestone("rig rastreado x rig do ik.lua: " .. shortName(mesh) .. " / " .. ikName
			.. ", sao o mesmo: " .. tostring(ikMesh == mesh))
		logMilestone("osso da cabeca '" .. headBone .. "' no mundo: " .. fmt(getHeadWorldLocation()))

			-- Quadril: na origem é a pose animada do jogo. Com "acompanha o agachamento"
			-- ligado os dois batem; desligado, a diferença mostra o quanto agachou.
		if legAnchorFName ~= nil and currentRig ~= nil then
			if uevrUtils.getValid(source) ~= nil then
				local sourceHip = source:GetSocketTransform(legAnchorFName, RTS_COMPONENT)
				local targetHip = mesh:GetBoneTransformByName(legAnchorFName, EBoneSpaces.ComponentSpace)
				if sourceHip ~= nil and targetHip ~= nil then
					logMilestone("quadril (espaco de componente) origem: " .. fmt(sourceHip.Translation)
						.. ", copia: " .. fmt(targetHip.Translation))
				end
			end
		end
	end
	logMilestone("--- fim ---")
end

configui.onUpdate("body_diagnostics", function()
	local ok, err = pcall(logDiagnostics)
	if not ok then
		log("Falha no diagnostico: " .. tostring(err), LogLevel.Warning)
	end
end)

configui.onUpdate("body_logBones", function()
	local mesh = bodyMeshes[1]
	if uevrUtils.getValid(mesh) == nil then
		log("Corpo não está criado", LogLevel.Warning)
		return
	end
	animation.logBoneNames(mesh)
end)

configui.create({
	{
		panelLabel = "Corpo VR",
		saveFile = "config_body",
		layout = {
			{ widgetType = "text", label = "Corpo completo em primeira pessoa (tronco, bracos, maos, pernas e pes)." },
			{ widgetType = "spacing" },
			{ widgetType = "checkbox", id = "body_enabled", label = "Ativar corpo VR", initialValue = PANEL_DEFAULTS.body_enabled },
			{ widgetType = "checkbox", id = "body_replaceHands", label = "Usar as maos do corpo (desliga Show Hands)", initialValue = PANEL_DEFAULTS.body_replaceHands },
			{ widgetType = "checkbox", id = "body_shadow", label = "Corpo projeta sombra", initialValue = PANEL_DEFAULTS.body_shadow },
			{ widgetType = "checkbox", id = "body_onlyArms", label = "Somente bracos (esconde tronco e pernas)", initialValue = PANEL_DEFAULTS.body_onlyArms },
			{ widgetType = "text", label = "  Neste modo os ombros ficam presos a SUA cabeca: 'Posicao' e a altura da capsula" },
			{ widgetType = "text", label = "  nao valem (elas poem os pes no chao, e aqui nao ha pes). Calibre so o campo abaixo." },
			{
				widgetType = "drag_float3",
				id = "body_armsOffset",
				label = "  Altura dos bracos (X frente, Y direita, Z altura) — so em 'Somente bracos'",
				speed = 0.5,
				range = { -100, 100 },
				initialValue = PANEL_DEFAULTS.body_armsOffset,
			},
			{ widgetType = "text", label = "    Z e a distancia dos seus olhos ate os ombros; mais negativo desce os bracos." },
			{ widgetType = "spacing" },
			{ widgetType = "button", id = "body_resetDefaults", label = "Restaurar padroes" },
			{ widgetType = "text", label = "  Devolve esta aba inteira a calibragem testada em jogo. Nao mexe na 'Posicao'" },
			{ widgetType = "text", label = "  nem na 'Rotacao', que sao do painel IK Dev Config." },
			{ widgetType = "spacing" },
			{ widgetType = "text", label = "Vista" },
			{
				widgetType = "drag_float",
				id = "body_headCameraHeight",
				label = "  Altura dos olhos acima do osso da cabeca",
				speed = 0.5,
				range = { -100, 100 },
				initialValue = PANEL_DEFAULTS.body_headCameraHeight,
			},
			{
				widgetType = "slider_float",
				id = "body_gazeLeanMax",
				label = "  Quanto a camera avanca ao olhar para baixo (cm)",
				speed = 0.5,
				range = { 0, 40 },
				initialValue = PANEL_DEFAULTS.body_gazeLeanMax,
			},
			{ widgetType = "spacing" },
			{ widgetType = "text", label = "Pernas: empurra coxa, canela, pe e dedos juntos." },
			{ widgetType = "text", label = "  Atencao: aqui os eixos sao os do esqueleto, nao os seus — Y e a FRENTE." },
			{
				widgetType = "drag_float3",
				id = "body_legOffset",
				label = "Ajuste das pernas (X esquerda, Y frente, Z altura)",
				speed = 0.5,
				range = { -100, 100 },
				initialValue = PANEL_DEFAULTS.body_legOffset,
			},
			{ widgetType = "spacing" },
			{ widgetType = "text", label = "Postura na montaria (so criaturas; vassoura nao entra)" },
			{ widgetType = "text", label = "  Montado, o corpo copia a rotacao da malha do jogo inteira, e ela vem deitada" },
			{ widgetType = "text", label = "  para tras — e o tronco vai junto. Isto gira SO a cintura de volta, entao as" },
			{ widgetType = "text", label = "  pernas ficam onde a animacao as pos, nos estribos." },
			{
				widgetType = "slider_float",
				id = "body_mountSpineUpright",
				label = "    Endireitar a coluna",
				speed = 0.01,
				range = { 0, 1 },
				initialValue = PANEL_DEFAULTS.body_mountSpineUpright,
			},
			{ widgetType = "text", label = "      0 = pose original do jogo.  1 = coluna na vertical do mundo." },
			{
				widgetType = "slider_float",
				id = "body_mountSpineTrim",
				label = "    Ajuste fino (graus)",
				speed = 0.5,
				range = { -45, 45 },
				initialValue = PANEL_DEFAULTS.body_mountSpineTrim,
			},
			{ widgetType = "text", label = "      Positivo deita para tras, negativo inclina para a frente. Vale sozinho," },
			{ widgetType = "text", label = "      mesmo com o controle de cima em 0." },
			{ widgetType = "text", label = "    A cabeca e osso da coluna e sobe junto, entao a camera sobe junto com ela." },
			{ widgetType = "text", label = "    Reposicione a vista pela 'Altura dos olhos', mais acima." },
			{ widgetType = "spacing" },
			{
				widgetType = "checkbox",
				id = "body_devMode",
				label = "Modo desenvolvedor — nao mexer",
				initialValue = PANEL_DEFAULTS.body_devMode,
			},
			{ widgetType = "text", label = "  Mostra os interruptores internos e a aba 'IK Dev Config'. Todos ja estao no" },
			{ widgetType = "text", label = "  ponto certo; desmarcar qualquer um quebra alguma parte do corpo." },
			{ widgetType = "begin_group", id = "body_devGroup", isHidden = true },
			{
				widgetType = "checkbox",
				id = "body_headCamera",
				label = "  Camera atracada a cabeca do corpo",
				initialValue = PANEL_DEFAULTS.body_headCamera,
			},
			{ widgetType = "text", label = "    A camera vai ate a cabeca em vez de o corpo ir atras da camera. Vale a pe" },
			{ widgetType = "text", label = "    e em toda montaria. A rotacao continua sendo do headset." },
			{
				widgetType = "checkbox",
				id = "body_gazeLean",
				label = "  Camera vai para a frente ao olhar para baixo",
				initialValue = PANEL_DEFAULTS.body_gazeLean,
			},
			{ widgetType = "text", label = "    So dentro de 120 graus da frente do corpo; olhando para tras, zero." },
			{
				widgetType = "checkbox",
				id = "body_followView",
				label = "  Corpo acompanha a visao (giro)",
				initialValue = PANEL_DEFAULTS.body_followView,
			},
			{
				widgetType = "slider_int",
				id = "body_followViewDeadzone",
				label = "    Angulo para o corpo comecar a virar",
				speed = 1.0,
				range = { 1, 90 },
				initialValue = PANEL_DEFAULTS.body_followViewDeadzone,
			},
			{
				widgetType = "checkbox",
				id = "body_mountHipAlign",
				label = "  Na montaria, tronco acompanha o headset (so criaturas)",
				initialValue = PANEL_DEFAULTS.body_mountHipAlign,
			},
			{ widgetType = "text", label = "    Gira o osso da cintura, logo acima do quadril. Nada se move de lugar." },
			{ widgetType = "text", label = "    As pernas ficam onde a animacao as pos. Vassoura nao entra." },
			{
				widgetType = "slider_float",
				id = "body_mountHipSensitivity",
				label = "    Sensibilidade",
				speed = 0.01,
				range = { 0, 1 },
				initialValue = PANEL_DEFAULTS.body_mountHipSensitivity,
			},
			{
				widgetType = "slider_int",
				id = "body_mountHipDeadzone",
				label = "    Angulo para comecar a girar",
				speed = 1.0,
				range = { 0, 60 },
				initialValue = PANEL_DEFAULTS.body_mountHipDeadzone,
			},
			{
				widgetType = "slider_int",
				id = "body_mountHipMaxYaw",
				label = "    Limite do giro (graus)",
				speed = 1.0,
				range = { 0, 90 },
				initialValue = PANEL_DEFAULTS.body_mountHipMaxYaw,
			},
			{
				widgetType = "checkbox",
				id = "body_animate",
				label = "  Animar as pernas pelo jogo",
				initialValue = PANEL_DEFAULTS.body_animate,
			},
			{ widgetType = "text", label = "    So da cintura para baixo. Tronco, cabeca e dedos continuam como estavam." },
			{
				widgetType = "checkbox",
				id = "body_followCrouch",
				label = "  Corpo acompanha o agachamento do jogo",
				initialValue = PANEL_DEFAULTS.body_followCrouch,
			},
			{ widgetType = "text", label = "    Sem isso, agachar levanta os pes em vez de baixar o corpo." },
			{
				widgetType = "checkbox",
				id = "body_mountArmsIK",
				label = "  Na montaria, bracos pelo IK",
				initialValue = PANEL_DEFAULTS.body_mountArmsIK,
			},
			{ widgetType = "text", label = "    Sem isso a mao congela no hipogrifo: o ik.lua mede a altura pela capsula do" },
			{ widgetType = "text", label = "    pawn, que montado e A CRIATURA, e o alvo sai do alcance do braco." },
			{
				widgetType = "checkbox",
				id = "body_mountSpineRoll",
				label = "  Endireitar tambem a inclinacao lateral (montaria)",
				initialValue = PANEL_DEFAULTS.body_mountSpineRoll,
			},
			{ widgetType = "text", label = "    Desmarque para continuar deitando junto com a criatura nas curvas." },
			{
				widgetType = "checkbox",
				id = "body_autoDetectBones",
				label = "  Detectar ossos automaticamente",
				initialValue = PANEL_DEFAULTS.body_autoDetectBones,
			},
			{ widgetType = "text", label = "    Corrige nomes de osso que nao existem na malha. Nome que ja funciona fica." },
			{ widgetType = "end_group" },
			{ widgetType = "spacing" },
			{ widgetType = "button", id = "body_recalibrate", label = "Recalibrar altura" },
			{ widgetType = "same_line" },
			{ widgetType = "button", id = "body_rebuild", label = "Reconstruir corpo" },
			{ widgetType = "same_line" },
			{ widgetType = "button", id = "body_detectBones", label = "Detectar ossos agora" },
			{ widgetType = "same_line" },
			{ widgetType = "button", id = "body_logBones", label = "Listar ossos no log" },
			{ widgetType = "same_line" },
			{ widgetType = "button", id = "body_diagnostics", label = "Diagnostico no log" },
			{ widgetType = "spacing" },
			{ widgetType = "text", label = "Ajuste fino de bracos e maos: aba 'IK Dev Config'.", wrapped = true },
		},
	},
})

ik.init(SHOW_DEV_UI, LogLevel.Info)

-- Depois do ik.init, que é quem cria a aba "IK Dev Config". Num onCreateOrUpdate
-- isto dispararia durante o configui.create acima, sem o painel do IK existir.
applyDevMode()

-- Depois do registro do main.lua, que roda no carregamento dos scripts: qualquer
-- callback de tick já satisfaz isso. O delay é só para não disputar o frame de
-- inicialização.
uevrUtils.delay(2000, registerHeadCamera)

-- Carregado já dentro de um nível, o corpo é criado pelo temporizador interno do
-- módulo IK (1x por segundo, enquanto não existir).
uevrUtils.registerLevelChangeCallback(function()
	uevrUtils.delay(3000, applyHandsSetting)
	registerHeadCamera() -- protegido por flag: registra uma vez só
end)
