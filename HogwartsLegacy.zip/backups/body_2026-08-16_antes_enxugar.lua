--[[
	body.lua — Corpo VR (IK) para Hogwarts Legacy
	--------------------------------------------------------------------------
	Cria um corpo completo em primeira pessoa (tronco, braços, mãos, pernas e
	pés) a partir do próprio esqueleto do personagem, usando o módulo de
	Inverse Kinematics da uevrlib (libs/ik.lua).

	Como funciona (mesmo esquema do perfil do Silent Hill f):
	  1. O módulo IK faz uma cópia PoseableMeshComponent das malhas do
	     personagem (corpo + roupas) e prende essa cópia no RootComponent do
	     pawn, deslocada para baixo até os pés.
	  2. Dois solvers de Two Bone IK giram RightArm/RightForeArm/RightHand e
	     LeftArm/LeftForeArm/LeftHand para que as mãos acompanhem os controles.
	  3. As poses de dedo do próprio perfil (helpers/hand_animations.lua) são
	     reaproveitadas nas mãos do corpo, então gatilho/grip continuam
	     animando os dedos.

	Os valores numéricos (altura, rotação, alinhamento da mão) ficam em
	data/ik_parameters.json e podem ser ajustados ao vivo:
	  - no painel "Corpo VR" (ajustes principais), ou
	  - no painel "IK Dev Config" (ajuste fino de ossos e offsets de mão).

	O PORQUÊ de cada decisão — e a lista de armadilhas que não podem voltar —
	está no LEIAME_CORPO_VR.md, ao lado deste arquivo. Aqui os comentários só
	descrevem o que o código faz.
]]--

local uevrUtils      = require("libs/uevr_utils")
local configui       = require("libs/configui")
local animation      = require("libs/animation")
local controllers    = require("libs/controllers")
local hands          = require("libs/hands")
local ik             = require("libs/ik")
local bodyYaw        = require("libs/body_yaw")
local handAnimations = require("helpers/hand_animations")
local mounts         = require("helpers/mounts")
require("libs/enums/unreal")

-- EVisibilityBasedAnimTickOption::AlwaysTickPoseAndRefreshBones — não está no
-- enums/unreal.lua da lib, então fica aqui o valor cru.
local ALWAYS_TICK_POSE_AND_REFRESH_BONES = 0

-- Deixe true para ter o painel "IK Dev Config" na UI do UEVR (ajuste fino).
local SHOW_DEV_UI = true

-- Osso da cabeça. É só o palpite inicial: se não existir na malha, a detecção
-- automática procura o nome certo.
local HEAD_BONE = "Head"

-- Componentes filhos de Pawn.Mesh que nunca devem entrar no corpo.
-- (nomes parciais, sem diferenciar maiúsculas/minúsculas)
local EXCLUDED_MESHES = { "preview", "shadowproxy" }

local currentRig    = nil   -- instância do rig de IK ativa
local bodyMeshes    = {}    -- cópias PoseableMesh criadas pelo IK
local meshTags      = {}    -- tags de animação encontradas na última criação
local headBone      = HEAD_BONE -- nome real do osso da cabeça nesta malha

local function log(text, level)
	uevrUtils.print("[body] " .. text, level or LogLevel.Info)
end

-- Sem isto NADA de Lua chega no log.txt: o uevr_utils nasce com
-- logToFile = false (uevr_utils.lua:1802) e o print() cru do Lua vai só para a
-- janela de console do UEVR, não para o arquivo — é por isso que procurar
-- "[body]" no log não devolvia nada, e nem o "UEVR is now ready" do main.lua
-- está lá. Ligar isto NÃO enche o log: o filtro de nível continua valendo e o
-- padrão é Error, então só passam erros de verdade e os marcos abaixo.
uevrUtils.setLogToFile(true)

-- Marcos que PRECISAM aparecer no log.txt. O uevrUtils.print só escreve quando
-- logLevel <= currentLogLevel, e o padrão do perfil é Error: mensagem Info não
-- chega no arquivo. Estes são poucos, acontecem uma vez cada e são exatamente o
-- que se lê quando algo não funciona, então vão como Error de propósito.
local function logMilestone(text)
	uevrUtils.print("[body] " .. text, LogLevel.Error)
end

local function isEnabled()
	return configui.getValue("body_enabled") == true
end

--------------------------------------------------------------------------
-- Seleção das malhas que formam o corpo
--------------------------------------------------------------------------

local function shortName(component)
	local fullName = component:get_full_name()
	return fullName:match("([^%.]+)$") or fullName
end

local function isExcluded(name)
	local lowerName = string.lower(name)
	for _, excluded in ipairs(EXCLUDED_MESHES) do
		if string.find(lowerName, excluded, 1, true) ~= nil then
			return true
		end
	end
	return false
end

local function isSkeletalMesh(component)
	if uevrUtils.getValid(component) == nil then return false end
	local class = uevrUtils.get_class("Class /Script/Engine.SkeletalMeshComponent")
	if class ~= nil and component.is_a ~= nil and not component:is_a(class) then
		return false
	end
	-- só interessa se realmente tem uma malha carregada (UE4 x UE5)
	return uevrUtils.getValid(component, {"SkeletalMesh"}) ~= nil
		or uevrUtils.getValid(component, {"SkeletalMeshAsset"}) ~= nil
end

--------------------------------------------------------------------------
-- A malha viva que serve de origem para o corpo VR.
--
-- Montado numa criatura o pawn é a CRIATURA, então a malha tem de vir do
-- RiderCharacter: o temporizador do ik.lua recria o corpo 1x por segundo e, se
-- pegar `pawn.Mesh` no meio de um voo, o corpo VR vira o bicho (aconteceu em
-- 06/08/2026 — 142 ossos, esqueleto de asas). A pé nada muda.
--------------------------------------------------------------------------
local function getPlayerBodyMesh(shouldLog)
	local playerPawn = uevrUtils.getValid(pawn)
	local baseMesh = playerPawn ~= nil and uevrUtils.getValid(playerPawn, {"Mesh"}) or nil

	if playerPawn ~= nil and not mounts.isWalking() then
		local rider = uevrUtils.getValid(mounts.getMountPawn(playerPawn))
		local riderMesh = rider ~= nil and uevrUtils.getValid(rider, {"Mesh"}) or nil
		if riderMesh ~= nil and riderMesh ~= baseMesh then
			baseMesh = riderMesh
			if shouldLog then
				logMilestone("Montado: corpo criado a partir da malha do personagem, nao da criatura")
			end
		end
	end

	return baseMesh
end

-- Chamada pelo libs/ik.lua quando o parâmetro "animation_mesh" está como "Custom".
-- Tem que ser a mesma malha viva usada como origem do corpo: o
-- CopyPoseFromSkeletalComponent do ik.lua exige esqueletos iguais, então apontar
-- para a criatura montada deixaria o corpo congelado na pose padrão.
function getCustomAnimationIKComponent(rigID)
	return getPlayerBodyMesh(false)
end

-- Chamada pelo libs/ik.lua quando o parâmetro "mesh" está como "Custom".
-- Retorna a lista de malhas que serão copiadas para formar o corpo.
-- A primeira da lista precisa ser a malha com o esqueleto completo (Pawn.Mesh),
-- porque é ela que os solvers usam como referência.
function getCustomIKComponent(rigID)
	meshTags = {}

	local baseMesh = getPlayerBodyMesh(true)

	if baseMesh == nil then
		log("Pawn.Mesh indisponível, corpo não foi criado", LogLevel.Warning)
		return {}
	end

	local templates = {}
	table.insert(templates, { descriptor = "Pawn.Mesh", instance = baseMesh, animation = "Body" })
	meshTags["Body"] = true

	-- As malhas filhas (roupa, luvas, braços) entram SEMPRE. Existiu aqui um
	-- combo "Malhas" com um modo "Somente Pawn.Mesh"; foi removido em 11/08/2026,
	-- opção e código — quem decide de qual malha o corpo sai é o parâmetro "mesh"
	-- do painel IK Dev Config, e ter dois donos para isso é o defeito de sempre.
	do
		local children = baseMesh.AttachChildren
		if children ~= nil then
			for _, child in ipairs(children) do
				if isSkeletalMesh(child) then
					local name = shortName(child)
					if isExcluded(name) then
						log("Malha ignorada: " .. name)
					else
						local tag = nil
						if string.find(name, "Arm") ~= nil then
							tag = "Arms"
						elseif string.find(name, "Glove") ~= nil then
							tag = "Gloves"
						end
						if tag ~= nil and meshTags[tag] == true then
							tag = nil -- só a primeira malha de cada tipo recebe as animações de dedo
						end
						if tag ~= nil then meshTags[tag] = true end

						table.insert(templates, {
							descriptor = "Pawn.Mesh(" .. name .. ")",
							instance = child,
							animation = tag,
							optional = true,
						})
						log("Malha do corpo: " .. name .. (tag ~= nil and (" [" .. tag .. "]") or ""))
					end
				end
			end
		end
	end

	log("Total de malhas no corpo: " .. #templates)
	return templates
end

--------------------------------------------------------------------------
-- Animação dos dedos reaproveitando as poses do perfil
--------------------------------------------------------------------------

-- O módulo hands_animation monta os IDs como "<mão>_<alvo>", então os alvos
-- precisam bater com o sufixo do ID: "hand", "glove", "body".
local function buildAnimationTable()
	local profile = {}
	local targets = { Body = "body", Arms = "hand", Gloves = "glove" }
	for tag, target in pairs(targets) do
		if meshTags[tag] == true then
			profile[tag] = {
				Left  = { AnimationID = "left_"  .. target },
				Right = { AnimationID = "right_" .. target },
			}
		end
	end
	return { animations = { Shared = handAnimations }, profiles = { Main = profile } }
end

--------------------------------------------------------------------------
-- Detecção automática dos ossos
--
-- Cada jogo nomeia os ossos do seu jeito (RightHand, hand_r, Bip01_R_Hand...)
-- e o ik.lua descarta o solver em silêncio quando o nome não existe na malha
-- (ele exige que o osso tenha 3 gerações de pais). Então, antes de aceitar o
-- corpo, conferimos os nomes contra a malha real e corrigimos o que estiver
-- errado. Nomes que já funcionam nunca são tocados.
--------------------------------------------------------------------------

-- palavras que descartam um osso como sendo a mão (dedos e ossos auxiliares)
local NOT_A_HAND = {
	"index", "middle", "ring", "pinky", "thumb", "finger", "twist", "roll",
	"ik", "attach", "socket", "weapon", "prop", "end", "tip", "ctrl", "helper",
}

local NOT_A_HEAD = { "top", "end", "attach", "socket", "ik", "ctrl", "helper", "hat", "wear" }

-- nomes exatos mais comuns, em ordem de preferência (minúsculas)
local HAND_NAMES = {
	[Handed.Right] = { "righthand", "hand_r", "r_hand", "hand_right", "bip01 r hand", "bip01_r_hand", "mixamorig:righthand" },
	[Handed.Left]  = { "lefthand",  "hand_l", "l_hand", "hand_left",  "bip01 l hand", "bip01_l_hand", "mixamorig:lefthand"  },
}

local HEAD_NAMES = { "head", "bip01 head", "bip01_head", "mixamorig:head", "b_head", "head_01" }

local function toBoneSet(names)
	local set = {}
	for _, name in ipairs(names) do
		set[string.lower(name)] = name
	end
	return set
end

local function containsAny(lowerName, words)
	for _, word in ipairs(words) do
		if string.find(lowerName, word, 1, true) ~= nil then return true end
	end
	return false
end

-- separadores usados pelas convenções de nome: hand_r, hand.r, hand-r, "Bip01 R Hand"
local SEPARATOR = "[_%.%-%s]"

local function hasSideMarker(lowerName, side)
	local word, letter = "left", "l"
	if side == Handed.Right then word, letter = "right", "r" end
	return string.find(lowerName, word, 1, true) ~= nil
		or string.match(lowerName, SEPARATOR .. letter .. "$") ~= nil
		or string.match(lowerName, SEPARATOR .. letter .. SEPARATOR) ~= nil
end

-- Procura o osso da mão: primeiro pelos nomes conhecidos, depois por
-- qualquer osso que contenha "hand" (ou "wrist") do lado certo. Entre vários
-- candidatos vence o nome mais curto, que é sempre a raiz da mão.
local function detectHandBone(names, set, side)
	for _, candidate in ipairs(HAND_NAMES[side]) do
		if set[candidate] ~= nil then return set[candidate] end
	end

	for _, keyword in ipairs({ "hand", "wrist" }) do
		local best = nil
		for _, name in ipairs(names) do
			local lower = string.lower(name)
			if string.find(lower, keyword, 1, true) ~= nil
				and not containsAny(lower, NOT_A_HAND)
				and hasSideMarker(lower, side)
				and (best == nil or #name < #best)
			then
				best = name
			end
		end
		if best ~= nil then return best end
	end

	return nil
end

local function detectHeadBone(names, set)
	for _, candidate in ipairs(HEAD_NAMES) do
		if set[candidate] ~= nil then return set[candidate] end
	end
	local best = nil
	for _, name in ipairs(names) do
		local lower = string.lower(name)
		if string.find(lower, "head", 1, true) ~= nil
			and not containsAny(lower, NOT_A_HEAD)
			and (best == nil or #name < #best)
		then
			best = name
		end
	end
	return best
end

-- Cadeia do osso até a raiz: {osso, pai, avô, ...}. Versão com limite — a
-- uevrUtils.getAncestorBones roda um while sem teto e um esqueleto com
-- hierarquia estranha travaria o jogo.
local function getBoneChain(mesh, boneName, maxDepth)
	local chain = { boneName }
	local current = boneName
	for _ = 1, (maxDepth or 6) do
		local parent = mesh:GetParentBone(current)
		if parent == nil then break end
		parent = parent:to_string()
		if parent == "" or parent == "None" or parent == current then break end
		table.insert(chain, parent)
		current = parent
	end
	return chain
end

-- Corrige os ossos de um solver. Devolve true se mudou alguma coisa.
-- A cadeia braço → antebraço → mão sai da própria hierarquia da malha, então
-- só a mão precisa ser adivinhada.
local function fixSolverBones(rig, mesh, names, set, solverId, solverParams)
	local side = Handed.Right
	if solverParams["end_control_type"] == 0 then side = Handed.Left end

	local endBone = solverParams["end_bone"] or ""
	if endBone ~= "" and set[string.lower(endBone)] ~= nil then
		return false -- o nome configurado existe na malha, não mexe
	end

	local detected = detectHandBone(names, set, side)
	-- se um lado foi achado e o outro não, espelha o nome
	if detected == nil then
		local other = detectHandBone(names, set, side == Handed.Right and Handed.Left or Handed.Right)
		if other ~= nil then
			detected = uevrUtils.findOppositeBone(other, side == Handed.Right, names)
		end
	end

	if detected == nil then
		log("Não achei o osso da mão " .. (side == Handed.Right and "direita" or "esquerda")
			.. " para o solver '" .. tostring(solverId) .. "'. Use 'Listar ossos no log' e "
			.. "escolha na aba IK Dev Config.", LogLevel.Warning)
		return false
	end

	local chain = getBoneChain(mesh, detected, 5)
	if #chain < 3 then
		log("Osso '" .. detected .. "' não tem antebraço e braço acima dele, ignorado", LogLevel.Warning)
		return false
	end

	log("Solver '" .. tostring(solverId) .. "': usando " .. chain[3] .. " -> " .. chain[2] .. " -> " .. chain[1])
	rig:setConfigParameter({ "solvers", solverId, "end_bone" }, chain[1], true)
	rig:setConfigParameter({ "solvers", solverId, "joint_bone" }, chain[2], true)
	rig:setConfigParameter({ "solvers", solverId, "start_bone" }, chain[3], true)

	-- ombro e espinha (usados só pelo modo "Somente braços") saem da mesma cadeia
	local shoulderKey = side == Handed.Right and "right_shoulder_bone_name" or "left_shoulder_bone_name"
	if chain[4] ~= nil then
		rig:setConfigParameter(shoulderKey, chain[4], true)
		if chain[5] ~= nil then
			rig:setConfigParameter("spine_bone_name", chain[5], true)
		end
	end

	return true
end

-- Devolve true se algum osso foi corrigido (nesse caso o corpo é reconstruído).
local function detectBones(rig, force)
	local mesh = bodyMeshes[1]
	if uevrUtils.getValid(mesh) == nil then return false end

	local names = uevrUtils.getBoneNames(mesh)
	if names == nil or #names == 0 then
		log("A malha do corpo não devolveu nenhum osso", LogLevel.Warning)
		return false
	end
	local set = toBoneSet(names)

	-- cabeça (não faz parte do rig, aplica na hora)
	if set[string.lower(headBone)] == nil or force then
		local detectedHead = detectHeadBone(names, set)
		if detectedHead ~= nil then
			if detectedHead ~= headBone then
				log("Osso da cabeça: " .. detectedHead)
			end
			headBone = detectedHead
		else
			log("Não achei o osso da cabeça; 'Esconder a cabeça' não vai funcionar", LogLevel.Warning)
		end
	end

	-- braços: lê a configuração gravada para saber quais solvers existem
	-- (não dá para ler do rig: quando o nome do osso está errado o ik.lua
	--  descarta o solver e ele nem aparece em rig.activeSolvers)
	if json == nil then return false end
	local params = json.load_file("ik_parameters.json")
	local rigParams = params ~= nil and params[rig.rigId or ""] or nil
	local solvers = rigParams ~= nil and rigParams.solvers or nil
	if solvers == nil then return false end

	local changed = false
	for solverId, solverParams in pairs(solvers) do
		if force then solverParams["end_bone"] = "" end
		if fixSolverBones(rig, mesh, names, set, solverId, solverParams) then
			changed = true
		end
	end
	return changed
end

--------------------------------------------------------------------------
-- Visibilidade
--------------------------------------------------------------------------

-- Roda a cada frame quando a animação do corpo está ligada, então usa o struct
-- reutilizável: é o mesmo vetor para todas as malhas do laço, consumido na hora.
--
-- SEMPRE ATIVO (10/08/2026, a pedido do Renan): o checkbox "Esconder a cabeca"
-- saiu do painel. Em primeira pessoa a câmera fica DENTRO da cabeça — mostrá-la
-- só rende o interior do crânio na cara do jogador, então nunca houve motivo
-- real para desligar. O osso é encolhido (escala 0,001), não movido: a POSIÇÃO
-- dele continua valendo, e é dela que sai a câmera atracada à cabeça.
local function applyHeadVisibility()
	local scale = uevrUtils.vector(0.001, 0.001, 0.001, true)
	for _, mesh in ipairs(bodyMeshes) do
		if uevrUtils.getValid(mesh) ~= nil and mesh.SetBoneScaleByName ~= nil then
			mesh:SetBoneScaleByName(uevrUtils.fname_from_string(headBone), scale, EBoneSpaces.ComponentSpace)
		end
	end
end

local function applyShadowSetting()
	local castShadow = configui.getValue("body_shadow") == true
	for _, mesh in ipairs(bodyMeshes) do
		if uevrUtils.getValid(mesh) ~= nil then
			mesh.bCastDynamicShadow = castShadow
			-- BoundsScale grande evita que o corpo seja descartado pelo frustum
			-- quando a origem da malha (nos pés) sai do campo de visão. O ik.lua
			-- já põe 16 na criação; reafirmamos porque é barato e é o tipo de
			-- coisa que, se falhar, o sintoma é o corpo sumindo.
			mesh.BoundsScale = 16.0
			-- bRenderInDepthPass NÃO é forçado: o exemplo do ik.md desliga, mas
			-- em Native Stereo tirar a malha do depth prepass é candidato a
			-- artefato de render. Fica o padrão do motor.
		end
	end
end

-- O corpo some em terceira pessoa e em cinemáticas, porque nesses casos o jogo
-- mostra o personagem original.
--
-- NA MONTARIA NÃO SOME (10/08/2026): existiu aqui um "Esconder o corpo na
-- montaria", removido a pedido do Renan. Ele nunca ganhava em caso nenhum —
-- como o perfil já esconde o jogador em primeira pessoa, ligá-lo deixava você
-- sem corpo NENHUM em cima da vassoura, e por isso vinha desligado desde
-- sempre. Todo o trabalho da montaria (copiar a malha do jogo, o giro e a
-- postura da cintura) existe justamente para o corpo aparecer certo lá.
local function shouldHideBody()
	if configui.getValue("isFP") == false then return true end
	local playerPawn = uevrUtils.getValid(pawn)
	if playerPawn == nil then return true end
	if playerPawn.InCinematic == true then return true end
	return false
end

-- O ik.lua consulta este callback a cada 200ms e esconde/mostra o corpo quando
-- a resposta muda. Se alguma das condições oscilar (o pawn.InCinematic entra e
-- sai durante certas animações), isso vira pisca-pisca a 5Hz. Por isso só
-- escondemos depois de duas leituras seguidas pedindo para esconder — voltar a
-- aparecer continua imediato.
local hideStreak = 0
local bodyHidden = false

-- Estado JÁ FILTRADO, e é este que o resto do arquivo deve usar.
--
-- Chamar shouldHideBody() cru a cada frame era um erro meu: as pernas, a
-- posição do corpo e a câmera faziam isso, e o InCinematic — que este arquivo
-- já documentava como instável — ligava e desligava as três de um frame para o
-- outro. O corpo parava e voltava, e com a câmera na cabeça ela ainda saltava
-- entre o osso da cabeça e a câmera normal do perfil. Dava exatamente a
-- "flicada", e mais forte com a câmera na cabeça ligada.
local function isBodyHidden()
	return bodyHidden
end

uevrUtils.registerUEVRCallback("is_hands_hidden", function()
	if not isEnabled() then return nil end
	if shouldHideBody() then
		hideStreak = hideStreak + 1
	else
		hideStreak = 0
	end
	bodyHidden = hideStreak >= 2
	return bodyHidden, 20
end)

-- NOTA: existiu aqui uma "trava de cabeça" que mexia na POSIÇÃO do corpo a cada
-- frame para encostar o osso da cabeça no HMD. Ela era a causa do corpo piscar e
-- foi removida. A posição é configurada em jogo, pelo campo "Posicao".

--------------------------------------------------------------------------
-- 1. Animação das pernas — receita do perfil do Silent Hill f, restrita
--
-- O ik.lua cria o corpo em pose de referência e só mexe nos braços; por isso as
-- pernas não andavam. Copiamos a pose só da subárvore das pernas (da coxa para
-- baixo), reancorada no quadril da cópia — copiar a pose inteira levaria tronco,
-- cabeça e dedos junto, que são do VR.
--
-- As malhas de origem precisam continuar animando escondidas, daí o
-- VisibilityBasedAnimTickOption. Ver LEIAME, "Pernas animadas".
--------------------------------------------------------------------------

local RTS_COMPONENT = 2 -- ERelativeTransformSpace::RTS_Component

local FOOT_NAMES = {
	[Handed.Right] = { "rightfoot", "foot_r", "r_foot", "bip01 r foot", "mixamorig:rightfoot" },
	[Handed.Left]  = { "leftfoot",  "foot_l", "l_foot", "bip01 l foot", "mixamorig:leftfoot"  },
}
local NOT_A_FOOT = { "toe", "ball", "ik", "attach", "socket", "twist", "roll", "ctrl", "helper", "end", "tip" }

local legBones = nil       -- { {name=..., fname=...}, ... } coxa para baixo
local legAnchorFName = nil -- quadril: a âncora das pernas

-- Posição do quadril na POSE DE REFERÊNCIA, capturada quando o corpo nasce.
-- É a partir dela que o quadril é reposicionado a cada frame — nunca a partir
-- do valor lido de volta do osso, que é o que nós mesmos escrevemos no frame
-- anterior e faria a posição derivar sozinha.
local referenceHip = nil
-- Altura do quadril na malha de ORIGEM com o personagem em pé, capturada no
-- primeiro frame. É contra esta que o agachamento é medido, e não contra a pose
-- de referência: as duas não coincidem. A pose de referência é a bind pose crua
-- (perna reta), enquanto a pose animada de "em pé" tem sempre um joelho mole —
-- a diferença entre elas é livre, pode ser para cima ou para baixo, e entrava
-- inteira na conta do agachamento. Se a bind pose fosse mais BAIXA que o "em
-- pé" animado, a diferença comia a folga e o agachamento quase não passava.
local standingSourceHipZ = nil
-- O quanto o quadril está abaixado agora (0 = em pé), suavizado.
local hipDrop = 0

-- O quanto o quadril escrito neste quadro saiu da pose de referência, em espaço
-- de componente. A cintura (seção 1c) é escrita em espaço de componente, ou
-- seja, em posição ABSOLUTA dentro do esqueleto — se ela ficasse na translação
-- da pose de referência enquanto o quadril anda (o que acontece montado, onde o
-- quadril é copiado inteiro), o tronco descolaria das pernas. Somando este
-- deslocamento, a cintura acompanha o quadril como filha dele.
local hipShift = { X = 0, Y = 0, Z = 0 }

-- O quadril da animação balança o tempo todo (2-4 cm por passo) e o tronco é
-- filho dele, então copiar o balanço balançaria a vista junto. Separação por
-- amplitude: abaixo da zona morta é balanço e vira zero; um agachamento passa
-- de 30 cm. Sem lerp — amortecer aqui só atrasa a vista (armadilha 6).
local HIP_DROP_DEADZONE = 8.0

local function keepSourceMeshesAnimating(rig)
	for _, template in pairs(rig.meshTemplates or {}) do
		local source = template.instance
		if uevrUtils.getValid(source) ~= nil and source.VisibilityBasedAnimTickOption ~= nil then
			source.VisibilityBasedAnimTickOption = ALWAYS_TICK_POSE_AND_REFRESH_BONES
		end
	end
end

local function detectFootBone(names, set, side)
	for _, candidate in ipairs(FOOT_NAMES[side]) do
		if set[candidate] ~= nil then return set[candidate] end
	end
	for _, keyword in ipairs({ "foot", "ankle" }) do
		local best = nil
		for _, name in ipairs(names) do
			local lower = string.lower(name)
			if string.find(lower, keyword, 1, true) ~= nil
				and not containsAny(lower, NOT_A_FOOT)
				and hasSideMarker(lower, side)
				and (best == nil or #name < #best)
			then
				best = name
			end
		end
		if best ~= nil then return best end
	end
	return nil
end

-- Acha o pé de cada lado e sobe a hierarquia: pé -> canela -> coxa -> quadril.
-- A lista final é coxa + todos os descendentes dela (canela, pé, dedos, twist).
local function detectLegBones(mesh)
	legBones, legAnchorFName = nil, nil
	referenceHip, standingSourceHipZ, hipDrop = nil, nil, 0
	hipShift.X, hipShift.Y, hipShift.Z = 0, 0, 0
	if uevrUtils.getValid(mesh) == nil then return end

	local names = uevrUtils.getBoneNames(mesh)
	if names == nil or #names == 0 then return end
	local set = toBoneSet(names)

	local bones, anchor = {}, nil
	for _, side in ipairs({ Handed.Right, Handed.Left }) do
		local foot = detectFootBone(names, set, side)
		if foot ~= nil then
			local chain = getBoneChain(mesh, foot, 4) -- {pé, canela, coxa, quadril}
			if #chain >= 4 then
				local thigh = chain[3]
				anchor = anchor or chain[4]
				table.insert(bones, thigh)
				for _, descendant in ipairs(animation.getDescendantBones(mesh, thigh, false)) do
					table.insert(bones, descendant)
				end
			end
		end
	end

	if #bones == 0 or anchor == nil then
		log("Não achei os ossos das pernas — a animação das pernas fica desligada", LogLevel.Warning)
		return
	end

	legBones = {}
	for _, name in ipairs(bones) do
		table.insert(legBones, { name = name, fname = uevrUtils.fname_from_string(name) })
	end
	legAnchorFName = uevrUtils.fname_from_string(anchor)

	-- A cópia ainda está na pose de referência aqui (nasce com
	-- useDefaultPose = true e nada escreveu nela), então este é o único momento
	-- em que dá para ler a posição "de pé" do quadril.
	local hipTransform = mesh:GetBoneTransformByName(legAnchorFName, EBoneSpaces.ComponentSpace)
	if hipTransform ~= nil and hipTransform.Translation ~= nil then
		referenceHip = {
			X = hipTransform.Translation.X,
			Y = hipTransform.Translation.Y,
			Z = hipTransform.Translation.Z,
		}
	end

	logMilestone("Pernas: " .. #legBones .. " ossos, ancoradas em " .. anchor
		.. ", quadril de pe em Z=" .. (referenceHip and string.format("%.1f", referenceHip.Z) or "?"))
end

-- A malha de origem da cópia principal é quem carrega a animação do jogo.
local function getSourceMesh()
	if currentRig == nil then return nil end
	local reference = bodyMeshes[1]
	if reference == nil then return nil end
	for _, template in pairs(currentRig.meshTemplates or {}) do
		if template.mesh == reference then return template.instance end
	end
	return nil
end

local function copyLegPose(engine, delta)
	-- Sem cópia de pernas o quadril fica na pose de referência, então a cintura
	-- não tem deslocamento para acompanhar — zerar aqui evita que um hipShift
	-- velho continue empurrando o tronco depois de desligar a animação.
	if not isEnabled() or currentRig == nil or legBones == nil
		or configui.getValue("body_animate") == false
		or configui.getValue("body_onlyArms") == true
		or isBodyHidden()
	then
		hipShift.X, hipShift.Y, hipShift.Z = 0, 0, 0
		return
	end

	local reference = bodyMeshes[1]
	if uevrUtils.getValid(reference) == nil or reference.SetBoneTransformByName == nil then return end

	local source = getSourceMesh()
	if uevrUtils.getValid(source) == nil or source.GetSocketTransform == nil then return end

	local sourceAnchor = source:GetSocketTransform(legAnchorFName, RTS_COMPONENT)
	local targetAnchor = reference:GetBoneTransformByName(legAnchorFName, EBoneSpaces.ComponentSpace)
	if sourceAnchor == nil or targetAnchor == nil then return end

	-- O quadril é ÂNCORA: a única coisa que a animação move nele é a ALTURA, e só
	-- quando é agachamento de verdade (HIP_DROP_DEADZONE). X, Y e rotação vêm
	-- sempre da pose de referência capturada na criação — o quadril é a raiz do
	-- esqueleto, girá-lo giraria o tronco inteiro, e reler o osso realimentaria o
	-- que nós mesmos escrevemos no frame anterior (armadilha 4).
	-- A linha do "em pé" é medida na malha animada no primeiro frame, e só a pé:
	-- criado em cima do hipogrifo, gravaria a altura de quem está sentado.
	if standingSourceHipZ == nil and mounts.isWalking() then
		standingSourceHipZ = sourceAnchor.Translation.Z
	end

	-- MONTADO: o quadril vai inteiro para onde a animação do jogo o põe. Toda a
	-- prudência acima existe por causa do balanço do andar, que montado não há;
	-- presa na altura de quem está de pé, a pose sentada deixava o tronco
	-- flutuando acima da sela.
	local mounted = not mounts.isWalking()

	if mounted or referenceHip ~= nil then
		if mounted then
			targetAnchor.Translation.X = sourceAnchor.Translation.X
			targetAnchor.Translation.Y = sourceAnchor.Translation.Y
			targetAnchor.Translation.Z = sourceAnchor.Translation.Z
			hipDrop = 0
		else
			hipDrop = 0
			if configui.getValue("body_followCrouch") ~= false and standingSourceHipZ ~= nil then
				-- só para baixo, e só o que passar da folga: andar não é agachar
				hipDrop = math.min(0, sourceAnchor.Translation.Z - standingSourceHipZ + HIP_DROP_DEADZONE)
			end

			-- escrito sempre, inclusive com hipDrop = 0: é assim que o quadril volta
			-- para a altura de pé quando o agachamento é desligado no painel
			targetAnchor.Translation.X = referenceHip.X
			targetAnchor.Translation.Y = referenceHip.Y
			targetAnchor.Translation.Z = referenceHip.Z + hipDrop
		end

		-- guardado para a cintura acompanhar (ver hipShift)
		if referenceHip ~= nil then
			hipShift.X = targetAnchor.Translation.X - referenceHip.X
			hipShift.Y = targetAnchor.Translation.Y - referenceHip.Y
			hipShift.Z = targetAnchor.Translation.Z - referenceHip.Z
		end

		for _, component in ipairs(bodyMeshes) do
			if uevrUtils.getValid(component) ~= nil and component.SetBoneTransformByName ~= nil then
				component:SetBoneTransformByName(legAnchorFName, targetAnchor, EBoneSpaces.ComponentSpace)
			end
		end
	end

	-- As pernas são reancoradas no quadril (que agora pode estar abaixado), então
	-- elas continuam rigidamente presas a ele — sem rasgo na cintura. Parado ou
	-- agachado de verdade, hipDrop bate com o agachamento da animação e os pés
	-- caem no lugar certo; andando, sobra a diferença do balanço, que é o
	-- deslizezinho de pé que o método sempre teve.
	local align = kismet_math_library:ComposeTransforms(
		kismet_math_library:InvertTransform(sourceAnchor), targetAnchor)

	-- Ajuste manual das pernas, do painel: entra depois da reancoragem, em espaço
	-- de componente, empurrando coxa, canela, pé e dedos juntos. Serve para quando
	-- as pernas nascem deslocadas do tronco.
	--
	-- OS EIXOS AQUI SÃO OS DO COMPONENTE: o valor é somado cru na translação do
	-- osso e o esqueleto está girado -90°, então a frente do personagem cai no +Y
	-- e o lado direito no -X — daí o rótulo "X esquerda, Y frente".
	local legOffset = configui.getValue("body_legOffset")
	local lx = legOffset and (legOffset.x or legOffset.X or 0) or 0
	local ly = legOffset and (legOffset.y or legOffset.Y or 0) or 0
	local lz = legOffset and (legOffset.z or legOffset.Z or 0) or 0
	local hasLegOffset = (lx ~= 0 or ly ~= 0 or lz ~= 0)

	for _, bone in ipairs(legBones) do
		local transform = source:GetSocketTransform(bone.fname, RTS_COMPONENT)
		if transform ~= nil then
			local aligned = kismet_math_library:ComposeTransforms(transform, align)
			if hasLegOffset and aligned.Translation ~= nil then
				aligned.Translation.X = aligned.Translation.X + lx
				aligned.Translation.Y = aligned.Translation.Y + ly
				aligned.Translation.Z = aligned.Translation.Z + lz
			end
			for _, component in ipairs(bodyMeshes) do
				if uevrUtils.getValid(component) ~= nil and component.SetBoneTransformByName ~= nil then
					component:SetBoneTransformByName(bone.fname, aligned, EBoneSpaces.ComponentSpace)
				end
			end
		end
	end
end

-- Prioridade 10 = roda ANTES do tick do ik.lua (que é 0). Como só mexemos em
-- osso de perna e o IK só mexe em braço, os dois não se atropelam.
uevrUtils.registerPreEngineTickCallback(function(engine, delta)
	local ok, err = pcall(copyLegPose, engine, delta)
	if not ok then
		log("Falha ao animar as pernas: " .. tostring(err), LogLevel.Warning)
	end
end, 10)

--------------------------------------------------------------------------
-- 1b. SÓ MONTADO: destravar o Z do ik.lua para os braços mirarem certo
--
-- Era este o motivo das mãos ficarem paradas no hipogrifo, e não o solver: o
-- tick do ik.lua escreve o Z pela cápsula do pawn (ik.lua:417) ANTES de resolver
-- os braços, e montado essa cápsula é a da criatura — o alvo saía do alcance e o
-- solver saturava. Com `coupling == 2` o ik.lua não toca no Z (ik.lua:418), e é
-- isso que trocamos enquanto montado, devolvendo o valor original ao desmontar.
--
-- Só age com "corpo copia a malha do jogo" ligado (é quem escreve a posição
-- montado) e a devolução compara antes de escrever, então a pé é no-op.
-- Prioridade 20 = antes de tudo o que é nosso e antes do ik.lua.
--------------------------------------------------------------------------

--------------------------------------------------------------------------
-- SÓ MONTADO: o ik.lua tem que olhar para o PERSONAGEM, não para a criatura.
--
-- O rig busca o pawn em dois pontos: a quem o corpo é anexado (ik.lua:493) e a
-- CapsuleHalfHeight da conta do Z (ik.lua:411). Montado, o pawn controlado é a
-- criatura. `M.setPawn` (ik.lua:80) troca só essa referência, sem mexer em quem
-- o jogo controla. A pé é no-op. Ver LEIAME, armadilha 7.
--------------------------------------------------------------------------
local lastRigPawn = nil

local function updateRigPawn()
	local playerPawn = uevrUtils.getValid(pawn)
	if playerPawn == nil then
		-- sem pawn válido, devolve o padrão: com pawnObject nil o getPawn()
		-- do ik.lua cai sozinho no pawn global.
		if lastRigPawn ~= nil then
			lastRigPawn = nil
			ik.setPawn(nil)
		end
		return
	end

	local rigPawn = uevrUtils.getValid(mounts.getMountPawn(playerPawn)) or playerPawn
	if rigPawn == lastRigPawn then return end
	lastRigPawn = rigPawn

	ik.setPawn(rigPawn)
	if rigPawn ~= playerPawn then
		logMilestone("Montado: ik.lua ancorado no personagem, nao na criatura")
	else
		logMilestone("ik.lua ancorado no pawn controlado")
	end
end

-- valor original do `coupling` do rig (vem de parent_type), guardado na criação
local rigCoupling = nil

-- SOMENTE BRAÇOS usa o mesmo destravamento, e pelo mesmo motivo de fundo: a
-- conta do `ik.lua:417` descreve um corpo INTEIRO, com os pés no chão. Sem
-- tronco nem pernas ela não descreve nada — só joga a cópia 1,5 m abaixo de
-- onde os ombros têm de estar, todo frame, para a nossa correção desfazer logo
-- em seguida. Dois donos escrevendo o mesmo Z é a receita do pisca: basta um
-- frame em que o nosso tick não rode (ou role antes) para os braços irem parar
-- nos pés. Com coupling = 2 o ik.lua não toca no Z e nós somos o único dono.
local function updateMountCoupling()
	if currentRig == nil then return end

	local wantFree = configui.getValue("body_onlyArms") == true
		or (not mounts.isWalking()
			and configui.getValue("body_mountArmsIK") ~= false)

	if wantFree then
		if currentRig.coupling ~= 2 then
			currentRig.coupling = 2
			logMilestone("Z do ik.lua liberado, quem posiciona a copia e o body.lua")
		end
	elseif rigCoupling ~= nil and currentRig.coupling ~= rigCoupling then
		currentRig.coupling = rigCoupling
		logMilestone("Z do ik.lua devolvido (coupling " .. tostring(rigCoupling) .. ")")
	end
end

-- DIAGNÓSTICO, sem efeito nenhum no jogo: registra no log toda vez que o estado
-- de montaria MUDA, com os números crus do momento. É o que responde, sem
-- adivinhação, duas perguntas que o log de hoje deixou em aberto:
--
--   * o estado de montaria oscila sozinho? (no log de 06/08 houve um
--     "desmontado" seguido de "montado" 0,5 s depois, o que não é gente
--     desmontando — e cada oscilação joga o corpo entre a conta de quem está
--     montado e a de quem está a pé);
--   * montado, onde estão de fato a malha do jogo, a cópia e a sua cabeça.
-- Ossos do braço direito, só para o diagnóstico abaixo.
local diagArmBone, diagHandBone = nil, nil

local function detectDiagArmBones(mesh)
	diagArmBone, diagHandBone = nil, nil
	if uevrUtils.getValid(mesh) == nil then return end
	local names = uevrUtils.getBoneNames(mesh)
	if names == nil or #names == 0 then return end
	local hand = detectHandBone(names, toBoneSet(names), Handed.Right)
	if hand == nil then return end
	local chain = getBoneChain(mesh, hand, 5)
	diagHandBone = uevrUtils.fname_from_string(hand)
	if chain[3] ~= nil then diagArmBone = uevrUtils.fname_from_string(chain[3]) end
end

-- DIAGNÓSTICO DOS BRAÇOS, sem efeito no jogo. A cada 2 s, e só montado, anota o
-- que decide se a mão segue o controle:
--
--   * "animando pela malha" — se algum callback `is_hands_animating_from_mesh`
--     responder true, o ik.lua NEM CHAMA os solvers (ik.lua:435): ele copia a
--     pose do braço da malha do jogo. Mão parada segurando a rédea seria
--     exatamente isso;
--   * ombro, mão e controle em MUNDO, mais a distância ombro→controle. Se essa
--     distância for muito maior que o braço, o solver satura e a mão congela no
--     limite do alcance, mesmo rodando normalmente.
local diagTimer = 0

local function logArmDiagnostics(delta)
	if mounts.isWalking() then diagTimer = 0 return end
	if currentRig == nil or #bodyMeshes == 0 then return end
	diagTimer = diagTimer + (delta or 0)
	if diagTimer < 2.0 then return end
	diagTimer = 0

	local mesh = bodyMeshes[1]
	if uevrUtils.getValid(mesh) == nil or mesh.GetBoneLocationByName == nil then return end

	local function fmt(v)
		if v == nil then return "nil" end
		return string.format("(%.0f, %.0f, %.0f)", v.X or 0, v.Y or 0, v.Z or 0)
	end

	local animLeft = uevrUtils.executeUEVRCallbacksWithPriorityBooleanResult(
		"is_hands_animating_from_mesh", Handed.Left)
	local animRight = uevrUtils.executeUEVRCallbacksWithPriorityBooleanResult(
		"is_hands_animating_from_mesh", Handed.Right)

	local shoulder = diagArmBone ~= nil and mesh:GetBoneLocationByName(diagArmBone, EBoneSpaces.WorldSpace) or nil
	local hand = diagHandBone ~= nil and mesh:GetBoneLocationByName(diagHandBone, EBoneSpaces.WorldSpace) or nil
	local controller = controllers.getController(1)
	local controllerLoc = uevrUtils.getValid(controller) ~= nil and controller:K2_GetComponentLocation() or nil

	local reach = "?"
	if shoulder ~= nil and controllerLoc ~= nil then
		reach = string.format("%.0f", kismet_math_library:Vector_Distance(shoulder, controllerLoc))
	end
	local erro = "?"
	if hand ~= nil and controllerLoc ~= nil then
		erro = string.format("%.0f", kismet_math_library:Vector_Distance(hand, controllerLoc))
	end

	local solvers = 0
	for _ in pairs(currentRig.activeSolvers or {}) do solvers = solvers + 1 end

	logMilestone("[bracos] solvers=" .. solvers
		.. ", animando pela malha: esq=" .. tostring(animLeft) .. " dir=" .. tostring(animRight)
		.. ", ombro=" .. fmt(shoulder) .. ", mao=" .. fmt(hand)
		.. ", controle=" .. fmt(controllerLoc)
		.. ", ombro->controle=" .. reach .. "cm, mao->controle=" .. erro .. "cm")
end

local lastLoggedMountType = nil

local function logMountStateChange()
	local mountType = mounts.getMountType()
	if mountType == lastLoggedMountType then return end
	lastLoggedMountType = mountType

	local function fmt(v)
		if v == nil then return "nil" end
		return string.format("(%.0f, %.0f, %.0f)", v.X or 0, v.Y or 0, v.Z or 0)
	end
	local function nameOf(obj)
		if uevrUtils.getValid(obj) == nil or obj.get_full_name == nil then return "nil" end
		local full = obj:get_full_name()
		return full:sub(-60)
	end

	-- O TIPO SAI PRIMEIRO, antes de qualquer coisa que possa estourar. Estava no
	-- fim: bastava uma das leituras abaixo falhar para a linha inteira sumir, e
	-- como `lastLoggedMountType` já foi atualizado acima, aquela transição nunca
	-- mais era registrada. Foi assim que a montaria em criatura passou batida.
	logMilestone("--- montaria mudou: tipo=" .. tostring(mountType)
		.. ", voando=" .. tostring(mounts.getIsFlying()) .. " ---")

	local playerPawn = uevrUtils.getValid(pawn)
	local rider = playerPawn ~= nil and uevrUtils.getValid(mounts.getMountPawn(playerPawn)) or nil
	local source = getSourceMesh()
	local mesh = bodyMeshes[1]
	local hmd = controllers.getController(2)
	local root = uevrUtils.getValid(playerPawn, {"RootComponent"})
	logMilestone("  pawn=" .. nameOf(playerPawn) .. ", personagem=" .. nameOf(rider))
	logMilestone("  capsula=" .. tostring(root ~= nil and root.CapsuleHalfHeight or "nil")
		.. ", root=" .. fmt(root ~= nil and root:K2_GetComponentLocation() or nil))
	logMilestone("  malha do jogo=" .. nameOf(source) .. " em "
		.. fmt(uevrUtils.getValid(source) ~= nil and source:K2_GetComponentLocation() or nil))
	logMilestone("  copia=" .. fmt(uevrUtils.getValid(mesh) ~= nil and mesh:K2_GetComponentLocation() or nil)
		.. ", cabeca=" .. fmt(uevrUtils.getValid(mesh) ~= nil and mesh.GetSocketLocation ~= nil
			and mesh:GetSocketLocation(uevrUtils.fname_from_string(headBone)) or nil)
		.. ", HMD=" .. fmt(uevrUtils.getValid(hmd) ~= nil and hmd:K2_GetComponentLocation() or nil))
end

-- Estas falhas iam como Warning e o filtro do perfil é Error, então NUNCA
-- chegavam no log.txt: um pcall que estoura todo frame ficava completamente
-- invisível. Agora vão como marco (Error), e cada mensagem distinta sai só uma
-- vez para não encher o arquivo a 30 Hz.
local loggedTickFailures = {}

local function logTickFailure(prefix, err)
	local text = prefix .. ": " .. tostring(err)
	if loggedTickFailures[text] then return end
	loggedTickFailures[text] = true
	logMilestone(text)
end

uevrUtils.registerPreEngineTickCallback(function(engine, delta)
	-- antes do coupling: quem for refazer o rig neste frame já pega o pawn certo
	local okPawn, errPawn = pcall(updateRigPawn)
	if not okPawn then
		logTickFailure("Falha ao apontar o pawn do rig", errPawn)
	end
	local ok, err = pcall(updateMountCoupling)
	if not ok then
		logTickFailure("Falha ao ajustar o coupling na montaria", err)
	end
	local okLog, errLog = pcall(logMountStateChange)
	if not okLog then
		logTickFailure("Falha ao registrar a mudanca de montaria", errLog)
	end
	local okArms, errArms = pcall(logArmDiagnostics, delta)
	if not okArms then
		logTickFailure("Falha no diagnostico dos bracos", errArms)
	end
end, 20)

--------------------------------------------------------------------------
-- 1c. SÓ MONTADO (criatura): o tronco acompanha o headset
--
-- Montado o corpo não tem yaw próprio: herda a rotação da malha do jogo, que
-- aponta para onde a criatura aponta. Aqui o tronco gira para onde você olha,
-- com zona morta, sensibilidade e limite, sem nada mudar de lugar — é só a
-- rotação de um osso, o da CINTURA (primeiro da coluna). No quadril as pernas
-- iriam junto e sairiam do estribo.
--
-- O mesmo osso recebe o "endireitar a coluna": a reclinada do hipogrifo vem da
-- malha inteira, não de osso, e desinclinar o componente levaria as pernas.
-- A conta parte sempre da pose de referência capturada na criação, nunca do que
-- está no osso (que é o que nós escrevemos no frame anterior).
--
-- Prioridade 5 = depois das pernas (10) e antes do IK (0), para os braços serem
-- resolvidos com o tronco já na direção final.
-- Ver LEIAME, "Tronco acompanhando o headset" e "Endireitar a coluna".
--------------------------------------------------------------------------

local waistFName    = nil   -- primeiro osso da coluna (filho do quadril)
local waistRef      = nil   -- pose de referência dele, em números
local waistYawState = 0     -- torção já aplicada (suavizada)
local waistApplied  = false -- há uma torção escrita no osso agora?
local waistWarned   = false

local WAIST_LERP = 8.0

-- O endireitamento NÃO é suavizado de propósito: ele é uma função direta da
-- rotação da criatura, que já muda suave, e a câmera é compensada — então não
-- há degrau para amortecer. Um lerp aqui só atrasaria a correção e deixaria o
-- tronco balançando atrás da inclinação da montaria.

local function detectWaistBone(mesh)
	waistFName, waistRef, waistYawState, waistApplied = nil, nil, 0, false
	if uevrUtils.getValid(mesh) == nil or legAnchorFName == nil then return end
	if mesh.GetParentBone == nil or mesh.GetBoneTransformByName == nil then return end

	local names = uevrUtils.getBoneNames(mesh)
	if names == nil or #names == 0 then return end

	-- filho direto do quadril que não é perna: é a cintura. Entre candidatos
	-- vence o nome mais curto, que é sempre a raiz da coluna (Spine, e não
	-- Spine_twist_01 e afins).
	local isLeg = {}
	for _, bone in ipairs(legBones or {}) do isLeg[string.lower(bone.name)] = true end

	local hipName = legAnchorFName:to_string()
	local best = nil
	for _, name in ipairs(names) do
		if not isLeg[string.lower(name)] then
			local parent = mesh:GetParentBone(uevrUtils.fname_from_string(name))
			if parent ~= nil and parent:to_string() == hipName then
				if best == nil or #name < #best then best = name end
			end
		end
	end

	if best == nil then
		log("Não achei o osso da cintura — o tronco não vai acompanhar a visão na montaria", LogLevel.Warning)
		return
	end

	local fname = uevrUtils.fname_from_string(best)
	-- A cópia ainda está na pose de referência aqui (nasce com useDefaultPose e
	-- nada escreveu nela), então este é o único momento em que dá para ler a
	-- pose "neutra" da cintura.
	local transform = mesh:GetBoneTransformByName(fname, EBoneSpaces.ComponentSpace)
	local q = transform ~= nil and transform.Rotation or nil
	if transform == nil or transform.Translation == nil or q == nil or q.W == nil then
		log("Não consegui ler a pose da cintura ('" .. best .. "')", LogLevel.Warning)
		return
	end

	local rot = uevrUtils.rotatorFromQuat(q.X, q.Y, q.Z, q.W)
	local scale = transform.Scale3D
	waistFName = fname
	-- guardado em NÚMEROS: struct do motor devolvida por Get... é reaproveitada
	waistRef = {
		lx = transform.Translation.X, ly = transform.Translation.Y, lz = transform.Translation.Z,
		pitch = rot.Pitch, yaw = rot.Yaw, roll = rot.Roll,
		sx = scale ~= nil and scale.X or 1, sy = scale ~= nil and scale.Y or 1,
		sz = scale ~= nil and scale.Z or 1,
	}

	logMilestone("Cintura: '" .. best .. "' (acima de '" .. hipName .. "')")
end

-- Rotação que, aplicada na cintura, tira da coluna a inclinação que veio da
-- malha do jogo. Devolve nil quando não há nada a fazer — e nesse caso a escrita
-- da cintura fica exatamente como sempre foi.
--
-- A leitura é da MALHA DE ORIGEM e não da nossa cópia, de propósito. É a mesma
-- fonte que a seção 4 usa para posicionar o corpo, então as duas enxergam o
-- mesmo valor no mesmo quadro; ler de volta a rotação da nossa cópia seria ler
-- o que nós mesmos escrevemos (e a seção 4 escreve DEPOIS desta, no tick -10,
-- então viria de um quadro atrás).
local function computeSpineCorrection()
	local amount = configui.getValue("body_mountSpineUpright") or 0
	local trim   = configui.getValue("body_mountSpineTrim") or 0
	if amount <= 0 and trim == 0 then return nil end

	local source = getSourceMesh()
	if uevrUtils.getValid(source) == nil or source.K2_GetComponentRotation == nil then return nil end
	local srcRot = source:K2_GetComponentRotation()
	if srcRot == nil then return nil end

	amount = math.max(0, math.min(1, amount))
	local withRoll = configui.getValue("body_mountSpineRoll") ~= false

	-- para onde a rotação do componente vai ser puxada: mesmo yaw, pitch (e roll,
	-- se marcado) reduzidos pela fração escolhida. amount = 0 devolve a rotação
	-- original; amount = 1 deixa o tronco na vertical do mundo.
	local target = uevrUtils.rotator(
		srcRot.Pitch * (1 - amount),
		srcRot.Yaw,
		withRoll and (srcRot.Roll * (1 - amount)) or srcRot.Roll)

	-- Ajuste fino: uma inclinação a mais, medida no plano de quem está montado.
	-- Precisa ser em volta do eixo esquerda-direita DO PERSONAGEM, e o esqueleto
	-- não aponta para a frente do componente — daí o "Mesh Rotation Offset" do
	-- IK Dev Config, que é justamente a diferença entre um e outro. Tirando ele
	-- do yaw da malha sobra a direção para onde o personagem realmente olha.
	if trim ~= 0 then
		local rigYaw = 0
		if currentRig ~= nil and currentRig.meshRotationOffset ~= nil then
			rigYaw = currentRig.meshRotationOffset.Yaw or 0
		end
		local facingYaw = srcRot.Yaw - rigYaw
		-- desgira -> inclina em pitch (agora o pitch é o do personagem) -> gira de volta
		local lean = kismet_math_library:ComposeRotators(
			kismet_math_library:ComposeRotators(
				uevrUtils.rotator(0, -facingYaw, 0),
				uevrUtils.rotator(trim, 0, 0)),
			uevrUtils.rotator(0, facingYaw, 0))
		target = kismet_math_library:ComposeRotators(target, lean)
	end

	-- Diferença entre "como o componente deveria estar" e "como ele está".
	-- Transform em vez de rotator porque o inverso de um rotator não é o rotator
	-- negado — MakeTransform/InvertTransform/ComposeTransforms é o caminho que o
	-- resto deste arquivo já usa e que a lib garante.
	local one  = uevrUtils.vector(1, 1, 1)
	local zero = uevrUtils.vector(0, 0, 0)
	return kismet_math_library:ComposeTransforms(
		kismet_math_library:MakeTransform(zero, target, one),
		kismet_math_library:InvertTransform(
			kismet_math_library:MakeTransform(zero, uevrUtils.rotator(srcRot.Pitch, srcRot.Yaw, srcRot.Roll), one)))
end

-- Escreve a cintura. `correction` é o que computeSpineCorrection devolveu, ou nil.
--
-- A CABEÇA NÃO É TRATADA AQUI: reescrevê-la para a câmera não se mexer esticava o
-- pescoço ("chiclete") e descolava a vista do corpo. A cabeça é osso da coluna e
-- anda com ela; quem reposiciona a vista é o "Ajuste dos olhos".
local function writeWaist(yaw, correction)
	local rotation = uevrUtils.rotator(waistRef.pitch, waistRef.yaw, waistRef.roll)
	if yaw ~= 0 then
		rotation = kismet_math_library:ComposeRotators(rotation, uevrUtils.rotator(0, yaw, 0))
	end

	-- A translação é a da pose de referência MAIS o quanto o quadril saiu dela
	-- (hipShift). Escrever em espaço de componente é escrever posição absoluta
	-- dentro do esqueleto: sem essa soma, montado — onde o quadril é copiado
	-- inteiro — o tronco ficaria parado na pose de pé enquanto as pernas sentam,
	-- e o corpo se partiria na cintura.
	local lx = waistRef.lx + hipShift.X
	local ly = waistRef.ly + hipShift.Y
	local lz = waistRef.lz + hipShift.Z

	local transform = kismet_math_library:MakeTransform(
		uevrUtils.vector(lx, ly, lz),
		rotation,
		uevrUtils.vector(waistRef.sx, waistRef.sy, waistRef.sz))

	if correction ~= nil then
		-- A correção entra DEPOIS da rotação do osso, no espaço do componente.
		-- Composta só na rotação e remontada com a translação e a escala
		-- originais: assim é um giro puro em volta da junta da cintura, sem
		-- deslocar nada — que é o que mantém o tronco preso ao quadril.
		local rotated = kismet_math_library:ComposeTransforms(
			kismet_math_library:MakeTransform(uevrUtils.vector(0, 0, 0), rotation, uevrUtils.vector(1, 1, 1)),
			correction)
		local q = rotated ~= nil and rotated.Rotation or nil
		if q ~= nil and q.W ~= nil then
			transform = kismet_math_library:MakeTransform(
				uevrUtils.vector(lx, ly, lz),
				uevrUtils.rotatorFromQuat(q.X, q.Y, q.Z, q.W),
				uevrUtils.vector(waistRef.sx, waistRef.sy, waistRef.sz))
		end
	end

	for _, component in ipairs(bodyMeshes) do
		if uevrUtils.getValid(component) ~= nil and component.SetBoneTransformByName ~= nil then
			component:SetBoneTransformByName(waistFName, transform, EBoneSpaces.ComponentSpace)
		end
	end

end

-- Condições comuns às duas coisas que mexem na cintura (o giro atrás do headset
-- e o endireitar da coluna). O que separa uma da outra é decidido no tick: cada
-- uma tem o seu próprio controle no painel e uma pode estar ligada sem a outra.
local function waistControlActive()
	if waistFName == nil or waistRef == nil then return false end
	if not isEnabled() or currentRig == nil or #bodyMeshes == 0 then return false end
	if mounts.isWalking() then return false end
	-- vassoura fica de fora: lá a regra é não modificar nada
	if mounts.isOnBroom() then return false end
	if isBodyHidden() then return false end
	return true
end

local function updateWaistFollow(engine, delta)
	local active = waistControlActive()

	local correction = nil
	if active then
		local ok, result = pcall(computeSpineCorrection)
		if ok then correction = result end
	end

	local followYaw = active and configui.getValue("body_mountHipAlign") ~= false

	if not active or (not followYaw and correction == nil) then
		-- Desmontou (ou desligou tudo): devolve a cintura à pose de referência
		-- UMA vez. Sem isto o osso guardaria a última torção para sempre, porque
		-- a pé ninguém mais escreve nele. Em regime, a pé, isto não escreve nada.
		if waistApplied then
			waistApplied = false
			waistYawState = 0
			local ok = pcall(writeWaist, 0, nil)
			if not ok and not waistWarned then
				waistWarned = true
				logMilestone("Cintura: nao consegui devolver a pose de referencia")
			end
		end
		return
	end

	local target = 0
	if followYaw then
		local hmd = controllers.getController(2)
		local mesh = bodyMeshes[1]
		if uevrUtils.getValid(hmd) == nil or uevrUtils.getValid(mesh) == nil then return end

		local hmdRot = hmd:K2_GetComponentRotation()
		local bodyRot = mesh:K2_GetComponentRotation()
		if hmdRot == nil or bodyRot == nil then return end

		-- Montado, a rotação do corpo é a da malha do jogo (o "corpo copia a malha"
		-- escreve ela inteira), então o quanto você está torcido é simplesmente a
		-- diferença entre o headset e ela.
		local diff = uevrUtils.clampAngle180(hmdRot.Yaw - bodyRot.Yaw)

		local deadzone = configui.getValue("body_mountHipDeadzone") or 0
		if math.abs(diff) > deadzone then
			local sign = diff >= 0 and 1 or -1
			target = (diff - sign * deadzone) * (configui.getValue("body_mountHipSensitivity") or 0)
			local limit = configui.getValue("body_mountHipMaxYaw") or 60
			target = math.max(-limit, math.min(limit, target))
		end
	end

	if delta ~= nil and delta > 0 then
		waistYawState = waistYawState + (target - waistYawState) * math.min(1, WAIST_LERP * delta)
	else
		waistYawState = target
	end

	waistApplied = true
	writeWaist(waistYawState, correction)
end

uevrUtils.registerPreEngineTickCallback(function(engine, delta)
	local ok, err = pcall(updateWaistFollow, engine, delta)
	if not ok then
		log("Falha ao girar a cintura: " .. tostring(err), LogLevel.Warning)
	end
end, 5)

--------------------------------------------------------------------------
-- 2. Altura do corpo
--
-- Sobrou só a linha de base do quadril: as duas correções que moravam aqui
-- foram removidas e não devem voltar.
--   (a) perseguir a malha do jogo para manter os pés plantados — ARMADILHA 3.
--       Sintoma: "descalibra quando subo", e recalibrar só reposicionava a
--       linha de base, sem tirar a oscilação.
--   (b) "agachar de verdade", descendo o corpo quando o HMD baixava —
--       ARMADILHA 2. O comentário original jurava que não lia nada que a
--       gente mesmo escreve, e era falso.
--
-- Quem trata agachamento é a altura do QUADRIL (seção 1), medida em espaço de
-- componente. A altura do corpo é inteiramente do ik.lua.
--------------------------------------------------------------------------

local function resetHeightCalibration()
	standingSourceHipZ = nil -- a linha do "em pé" do quadril (seção 1)
end

--------------------------------------------------------------------------
-- 3. Câmera atracada à cabeça do corpo
--
-- Por padrão a câmera deste perfil ORBITA o pawn (main.lua:130) e sobrava para o
-- corpo correr atrás dela. Este modo inverte: a câmera passa a ficar NA CABEÇA
-- do corpo e o corpo fica parado em relação ao pawn.
--
-- Só a POSIÇÃO é tocada; a rotação continua do headset. O deslocamento roomscale
-- é somado pelo UEVR depois deste callback, então andar no espaço real continua
-- funcionando.
--
-- O registro sai de um uevrUtils.delay porque a ordem importa: o callback do
-- main.lua é registrado durante o carregamento e sobrescreveria o nosso.
--------------------------------------------------------------------------

-- Um caminho só: a câmera vai ao osso da cabeça nos TRÊS EIXOS, a pé e montado.
-- Se o mundo voltar a deslizar ao virar o corpo, o suspeito é o X/Y do
-- `mesh_location_offset`, que é o raio do arco descrito pelo osso.
local function headCameraActive()
	if not isEnabled() or currentRig == nil or #bodyMeshes == 0 then return false end
	if configui.getValue("body_headCamera") ~= true then return false end
	if configui.getValue("body_onlyArms") == true then return false end -- sem corpo, sem cabeça
	if isBodyHidden() then return false end
	return true
end

local function getHeadWorldLocation()
	local mesh = bodyMeshes[1]
	if uevrUtils.getValid(mesh) == nil or mesh.GetSocketLocation == nil then return nil end
	-- "Esconder a cabeca" encolhe o osso (SetBoneScaleByName), não o move: a
	-- posição continua valendo mesmo com a cabeça invisível.
	return mesh:GetSocketLocation(uevrUtils.fname_from_string(headBone))
end

--------------------------------------------------------------------------
-- OLHAR PARA BAIXO LEVA A VISTA UM POUCO PARA A FRENTE
--
-- Move só A CÂMERA — nenhum osso é tocado. Quanto mais para baixo você olha,
-- mais a vista avança; olhando reto, avanço nenhum.
--
-- Só dentro de 60° para cada lado da frente do corpo (cheio até 45°, cosseno
-- até 60°, zero depois), e o avanço é na FRENTE DO CORPO, nunca na direção do
-- olhar. Vale a pé, na vassoura e em criatura.
-- Ver LEIAME, "Olhar para baixo leva a vista para a frente".
--------------------------------------------------------------------------

local GAZE_ARC_CORE   = 45 -- até aqui o efeito é cheio
local GAZE_ARC_HALF   = 60 -- daqui para fora, zero (a janela de 120°)
local GAZE_PITCH_DEAD = 10 -- graus de olhar para baixo que ainda não movem nada

-- Devolve: o yaw do olhar relativo à frente do corpo, o pitch do olhar contra o
-- HORIZONTE (negativo = olhando para baixo) e a direção do avanço, que é a
-- frente do corpo achatada no plano do chão.
--
-- O pitch é contra o horizonte, não contra o peito do personagem: montado, a
-- cópia vai reclinada e olhar reto já contaria como olhar para baixo. Tudo por
-- vetor, nunca `.Yaw`/`.Pitch` de rotator, que se confundem com o roll perto de
-- 90° de pitch. Ver LEIAME, "Yaw contra o corpo, pitch contra o horizonte".
local function getGazeInBodySpace()
	local mesh = bodyMeshes[1]
	local hmd = controllers.getController(2)
	if uevrUtils.getValid(mesh) == nil or uevrUtils.getValid(hmd) == nil then return nil end
	if mesh.K2_GetComponentRotation == nil or hmd.K2_GetComponentRotation == nil then return nil end
	if kismet_math_library == nil or kismet_math_library.GetForwardVector == nil
		or kismet_math_library.GetRightVector == nil then return nil end

	local hmdRot  = hmd:K2_GetComponentRotation()
	local bodyRot = mesh:K2_GetComponentRotation()
	if hmdRot == nil or bodyRot == nil then return nil end

	-- copiar para números logo depois de cada chamada: o motor reaproveita a
	-- mesma struct, e a chamada seguinte sobrescreveria a anterior
	local v = kismet_math_library:GetForwardVector(hmdRot)
	if v == nil then return nil end
	local vx, vy, vz = v.X, v.Y, v.Z

	-- só X e Y: o Z da frente do corpo não entra em nada aqui, porque tanto a
	-- janela quanto o avanço são medidos no chão
	local f = kismet_math_library:GetForwardVector(bodyRot)
	if f == nil then return nil end
	local fx, fy = f.X, f.Y

	local r = kismet_math_library:GetRightVector(bodyRot)
	if r == nil then return nil end
	local rx, ry = r.X, r.Y

	-- frente do ESQUELETO: os eixos do componente girados por -meshRotationOffset.Yaw,
	-- que é justamente a diferença entre a frente de um e a do outro (-90 aqui)
	local rigYaw = 0
	if currentRig ~= nil and currentRig.meshRotationOffset ~= nil then
		rigYaw = currentRig.meshRotationOffset.Yaw or 0
	end
	local a = math.rad(-rigYaw)
	local ca, sa = math.cos(a), math.sin(a)
	local Fx, Fy = (fx * ca) + (rx * sa), (fy * ca) + (ry * sa)

	-- Os dois yaws saem da sombra no chão: a do corpo e a do olhar. Achatar é o
	-- que faz a conta valer igual com o personagem reclinado (hipogrifo) ou
	-- deitado (vassoura) — a "frente" que interessa para a janela é para onde ele
	-- aponta no chão, não para onde o peito dele está virado.
	local bodyFlat = math.sqrt((Fx * Fx) + (Fy * Fy))
	local gazeFlat = math.sqrt((vx * vx) + (vy * vy))
	-- corpo (ou olhar) apontando reto para cima/baixo: não há sombra para medir, e
	-- uma direção inventada seria pior que efeito nenhum
	if bodyFlat < 0.0001 or gazeFlat < 0.0001 then return nil end

	local bodyYawNow = math.deg(math.atan(Fy, Fx))
	local gazeYaw    = math.deg(math.atan(vy, vx))

	-- pitch CONTRA O HORIZONTE (ver o bloco acima): é o pescoço de quem joga, que
	-- está na vertical na sala, e não o peito do boneco
	local pitch = math.deg(math.atan(vz, gazeFlat))

	-- direção do avanço: a frente do corpo achatada e normalizada, para o empurrão
	-- ser sempre horizontal. Antes ele saía na frente crua do personagem, o que
	-- montado o mandava para o chão ou para o céu junto com a inclinação do bicho.
	return gazeYaw - bodyYawNow, pitch, Fx / bodyFlat, Fy / bodyFlat, 0
end

-- Quantos centímetros a vista avança agora, e para onde. Devolve nil quando não
-- há avanço nenhum — desligado, fora da janela ou olhando para cima.
--
-- Nada de suavização: a conta já é contínua nas duas bordas (o cosseno da janela
-- e a rampa do pitch), e amortecer o que alimenta a câmera é atraso na vista, não
-- suavidade. Foi a lição do lerp do quadril, tirado em 10/08/2026.
local function gazeLeanPush()
	if configui.getValue("body_gazeLean") == false then return nil end
	-- sem a câmera na cabeça o applyHeadCamera nem chega a escrever posição: quem
	-- manda na vista é o main.lua. Repetido aqui para o "Diagnostico no log" não
	-- anunciar um empurrão que não está acontecendo.
	if not headCameraActive() then return nil end

	local maximum = configui.getValue("body_gazeLeanMax") or 0
	if maximum <= 0 then return nil end

	local relYaw, relPitch, Fx, Fy, Fz = getGazeInBodySpace()
	if relYaw == nil then return nil end

	-- janela de 120°: cheio até 45°, cosseno até 60°, zero depois
	local away = math.abs(uevrUtils.clampAngle180(relYaw))
	if away >= GAZE_ARC_HALF then return nil end
	local gate = 1
	if away > GAZE_ARC_CORE then
		gate = 0.5 * (1 + math.cos(math.pi * (away - GAZE_ARC_CORE) / (GAZE_ARC_HALF - GAZE_ARC_CORE)))
	end

	-- rampa do pitch: 0 na zona morta, 1 olhando reto para baixo. Assim o valor
	-- do painel é o avanço máximo em centímetros, e não um ganho abstrato.
	local down = -relPitch - GAZE_PITCH_DEAD
	if down <= 0 then return nil end
	local ramp = down / (90 - GAZE_PITCH_DEAD)
	if ramp > 1 then ramp = 1 end

	return maximum * ramp * gate, Fx, Fy, Fz
end

-- Só para o "Diagnostico no log".
local function gazeLeanDistance()
	local push = gazeLeanPush()
	return push or 0
end

-- Tudo é lido AQUI dentro, no mesmo instante em que a posição é escrita: nada
-- vem guardado do tick (chegaria atrasado um quadro) e não há teste de olho —
-- os dois recalculam e batem. Ver LEIAME, armadilha 5.
local function applyHeadCamera(position, rotation)
	if not headCameraActive() then return end

	-- É o osso da CÓPIA, não o da malha do jogo: a câmera pega a cabeça que você
	-- realmente vê. Sem osso não escrevemos nada e vale a câmera normal do perfil.
	-- Esconder a cabeça encolhe o osso, não o move — a posição continua valendo.
	local head = getHeadWorldLocation()
	if head == nil then return end

	local x, y, z = head.X, head.Y, head.Z

	-- OLHAR PARA BAIXO LEVA A VISTA PARA A FRENTE (ver o bloco logo acima).
	-- Calculado e somado aqui dentro, no mesmo instante em que a posição é
	-- escrita: nada é guardado entre um quadro e outro, e os dois olhos recebem
	-- o mesmo valor porque leem o mesmo estado.
	local push, fx, fy, fz = gazeLeanPush()
	if push ~= nil then
		x, y, z = x + (fx * push), y + (fy * push), z + (fz * push)
	end

	-- ALTURA DOS OLHOS: onde os seus olhos ficam acima do osso da cabeça. Um só
	-- para tudo (a pé, vassoura, criatura) e só altura — o X/Y que existiu aqui
	-- girava pela direção do olhar e fazia a câmera andar em círculo.
	-- Ver LEIAME, "Câmera atracada à cabeça do corpo".
	z = z + (configui.getValue("body_headCameraHeight") or 0)

	position.x = x
	position.y = y
	position.z = z
end

local headCameraRegistered = false

local function registerHeadCamera()
	if headCameraRegistered then return end
	headCameraRegistered = true

	uevr.params.sdk.callbacks.on_early_calculate_stereo_view_offset(
		function(device, view_index, world_to_meters, position, rotation, is_double)
			-- pcall obrigatório: isto roda dentro do caminho da câmera, uma vez
			-- por olho. Um erro solto aqui derruba a renderização.
			local ok, err = pcall(applyHeadCamera, position, rotation)
			if not ok then
				-- Warning NÃO chega no log.txt (o filtro do perfil é Error): um erro
				-- aqui estourava todo frame e ficava INVISÍVEL — a câmera
				-- simplesmente não era escrita e parecia que a opção "não faz nada".
				-- logTickFailure manda como marco e só uma vez por mensagem.
				logTickFailure("Falha na camera da cabeca", err)
			end
		end)

	logMilestone("Camera atracada a cabeca: callback registrado")
end

--------------------------------------------------------------------------
-- 4. Tronco acompanhando a visão
--
-- O corpo é filho do RootComponent, então gira com o PAWN — e este perfil usa
-- yaw desacoplado, em que virar a cabeça não vira o pawn. O libs/body_yaw.lua da
-- uevrlib gira o corpo em direção ao yaw do HMD, com lerp e zona morta.
--------------------------------------------------------------------------

-- A posição é recalculada todo frame porque a câmera deste perfil ORBITA a
-- origem do pawn (main.lua:130, raio de ~19 cm): com yaw desacoplado, virar 180°
-- move a câmera uns 38 cm, e o corpo, preso ao RootComponent com deslocamento
-- fixo, não acompanha.
--
-- Só X e Y. O Z continua sendo do tick do ik.lua (prioridade 0, logo antes desta
-- função), que é o valor ajustado em "Posicao".

-- Para onde o corpo olha. É uma variável NOSSA e nunca é lida de volta do
-- componente: o corpo é filho do RootComponent e o jogo gira o pawn na direção
-- do movimento no tick do motor, que roda depois deste callback — a leitura já
-- viria girada e o corpo acabava seguindo o analógico em vez do headset
-- (armadilha 4).
local bodyYawState = nil

local function updateBodyTransform(engine, delta)
	if not isEnabled() or currentRig == nil or #bodyMeshes == 0 then return end
	if isBodyHidden() then return end

	local followView = configui.getValue("body_followView") ~= false
	-- SOMENTE BRAÇOS: os ombros penduram na SUA cabeça, não no chão. Neste modo o
	-- ik.lua encolhe o esqueleto para esconder o corpo, todos os ossos desabam na
	-- origem do componente (que está nos pés) e os braços ficariam lá embaixo.
	-- Então a posição inteira (X, Y e Z) sai do HMD, e "Altura dos bracos" é a
	-- distância dos olhos até os ombros. Aqui ler o HMD não é realimentação: sem
	-- cabeça para a câmera atracar, headCameraActive() é false (armadilha 2).
	local onlyArms = configui.getValue("body_onlyArms") == true

	local rootComponent = uevrUtils.getValid(pawn, {"RootComponent"})
	if rootComponent == nil then return end
	-- Montado, o `pawn` global é A CRIATURA, mas o corpo está preso ao
	-- RootComponent do PERSONAGEM (updateRigPawn / ik.setPawn) — e é contra esse
	-- pai que RelativeLocation é medido. Só "somente bracos" chega aqui montado;
	-- todo o resto sai no bloco logo abaixo, que escreve em MUNDO e não se
	-- importa com quem é o pai. A pé isto é um no-op: getMountPawn devolve o
	-- próprio pawn.
	if onlyArms and not mounts.isWalking() then
		local rigRoot = uevrUtils.getValid(mounts.getMountPawn(pawn), {"RootComponent"})
		if rigRoot ~= nil then rootComponent = rigRoot end
	end
	local mesh = bodyMeshes[1]
	if uevrUtils.getValid(mesh) == nil then return end

	--------------------------------------------------------------------------
	-- MONTARIA (vassoura, hipogrifo): o corpo copia a malha do jogo.
	--
	-- O posicionamento normal pressupõe alguém EM PÉ (X/Y de um offset ajustado a
	-- pé, Z da cápsula, rotação só de yaw). Na vassoura o jogo deita o personagem
	-- e a vassoura inclina, então a conta é abandonada: o corpo vai para onde está
	-- a malha do jogo, com a rotação dela inteira. Em MUNDO, porque montado o
	-- personagem é outro ator (RiderCharacter) e não divide o pai com a cópia.
	--------------------------------------------------------------------------
	-- "Somente bracos" não entra aqui: copiar a malha é o que põe o TRONCO na
	-- sela, e neste modo os ombros têm de ficar debaixo da sua cabeça.
	if not mounts.isWalking() and not onlyArms then
		local source = getSourceMesh()
		if uevrUtils.getValid(source) ~= nil and source.K2_GetComponentLocation ~= nil then
			local srcLoc = source:K2_GetComponentLocation()
			local srcRot = source:K2_GetComponentRotation()
			if srcLoc ~= nil and srcRot ~= nil then
				-- Posição e rotação são as da malha do jogo, sem ajuste
				-- nenhum: cópia e malha têm o mesmo esqueleto e a mesma
				-- origem. O "Ajuste na montaria" que existiu aqui era
				-- compensação de um defeito no quadril, não calibragem.
				for _, component in ipairs(bodyMeshes) do
					if uevrUtils.getValid(component) ~= nil and component.K2_SetWorldLocation ~= nil then
						component:K2_SetWorldLocation(
							uevrUtils.vector(srcLoc.X, srcLoc.Y, srcLoc.Z, true),
							false, reusable_hit_result, false)
						component:K2_SetWorldRotation(
							uevrUtils.rotator(srcRot.Pitch, srcRot.Yaw, srcRot.Roll),
							false, reusable_hit_result, false)
					end
				end

				-- o yaw livre do corpo perde o sentido montado; recomeça do pawn
				-- quando você desmontar
				bodyYawState = nil
				return
			end
		end
	end

	local hmd = controllers.getController(2)
	local pawnYaw = rootComponent:K2_GetComponentRotation().Yaw
	-- O offset de Yaw faz parte da rotação da malha, não da direção para onde o
	-- corpo "olha", então entra e sai da conta. Lido do rig (Mesh Rotation
	-- Offset, no IK Dev Config) e não de um campo daqui: havia um campo em cada
	-- painel gravando no mesmo parâmetro, cada um com a sua cópia salva, e o
	-- valor voltava sozinho.
	local meshYawOffset = 0
	if currentRig ~= nil and currentRig.meshRotationOffset ~= nil then
		meshYawOffset = currentRig.meshRotationOffset.Yaw or 0
	end

	-- 1) para onde o corpo olha
	local newYaw = pawnYaw
	if followView then
		if bodyYawState == nil then bodyYawState = pawnYaw end
		newYaw = bodyYawState
		if uevrUtils.getValid(hmd) ~= nil and delta ~= nil and delta > 0 then
			newYaw = bodyYaw.update(newYaw, hmd:K2_GetComponentRotation().Yaw, delta) or newYaw
		end
		bodyYawState = newYaw
	else
		-- desligado: o corpo volta a girar com o pawn, e na próxima vez que for
		-- ligado começa de onde o pawn estiver
		bodyYawState = nil
	end

	-- 2) posição horizontal: base embaixo do HMD + o ajuste do painel.
	-- O ajuste é medido no espaço do CORPO (X = para onde o corpo olha), então
	-- ele gira junto com o corpo; sem isso, "um pouco para trás" viraria "um
	-- pouco para frente" assim que você se virasse.
	local x, y = 0, 0
	local offset = currentRig.meshLocationOffset
	if offset ~= nil then
		local rotated = kismet_math_library:RotateAngleAxis(
			uevrUtils.vector(offset.X, offset.Y, 0), newYaw - pawnYaw, uevrUtils.vector(0, 0, 1))
		x, y = rotated.X, rotated.Y
	end

	-- "Somente bracos" mede tudo a partir do HMD, inclusive o ajuste do painel,
	-- que é medido no espaço do CORPO (X para onde o corpo olha) como todos os
	-- outros ajustes daqui — assim "um pouco para trás" continua sendo para trás
	-- depois de você se virar.
	local armsOffset = nil
	if onlyArms then
		local value = configui.getValue("body_armsOffset")
		if value ~= nil then
			local rotated = kismet_math_library:RotateAngleAxis(
				uevrUtils.vector(value.x or value.X or 0, value.y or value.Y or 0, 0),
				newYaw - pawnYaw, uevrUtils.vector(0, 0, 1))
			x, y = x + rotated.X, y + rotated.Y
			armsOffset = value.z or value.Z or 0
		else
			armsOffset = 0
		end
	end

	-- O "Corpo segue a posicao da cabeca" foi removido (opção e código): ele tirava
	-- a base horizontal do HMD para acompanhar a órbita da câmera do perfil e só
	-- valia com a câmera na cabeça DESMARCADA, que não é o modo em uso. Sobrou o
	-- "somente bracos", que precisa do HMD por outro motivo: sem tronco, os ombros
	-- têm de ficar debaixo da sua cabeça.
	local armsZ = nil
	if onlyArms and uevrUtils.getValid(hmd) ~= nil then
		local hmdLoc = hmd:K2_GetComponentLocation()
		local rootLoc = rootComponent:K2_GetComponentLocation()
		-- diferença em mundo -> espaço do pawn, que é onde RelativeLocation vive
		local inPawnSpace = kismet_math_library:RotateAngleAxis(
			uevrUtils.vector(hmdLoc.X - rootLoc.X, hmdLoc.Y - rootLoc.Y, 0),
			-pawnYaw, uevrUtils.vector(0, 0, 1))
		x = x + inPawnSpace.X
		y = y + inPawnSpace.Y
		if armsOffset ~= nil then
			-- Altura relativa ao pawn, que é o espaço do RelativeLocation. Nada
			-- da conta da cápsula do ik.lua entra aqui: ela vale para o corpo
			-- inteiro, cujos pés precisam encostar no chão.
			armsZ = (hmdLoc.Z - rootLoc.Z) + armsOffset
		end
	end

	-- 3) altura: é inteiramente do ik.lua. Ele reescreve RelativeLocation.Z no tick
	-- de prioridade 0, logo antes deste, então lemos o valor dele e devolvemos
	-- igual — nada que venha do HMD entra aqui (armadilha 2).
	--
	-- Única exceção, "somente bracos" (armsZ): sem corpo para calibrar contra o
	-- chão, a conta da cápsula não descreve nada e a câmera na cabeça está off.
	for _, component in ipairs(bodyMeshes) do
		if uevrUtils.getValid(component) ~= nil and component.K2_SetRelativeLocation ~= nil then
			local z = armsZ
			if z == nil then
				z = component.RelativeLocation ~= nil and component.RelativeLocation.Z or 0
			end
			component:K2_SetRelativeLocation(
				uevrUtils.vector(x, y, z, true), false, reusable_hit_result, false)
		end
	end

	-- Em "somente bracos" a rotação é escrita sempre: montado, o bloco que
	-- copiava a rotação da malha do jogo não roda mais (acima), e sem escrever
	-- nada aqui os ombros ficariam com a rotação que sobrou da criatura.
	if followView or onlyArms then
		local rotation = uevrUtils.rotator(0, newYaw + meshYawOffset, 0)
		for _, component in ipairs(bodyMeshes) do
			if uevrUtils.getValid(component) ~= nil and component.K2_SetWorldRotation ~= nil then
				component:K2_SetWorldRotation(rotation, false, reusable_hit_result, false)
			end
		end
	end
end

--------------------------------------------------------------------------
-- SOMENTE BRAÇOS: repor o corpo escondido depois que o ik.lua copia a pose
--
-- O "esconder" deste modo mora na ESCALA dos ossos (armadilha 10), e dois pontos
-- do ik.lua a desfazem: `animateFromMesh` (ik.lua:677), que copia a pose inteira
-- da malha do jogo em escala 1, e `setInitialTransform` (ik.lua:440) no frame em
-- que essa animação acaba. Quem liga isso é o montage
-- (`is_hands_animating_from_mesh`), e ele oscila — daí o corpo aparecer e sumir
-- parado. A reposição é barata e roda só nos frames com cópia de pose, mais um.
--------------------------------------------------------------------------
local reapplyCount = 0
local wasAnimatingLast = false

local function reapplyHiddenBodyScales()
	if currentRig == nil or #bodyMeshes == 0 then return end
	if configui.getValue("body_onlyArms") ~= true then
		wasAnimatingLast = false
		return
	end

	local animating = currentRig.wasAnimating == true
	-- nada aconteceu neste frame nem no anterior
	if not animating and not wasAnimatingLast then return end
	wasAnimatingLast = animating

	if currentRig.updateBonesVisibility == nil then return end
	currentRig:updateBonesVisibility()
	-- a cabeça é escondida do mesmo jeito (escala do osso), então cai junto
	applyHeadVisibility()

	reapplyCount = reapplyCount + 1
	-- Marco no log, mas só nas primeiras vezes: se o pisca for isto, o log mostra
	-- a rajada; se não for, ficam duas linhas e pronto. Sem isso, um pisca a
	-- 90 Hz encheria o log.txt.
	if reapplyCount <= 5 then
		logMilestone("Somente bracos: pose do jogo copiada, corpo escondido reposto (" .. reapplyCount .. ")")
	end
end

-- Prioridade -10 = roda DEPOIS do tick do ik.lua, para a rotação final do corpo
-- ser a nossa. Continua no pré-tick: escrever transform no pós-tick foi o que
-- fez o corpo piscar da outra vez.
uevrUtils.registerPreEngineTickCallback(function(engine, delta)
	-- escalas primeiro: se o corpo acabou de voltar ao tamanho normal, os ossos
	-- que o posicionamento e os solvers usam já estão certos neste mesmo frame
	local okScale, errScale = pcall(reapplyHiddenBodyScales)
	if not okScale then
		logTickFailure("Falha ao repor o corpo escondido", errScale)
	end

	local ok, err = pcall(updateBodyTransform, engine, delta)
	if not ok then
		log("Falha ao posicionar o corpo: " .. tostring(err), LogLevel.Warning)
	end
end, -10)

--------------------------------------------------------------------------
-- Criação do rig
--------------------------------------------------------------------------

-- Reconstruir o corpo também reconstrói a varinha: o vínculo dela (controle ou
-- socket da mão) não sobrevive ao rig novo. Só DESCONECTAMOS — quem reconecta é
-- o poll do main.lua (linha 1009), já com o corpo novo no lugar.
--
-- pcall obrigatório: isto é chamado de timers, que o uevr_utils roda sem
-- proteção (uevr_utils:1123).
local function rebuildWand()
	if type(_G.disconnectWand) ~= "function" then return end
	local ok, err = pcall(_G.disconnectWand)
	if ok then
		log("Varinha desconectada para reconectar junto com o corpo")
	else
		log("Falha ao reconectar a varinha: " .. tostring(err), LogLevel.Warning)
	end
end

--------------------------------------------------------------------------
-- CORPOS FANTASMAS
--
-- Cópia PoseableMesh que sobrevive a um destroy fica órfã e congela onde
-- estava: é isso que dá "dois corpos" e z-fighting. Varremos as cópias
-- penduradas no pawn em dois momentos — depois do nosso destroyAll (keep
-- vazio) e na criação do corpo novo (keep = as malhas novas, que é o que cobre
-- os destroyAll disparados pelo próprio ik.lua). Desce pela árvore por causa do
-- SpringArm do coupling 2, e destrói sempre com destroyOwner = false, porque o
-- dono é o pawn. Ver LEIAME, "Corpo sumindo / piscando" e armadilha 9.
--------------------------------------------------------------------------
-- Todas as cópias penduradas no pawn, marcando com `mine` as que estão em
-- `keep`. Separado da destruição porque o diagnóstico precisa listar as duas:
-- mais de uma cópia = fantasma; só uma = briga de escrita.
local function collectPoseableCopies(keep)
	local found = {}

	local rootComponent = uevrUtils.getValid(pawn, {"RootComponent"})
	if rootComponent == nil then return found end

	local poseableClass = uevrUtils.get_class("Class /Script/Engine.PoseableMeshComponent")
	if poseableClass == nil then return found end

	local isMine = {}
	for _, mesh in ipairs(keep or {}) do isMine[mesh] = true end

	local function collect(component, depth)
		if depth > 4 then return end
		local children = component.AttachChildren
		if children == nil then return end
		for i = 1, #children do
			local child = children[i]
			if uevrUtils.getValid(child) ~= nil then
				if child.is_a ~= nil and child:is_a(poseableClass) then
					table.insert(found, { component = child, mine = isMine[child] == true })
				end
				collect(child, depth + 1)
			end
		end
	end
	collect(rootComponent, 0)

	return found
end

local function destroyGhostBodies(keep)
	-- com o corpo desligado o perfil volta às mãos antigas, que também podem ser
	-- PoseableMesh — não é hora de varrer nada
	if not isEnabled() then return end

	local ghosts = {}
	for _, entry in ipairs(collectPoseableCopies(keep)) do
		if not entry.mine then table.insert(ghosts, entry.component) end
	end

	if #ghosts == 0 then return end
	for _, ghost in ipairs(ghosts) do
		pcall(uevrUtils.destroyComponent, ghost, false, true)
	end
	logMilestone("Corpos fantasmas removidos: " .. #ghosts)
end

local function rebuild()
	ik.destroyAll()
	-- o que sobrou de PoseableMesh no pawn agora é fantasma
	pcall(destroyGhostBodies)
	currentRig = nil
	bodyMeshes = {}
	bodyYawState = nil
	resetHeightCalibration()
	rebuildWand()
end

-- Aplica um parâmetro do rig e grava em data/ik_parameters.json.
--
-- Sem fila de espera: os únicos parâmetros que valia a pena enfileirar eram a
-- posição e a rotação da malha, e esses saíram daqui — quem manda neles é o
-- painel IK Dev Config. O que sobrou ("hide_body") não pode esperar mesmo,
-- porque desligá-lo faz o próprio módulo IK reconstruir o rig.
local function setRigParam(key, value)
	if currentRig ~= nil then
		currentRig:setConfigParameter(key, value, true)
	end
end

ik.registerOnMeshCreatedCallback(function(meshList, rig)
	currentRig = rig
	bodyMeshes = meshList or {}
	if #bodyMeshes == 0 then
		log("Nenhuma malha foi criada para o corpo", LogLevel.Warning)
		return
	end

	-- Limpa cópias que sobreviveram a algum destroy anterior. Aqui é o único
	-- ponto por onde passam TODOS os caminhos de criação, inclusive os que o
	-- ik.lua dispara sozinho — por isso a varredura mora nos dois lugares.
	pcall(destroyGhostBodies, bodyMeshes)

	-- Confere os nomes de osso contra a malha real: se algum estava errado, os
	-- solvers nasceram mortos — grava os corretos e reconstrói (uma vez só).
	--
	-- MONTADO, NÃO: esta detecção GRAVA em data/ik_parameters.json, e se o corpo
	-- nasceu do esqueleto errado ela persiste os ossos da criatura por cima dos
	-- seus (aconteceu em 06/08/2026: `wing_elbow_left`, `wing_wrist_right`).
	if not mounts.isWalking() then
		rig.bodyBonesChecked = true
	end
	if configui.getValue("body_autoDetectBones") ~= false and not rig.bodyBonesChecked then
		rig.bodyBonesChecked = true
		if detectBones(rig, false) then
			log("Ossos corrigidos — reconstruindo o corpo")
			uevrUtils.delay(200, rebuild) -- fora do callback de criação
			return
		end
	end

	applyShadowSetting()
	applyHeadVisibility()
	keepSourceMeshesAnimating(rig)
	detectLegBones(bodyMeshes[1])
	-- o valor de fábrica do Z automático, para devolver ao desmontar (seção 1b)
	rigCoupling = rig.coupling or 1
	-- depois das pernas: a cintura é achada excluindo os ossos delas (seção 1c)
	detectWaistBone(bodyMeshes[1])
	detectDiagArmBones(bodyMeshes[1])

	-- reaproveita as poses de dedo do perfil nas mãos do corpo
	rig:setAnimationsFromHandsParametersFile(buildAnimationTable())
	rig:initHandAnimations(rig.meshTemplates)

	logMilestone("Corpo criado com " .. #bodyMeshes .. " malha(s)")

	-- e a varinha volta junto. Aqui cobre também os caminhos que não passam pelo
	-- botão "Reconstruir corpo": troca de malhas, redetecção de ossos e a
	-- criação automática no começo do nível.
	rebuildWand()
end)

ik.registerOnDestroyCallback(function()
	currentRig = nil
	bodyMeshes = {}
end)

--------------------------------------------------------------------------
-- As mãos antigas (presas aos controles) e o corpo não podem coexistir:
-- as duas usariam os mesmos IDs de animação e as mãos ficariam duplicadas.
--------------------------------------------------------------------------

-- Quem decide se as mãos existem é a global showHands, lida pelo main.lua a cada
-- poll. Mexemos direto nela e nas malhas, e repetimos de tempos em tempos caso
-- algo recrie as mãos. NÃO usamos configui.setValue("showHands", ...): isso
-- dispara o onUpdate do main.lua (disconnectWand + reset + disconnectHands) num
-- momento arbitrário, e erro em timer derruba os outros (uevr_utils:1123).
-- Efeito colateral aceito: o checkbox "Show Hands" continua marcado na tela.
local function enforceHandsOff()
	if not isEnabled() then return end
	if configui.getValue("body_replaceHands") == false then return end

	if _G.showHands ~= false then
		_G.showHands = false
		log("'Show Hands' desligado — as mãos agora vêm do corpo")
	end

	if hands.exists() then
		log("Destruindo as mãos antigas presas aos controles")
		hands.destroyHands()
		hands.reset()
	end
end

-- Quando o corpo é desligado, devolve as mãos do perfil.
local function restoreHands()
	if _G.showHands == false then
		log("Religando 'Show Hands'")
		_G.showHands = true
	end
end

uevrUtils.setInterval(2000, function()
	local ok, err = pcall(enforceHandsOff)
	if not ok then
		log("Falha ao desligar as mãos: " .. tostring(err), LogLevel.Warning)
	end
end)

--------------------------------------------------------------------------
-- Refazer o corpo ao mexer no inventário (para a roupa nova aparecer)
--
-- O corpo é uma cópia das malhas do personagem, tirada quando o rig nasce:
-- trocar de roupa troca as malhas do jogo, não a cópia. A tela de equipamento é
-- reconhecida pelo UIManager (UI na tela + Guia de Campo na aba 1) e o corpo é
-- refeito nas duas bordas — quem resolve é a de saída, quando a roupa nova já
-- existe. Ver LEIAME, "Roupa nova".
--------------------------------------------------------------------------
local uiManagerCache = nil
local lastInGearScreen = false

local function isInGearScreen()
	if uevrUtils.getValid(uiManagerCache) == nil then
		uiManagerCache = uevrUtils.find_first_of("Class /Script/Phoenix.UIManager")
	end
	local uiManager = uevrUtils.getValid(uiManagerCache)
	if uiManager == nil then return false end
	if uiManager.GetIsUIShown == nil or uiManager:GetIsUIShown() ~= true then return false end

	local widget = uevrUtils.getValid(uiManager.FieldGuideWidget)
	if widget == nil then return false end
	return widget.CurrentTabIndex == 1
end

uevrUtils.setInterval(200, function()
	local ok, err = pcall(function()
		local inGear = isInGearScreen()
		if inGear == lastInGearScreen then return end
		lastInGearScreen = inGear

		-- corpo desligado ou ainda não criado: não há o que refazer, e o
		-- temporizador do ik.lua criaria um do zero de qualquer jeito
		if not isEnabled() or currentRig == nil then return end

		logMilestone(inGear and "Equipamento aberto: refazendo o corpo"
			or "Equipamento fechado: refazendo o corpo com a roupa nova")
		rebuild()
	end)
	if not ok then
		log("Falha ao refazer o corpo no inventario: " .. tostring(err), LogLevel.Warning)
	end
end)

--------------------------------------------------------------------------
-- Painel de configuração
--------------------------------------------------------------------------

-- "Ativar corpo VR" e "Usar as maos do corpo" andam juntos nos dois sentidos: as
-- mãos do corpo são as mãos DO CORPO, e deixar um marcado sem o outro mostrava
-- no painel um estado que não existia. Quem faz o restoreHands/enforceHandsOff é
-- o handler do body_replaceHands; aqui só escrevemos o valor.
--
-- Sem laço infinito: cada função só escreve quando o valor é DIFERENTE do que já
-- está lá, então a segunda volta da corrente para sozinha.
local function syncReplaceHands(enabled)
	if configui.getValue("body_replaceHands") == enabled then return end
	configui.setValue("body_replaceHands", enabled)
end

local function syncBodyEnabled(enabled)
	if configui.getValue("body_enabled") == enabled then return end
	configui.setValue("body_enabled", enabled)
end

configui.onCreateOrUpdate("body_enabled", function(value)
	ik.setAutoCreateArms(value == true)
	syncReplaceHands(value == true)
	if value ~= true then
		rebuild()
		restoreHands()
	else
		uevrUtils.delay(1000, enforceHandsOff)
	end
end)

configui.onCreateOrUpdate("body_replaceHands", function(value)
	syncBodyEnabled(value == true)
	if value == false then
		restoreHands()
	else
		uevrUtils.delay(1000, enforceHandsOff)
	end
end)

configui.onCreateOrUpdate("body_shadow", function(value)
	applyShadowSetting()
end)

configui.onCreateOrUpdate("body_followViewDeadzone", function(value)
	bodyYaw.setMinAngularDeviation(value)
end)

--------------------------------------------------------------------------
-- PADRÕES DO PAINEL
--
-- A calibragem aprovada em jogo. Uma lista só serve de initialValue e de alvo do
-- botão "Restaurar padroes". Não entra posição/rotação do corpo: dono único é o
-- painel IK Dev Config (armadilha 8).
--------------------------------------------------------------------------
local PANEL_DEFAULTS = {
	body_devMode             = false,
	body_enabled             = true,
	body_replaceHands        = true,
	body_shadow              = true,
	body_onlyArms            = false,
	body_armsOffset          = { 0, 0, -15 },
	body_animate             = true,
	body_followCrouch        = true,
	body_headCamera          = true,
	body_headCameraHeight    = 9,
	body_gazeLean            = true,
	body_gazeLeanMax         = 25.6,
	body_followView          = true,
	body_followViewDeadzone  = 1,
	body_legOffset           = { 0, 9.5, 0 },
	body_mountArmsIK         = true,
	body_mountHipAlign       = true,
	body_mountHipSensitivity = 0,
	body_mountHipDeadzone    = 0,
	body_mountHipMaxYaw      = 0,
	body_mountSpineUpright   = 0.785,
	body_mountSpineRoll      = true,
	body_mountSpineTrim      = -1.45,
	body_autoDetectBones     = true,
}

-- Compara o que está no painel com o padrão. Vetor vem do configui como struct
-- (X/Y/Z) e o padrão é lista de três — daí os dois jeitos de ler.
local function nearEnough(a, b)
	if type(a) ~= "number" or type(b) ~= "number" then return a == b end
	-- o painel guarda float e devolve 25.621999…, então comparar com == acusaria
	-- diferença em valor que para o jogador é o mesmo
	return math.abs(a - b) < 0.0005
end

local function sameAsDefault(current, wanted)
	if type(wanted) == "table" then
		if type(current) ~= "table" and type(current) ~= "userdata" then return false end
		local ok, cx, cy, cz = pcall(function()
			local x = current.X or current.x or current[1]
			local y = current.Y or current.y or current[2]
			local z = current.Z or current.z or current[3]
			return x, y, z
		end)
		if not ok then return false end
		return nearEnough(cx, wanted[1]) and nearEnough(cy, wanted[2]) and nearEnough(cz, wanted[3])
	end
	return nearEnough(current, wanted)
end

--------------------------------------------------------------------------
-- MODO DESENVOLVEDOR
--
-- Esconde os interruptores internos (todos já no ponto certo; desmarcar
-- qualquer um quebra alguma parte do corpo) e a aba "IK Dev Config".
--
-- É um `begin_group` com `isHidden`: o drawUI pula até o `end_group`
-- (configui.lua:614), então um interruptor cobre o bloco inteiro. A aba do IK é
-- criada sempre; o modo só a mostra ou esconde, pelo nome do arquivo de save.
--------------------------------------------------------------------------
local IK_DEV_PANEL_ID = "dev/ik_config_dev"

local function applyDevMode()
	local on = configui.getValue("body_devMode") == true
	configui.hideWidget("body_devGroup", not on)
	-- pcall porque o painel do IK pode ainda não existir na primeira passada (o
	-- ik.init roda depois do configui.create) e hidePanel indexa a lista direto
	pcall(configui.hidePanel, IK_DEV_PANEL_ID, not on)
end

configui.onUpdate("body_devMode", applyDevMode)

-- SÓ ESCREVE O QUE ESTÁ DIFERENTE: `configui.setValue` dispara os onUpdate sem
-- comparar, e o do `body_onlyArms` mexe no `hide_body` — reescrever um valor que
-- já estava certo destruiria e recriaria o corpo à toa (armadilha 9).
--
-- Cada valor vai no seu próprio pcall e a ordem é fixa: um erro num onUpdate
-- abortava o laço e os campos seguintes ficavam sem restaurar, em silêncio.
local RESET_ORDER = {
	"body_headCameraHeight", "body_gazeLeanMax", "body_followViewDeadzone",
	"body_legOffset", "body_armsOffset",
	"body_mountSpineUpright", "body_mountSpineTrim", "body_mountSpineRoll",
	"body_mountHipAlign", "body_mountHipSensitivity", "body_mountHipDeadzone",
	"body_mountHipMaxYaw", "body_mountArmsIK",
	"body_animate", "body_followCrouch", "body_followView",
	"body_headCamera", "body_gazeLean", "body_shadow", "body_autoDetectBones",
	"body_replaceHands", "body_enabled", "body_onlyArms", "body_devMode",
}

configui.onUpdate("body_resetDefaults", function()
	local changed, failed = 0, {}

	local function restore(id)
		local wanted = PANEL_DEFAULTS[id]
		if wanted == nil or sameAsDefault(configui.getValue(id), wanted) then return end
		local ok, err = pcall(configui.setValue, id, wanted)
		if ok then
			changed = changed + 1
		else
			table.insert(failed, id .. " (" .. tostring(err) .. ")")
		end
	end

	local done = {}
	for _, id in ipairs(RESET_ORDER) do
		done[id] = true
		restore(id)
	end
	-- rede de segurança: padrão novo que eu esqueça de pôr na lista de ordem
	-- ainda é restaurado, só que por último
	for id in pairs(PANEL_DEFAULTS) do
		if not done[id] then restore(id) end
	end

	logMilestone("Padroes restaurados: " .. changed .. " valor(es) mudado(s)")
	if #failed > 0 then
		logMilestone("Padroes que falharam: " .. table.concat(failed, ", "))
	end
end)

-- Os três abaixo usam onUpdate (e não onCreateOrUpdate) de propósito: quem manda
-- na posição do corpo é data/ik_parameters.json, lido pelo IK a cada criação.
-- O painel só grava por cima quando o jogador realmente mexe no controle.
configui.onUpdate("body_onlyArms", function(value)
	setRigParam("hide_body", value == true)

	-- DESMARCAR cai no `hide_body == false` do ik.lua:899, que chama destroyAll() e
	-- deixa o rig para o temporizador de 1 s recriar — o caminho que empilha cópia
	-- órfã. A varredura espera o corpo novo existir: com `bodyMeshes` vazio, tudo o
	-- que estivesse pendurado no pawn seria tratado como lixo.
	uevrUtils.delay(1500, function()
		if currentRig == nil or #bodyMeshes == 0 then return end
		pcall(destroyGhostBodies, bodyMeshes)
	end)
end)

configui.onUpdate("body_rebuild", function()
	log("Reconstruindo o corpo")
	rebuild()
end)

-- Fique de pé, na altura em que você joga, e clique. As duas linhas de
-- referência da seção 2 são recapturadas no frame seguinte.
configui.onUpdate("body_recalibrate", function()
	resetHeightCalibration()
	logMilestone("Altura recalibrada")
end)

configui.onUpdate("body_detectBones", function()
	if currentRig == nil then
		log("Corpo não está criado", LogLevel.Warning)
		return
	end
	if detectBones(currentRig, true) then
		log("Ossos redetectados — reconstruindo o corpo")
		uevrUtils.delay(200, rebuild)
	else
		applyHeadVisibility()
	end
end)

-- Despeja no log.txt o estado que interessa quando a câmera ou a altura do
-- corpo estão erradas. Vai como Error de propósito (ver logMilestone): é para
-- ser lido depois, no arquivo.
local function logDiagnostics()
	local function fmt(v)
		if v == nil then return "nil" end
		return string.format("(%.1f, %.1f, %.1f)", v.X or v.x or 0, v.Y or v.y or 0, v.Z or v.z or 0)
	end

	logMilestone("--- diagnostico ---")
	logMilestone("corpo criado: " .. tostring(currentRig ~= nil) .. ", malhas: " .. #bodyMeshes
		.. ", escondido (filtrado): " .. tostring(isBodyHidden())
		.. ", escondido (cru): " .. tostring(shouldHideBody()))
	logMilestone("headCamera marcado: " .. tostring(configui.getValue("body_headCamera"))
		.. ", ativo agora: " .. tostring(headCameraActive()))
	logMilestone("montaria: tipo=" .. tostring(mounts.getMountType())
		.. ", voando=" .. tostring(mounts.getIsFlying()))

	-- SOMENTE BRAÇOS. Estas quatro linhas separam as três causas possíveis do
	-- "está noutra posição e pisca":
	--   * mais de uma cópia na lista  -> corpo fantasma (a órfã congela onde
	--     estava, e neste modo a viva fica na cabeça, bem longe dela);
	--   * coupling ~= 2               -> o ik.lua ainda está escrevendo o Z da
	--     cápsula por frame, disputando a posição com a gente;
	--   * reposições > 0              -> o jogo está copiando a pose por cima
	--     (montage), o que desfaz o encolhimento e mostra o corpo inteiro.
	logMilestone("somente bracos: " .. tostring(configui.getValue("body_onlyArms"))
		.. ", coupling=" .. tostring(currentRig ~= nil and currentRig.coupling or "?")
		.. ", animando pela malha=" .. tostring(currentRig ~= nil and currentRig.wasAnimating == true)
		.. ", reposicoes do corpo escondido=" .. reapplyCount)

	local copies = collectPoseableCopies(bodyMeshes)
	logMilestone("copias PoseableMesh no pawn: " .. #copies .. " (esperado: " .. #bodyMeshes .. ")")
	for _, entry in ipairs(copies) do
		local loc = entry.component.K2_GetComponentLocation ~= nil
			and entry.component:K2_GetComponentLocation() or nil
		logMilestone("  " .. (entry.mine and "[do corpo] " or "[FANTASMA] ")
			.. shortName(entry.component) .. " em " .. fmt(loc))
	end

	local rootComponent = uevrUtils.getValid(pawn, {"RootComponent"})
	if rootComponent ~= nil then
		logMilestone("pawn root: " .. fmt(rootComponent:K2_GetComponentLocation())
			.. ", CapsuleHalfHeight: " .. tostring(rootComponent.CapsuleHalfHeight))
	end

	local hmd = controllers.getController(2)
	if uevrUtils.getValid(hmd) ~= nil then
		logMilestone("HMD: " .. fmt(hmd:K2_GetComponentLocation()))
	end

	logMilestone("altura: quadril abaixado=" .. string.format("%.1f", hipDrop)
		.. ", deslocamento do quadril=" .. string.format("%.1f", hipShift.Z)
		.. ", quadril de pe (origem)=" .. (standingSourceHipZ and string.format("%.1f", standingSourceHipZ) or "nil")
		.. ", quadril na pose de referencia=" .. (referenceHip and string.format("%.1f", referenceHip.Z) or "nil"))

	local source = getSourceMesh()
	if uevrUtils.getValid(source) ~= nil then
		logMilestone("malha de origem no mundo: " .. fmt(source:K2_GetComponentLocation()))
		-- É desta rotação que sai a reclinada do tronco na montaria, e é ela que
		-- o "Endireitar a coluna" desfaz. Se o pitch e o roll aqui estiverem
		-- perto de zero enquanto o corpo aparece deitado, a inclinação vem de
		-- outro lugar e é o "Ajuste fino" que resolve, não o controle.
		local srcRot = source:K2_GetComponentRotation()
		if srcRot ~= nil then
			logMilestone(string.format(
				"rotacao da malha de origem: pitch=%.1f, yaw=%.1f, roll=%.1f",
				srcRot.Pitch, srcRot.Yaw, srcRot.Roll))
		end
	end

	logMilestone("coluna: endireitar=" .. tostring(configui.getValue("body_mountSpineUpright"))
		.. ", lateral=" .. tostring(configui.getValue("body_mountSpineRoll"))
		.. ", ajuste fino=" .. tostring(configui.getValue("body_mountSpineTrim"))
		.. ", corrigindo agora=" .. tostring(computeSpineCorrection() ~= nil))

	-- OLHAR PARA BAIXO (seção 3). O yaw diz se você está dentro da janela de 120°
	-- e o pitch quanto está olhando para baixo; o empurrão é o que a câmera ganha.
	-- Tudo zero com um yaw grande é o esperado — é a janela agindo.
	local relYaw, relPitch = getGazeInBodySpace()
	logMilestone("olhar: yaw=" .. (relYaw ~= nil and string.format("%.0f", relYaw) or "?")
		.. ", pitch=" .. (relPitch ~= nil and string.format("%.0f", relPitch) or "?")
		.. ", empurrao=" .. string.format("%.1f", gazeLeanDistance())
		.. " cm, marcado=" .. tostring(configui.getValue("body_gazeLean")))

	local mesh = bodyMeshes[1]
	if uevrUtils.getValid(mesh) ~= nil then
		logMilestone("corpo relativo: " .. fmt(mesh.RelativeLocation)
			.. ", mundo: " .. fmt(mesh:K2_GetComponentLocation()))

		-- Alturas lado a lado, para separar "o corpo está no lugar errado" de "há
		-- mais de um corpo". A malha do jogo é a referência de onde os pés do
		-- personagem realmente estão.
		if rootComponent ~= nil and uevrUtils.getValid(source) ~= nil then
			local srcLoc = source:K2_GetComponentLocation()
			local rootLoc = rootComponent:K2_GetComponentLocation()
			if srcLoc ~= nil and rootLoc ~= nil then
				logMilestone(string.format("altura: malha do jogo-root=%.1f, corpo-root=%.1f, Z de Posicao=%s",
					srcLoc.Z - rootLoc.Z,
					mesh:K2_GetComponentLocation().Z - rootLoc.Z,
					tostring(currentRig ~= nil and currentRig.meshLocationOffset ~= nil
						and currentRig.meshLocationOffset.Z or "?")))
			end
		end

		-- DOIS CORPOS. O ik.lua guarda os rigs numa LISTA (ik.lua:24) e o
		-- getCurrentMesh devolve o do ÚLTIMO criado; o body.lua rastreia o que
		-- veio no callback de criação. Se os dois não forem a MESMA malha, há
		-- mais de um rig vivo — e o que não é rastreado fica sendo posicionado
		-- só pela fórmula da cápsula do ik.lua, longe do outro.
		local ikMesh = ik.getCurrentMesh and ik.getCurrentMesh(1) or nil
		local ikName = uevrUtils.getValid(ikMesh) ~= nil and shortName(ikMesh) or "nil"
		logMilestone("rig rastreado x rig do ik.lua: " .. shortName(mesh) .. " / " .. ikName
			.. ", sao o mesmo: " .. tostring(ikMesh == mesh))
		logMilestone("osso da cabeca '" .. headBone .. "' no mundo: " .. fmt(getHeadWorldLocation()))

		-- Quadril: na malha de origem é a pose animada do jogo. Com "Corpo
		-- acompanha o agachamento" LIGADO os dois têm que bater (é o que a
		-- cópia da translação faz); DESLIGADO, a cópia fica na pose de
		-- referência e a diferença mostra o quanto o personagem agachou.
		if legAnchorFName ~= nil and currentRig ~= nil then
			if uevrUtils.getValid(source) ~= nil then
				local sourceHip = source:GetSocketTransform(legAnchorFName, RTS_COMPONENT)
				local targetHip = mesh:GetBoneTransformByName(legAnchorFName, EBoneSpaces.ComponentSpace)
				if sourceHip ~= nil and targetHip ~= nil then
					logMilestone("quadril (espaco de componente) origem: " .. fmt(sourceHip.Translation)
						.. ", copia: " .. fmt(targetHip.Translation))
				end
			end
		end
	end
	logMilestone("--- fim ---")
end

configui.onUpdate("body_diagnostics", function()
	local ok, err = pcall(logDiagnostics)
	if not ok then
		log("Falha no diagnostico: " .. tostring(err), LogLevel.Warning)
	end
end)

configui.onUpdate("body_logBones", function()
	local mesh = bodyMeshes[1]
	if uevrUtils.getValid(mesh) == nil then
		log("Corpo não está criado", LogLevel.Warning)
		return
	end
	animation.logBoneNames(mesh)
end)

configui.create({
	{
		panelLabel = "Corpo VR",
		saveFile = "config_body",
		layout = {
			{ widgetType = "text", label = "Corpo completo em primeira pessoa (tronco, bracos, maos, pernas e pes)." },
			{ widgetType = "spacing" },
			{ widgetType = "checkbox", id = "body_enabled", label = "Ativar corpo VR", initialValue = PANEL_DEFAULTS.body_enabled },
			{ widgetType = "checkbox", id = "body_replaceHands", label = "Usar as maos do corpo (desliga Show Hands)", initialValue = PANEL_DEFAULTS.body_replaceHands },
			{ widgetType = "checkbox", id = "body_shadow", label = "Corpo projeta sombra", initialValue = PANEL_DEFAULTS.body_shadow },
			{ widgetType = "checkbox", id = "body_onlyArms", label = "Somente bracos (esconde tronco e pernas)", initialValue = PANEL_DEFAULTS.body_onlyArms },
			{ widgetType = "text", label = "  Neste modo os ombros ficam presos a SUA cabeca: 'Posicao' e a altura da capsula" },
			{ widgetType = "text", label = "  nao valem (elas poem os pes no chao, e aqui nao ha pes). Calibre so o campo abaixo." },
			{
				widgetType = "drag_float3",
				id = "body_armsOffset",
				label = "  Altura dos bracos (X frente, Y direita, Z altura) — so em 'Somente bracos'",
				speed = 0.5,
				range = { -100, 100 },
				initialValue = PANEL_DEFAULTS.body_armsOffset,
			},
			{ widgetType = "text", label = "    Z e a distancia dos seus olhos ate os ombros; mais negativo desce os bracos." },
			{ widgetType = "spacing" },
			{ widgetType = "button", id = "body_resetDefaults", label = "Restaurar padroes" },
			{ widgetType = "text", label = "  Devolve esta aba inteira a calibragem testada em jogo. Nao mexe na 'Posicao'" },
			{ widgetType = "text", label = "  nem na 'Rotacao', que sao do painel IK Dev Config." },
			{ widgetType = "spacing" },
			{ widgetType = "text", label = "Vista" },
			{
				widgetType = "drag_float",
				id = "body_headCameraHeight",
				label = "  Altura dos olhos acima do osso da cabeca",
				speed = 0.5,
				range = { -100, 100 },
				initialValue = PANEL_DEFAULTS.body_headCameraHeight,
			},
			{
				widgetType = "slider_float",
				id = "body_gazeLeanMax",
				label = "  Quanto a camera avanca ao olhar para baixo (cm)",
				speed = 0.5,
				range = { 0, 40 },
				initialValue = PANEL_DEFAULTS.body_gazeLeanMax,
			},
			{ widgetType = "spacing" },
			{ widgetType = "text", label = "Pernas: empurra coxa, canela, pe e dedos juntos." },
			{ widgetType = "text", label = "  Atencao: aqui os eixos sao os do esqueleto, nao os seus — Y e a FRENTE." },
			{
				widgetType = "drag_float3",
				id = "body_legOffset",
				label = "Ajuste das pernas (X esquerda, Y frente, Z altura)",
				speed = 0.5,
				range = { -100, 100 },
				initialValue = PANEL_DEFAULTS.body_legOffset,
			},
			{ widgetType = "spacing" },
			{ widgetType = "text", label = "Postura na montaria (so criaturas; vassoura nao entra)" },
			{ widgetType = "text", label = "  Montado, o corpo copia a rotacao da malha do jogo inteira, e ela vem deitada" },
			{ widgetType = "text", label = "  para tras — e o tronco vai junto. Isto gira SO a cintura de volta, entao as" },
			{ widgetType = "text", label = "  pernas ficam onde a animacao as pos, nos estribos." },
			{
				widgetType = "slider_float",
				id = "body_mountSpineUpright",
				label = "    Endireitar a coluna",
				speed = 0.01,
				range = { 0, 1 },
				initialValue = PANEL_DEFAULTS.body_mountSpineUpright,
			},
			{ widgetType = "text", label = "      0 = pose original do jogo.  1 = coluna na vertical do mundo." },
			{
				widgetType = "slider_float",
				id = "body_mountSpineTrim",
				label = "    Ajuste fino (graus)",
				speed = 0.5,
				range = { -45, 45 },
				initialValue = PANEL_DEFAULTS.body_mountSpineTrim,
			},
			{ widgetType = "text", label = "      Positivo deita para tras, negativo inclina para a frente. Vale sozinho," },
			{ widgetType = "text", label = "      mesmo com o controle de cima em 0." },
			{ widgetType = "text", label = "    A cabeca e osso da coluna e sobe junto, entao a camera sobe junto com ela." },
			{ widgetType = "text", label = "    Reposicione a vista pela 'Altura dos olhos', mais acima." },
			{ widgetType = "spacing" },
			{
				widgetType = "checkbox",
				id = "body_devMode",
				label = "Modo desenvolvedor — nao mexer",
				initialValue = PANEL_DEFAULTS.body_devMode,
			},
			{ widgetType = "text", label = "  Mostra os interruptores internos e a aba 'IK Dev Config'. Todos ja estao no" },
			{ widgetType = "text", label = "  ponto certo; desmarcar qualquer um quebra alguma parte do corpo." },
			{ widgetType = "begin_group", id = "body_devGroup", isHidden = true },
			{
				widgetType = "checkbox",
				id = "body_headCamera",
				label = "  Camera atracada a cabeca do corpo",
				initialValue = PANEL_DEFAULTS.body_headCamera,
			},
			{ widgetType = "text", label = "    A camera vai ate a cabeca em vez de o corpo ir atras da camera. Vale a pe" },
			{ widgetType = "text", label = "    e em toda montaria. A rotacao continua sendo do headset." },
			{
				widgetType = "checkbox",
				id = "body_gazeLean",
				label = "  Camera vai para a frente ao olhar para baixo",
				initialValue = PANEL_DEFAULTS.body_gazeLean,
			},
			{ widgetType = "text", label = "    So dentro de 120 graus da frente do corpo; olhando para tras, zero." },
			{
				widgetType = "checkbox",
				id = "body_followView",
				label = "  Corpo acompanha a visao (giro)",
				initialValue = PANEL_DEFAULTS.body_followView,
			},
			{
				widgetType = "slider_int",
				id = "body_followViewDeadzone",
				label = "    Angulo para o corpo comecar a virar",
				speed = 1.0,
				range = { 1, 90 },
				initialValue = PANEL_DEFAULTS.body_followViewDeadzone,
			},
			{
				widgetType = "checkbox",
				id = "body_mountHipAlign",
				label = "  Na montaria, tronco acompanha o headset (so criaturas)",
				initialValue = PANEL_DEFAULTS.body_mountHipAlign,
			},
			{ widgetType = "text", label = "    Gira o osso da cintura, logo acima do quadril. Nada se move de lugar." },
			{ widgetType = "text", label = "    As pernas ficam onde a animacao as pos. Vassoura nao entra." },
			{
				widgetType = "slider_float",
				id = "body_mountHipSensitivity",
				label = "    Sensibilidade",
				speed = 0.01,
				range = { 0, 1 },
				initialValue = PANEL_DEFAULTS.body_mountHipSensitivity,
			},
			{
				widgetType = "slider_int",
				id = "body_mountHipDeadzone",
				label = "    Angulo para comecar a girar",
				speed = 1.0,
				range = { 0, 60 },
				initialValue = PANEL_DEFAULTS.body_mountHipDeadzone,
			},
			{
				widgetType = "slider_int",
				id = "body_mountHipMaxYaw",
				label = "    Limite do giro (graus)",
				speed = 1.0,
				range = { 0, 90 },
				initialValue = PANEL_DEFAULTS.body_mountHipMaxYaw,
			},
			{
				widgetType = "checkbox",
				id = "body_animate",
				label = "  Animar as pernas pelo jogo",
				initialValue = PANEL_DEFAULTS.body_animate,
			},
			{ widgetType = "text", label = "    So da cintura para baixo. Tronco, cabeca e dedos continuam como estavam." },
			{
				widgetType = "checkbox",
				id = "body_followCrouch",
				label = "  Corpo acompanha o agachamento do jogo",
				initialValue = PANEL_DEFAULTS.body_followCrouch,
			},
			{ widgetType = "text", label = "    Sem isso, agachar levanta os pes em vez de baixar o corpo." },
			{
				widgetType = "checkbox",
				id = "body_mountArmsIK",
				label = "  Na montaria, bracos pelo IK",
				initialValue = PANEL_DEFAULTS.body_mountArmsIK,
			},
			{ widgetType = "text", label = "    Sem isso a mao congela no hipogrifo: o ik.lua mede a altura pela capsula do" },
			{ widgetType = "text", label = "    pawn, que montado e A CRIATURA, e o alvo sai do alcance do braco." },
			{
				widgetType = "checkbox",
				id = "body_mountSpineRoll",
				label = "  Endireitar tambem a inclinacao lateral (montaria)",
				initialValue = PANEL_DEFAULTS.body_mountSpineRoll,
			},
			{ widgetType = "text", label = "    Desmarque para continuar deitando junto com a criatura nas curvas." },
			{
				widgetType = "checkbox",
				id = "body_autoDetectBones",
				label = "  Detectar ossos automaticamente",
				initialValue = PANEL_DEFAULTS.body_autoDetectBones,
			},
			{ widgetType = "text", label = "    Corrige nomes de osso que nao existem na malha. Nome que ja funciona fica." },
			{ widgetType = "end_group" },
			{ widgetType = "spacing" },
			{ widgetType = "button", id = "body_recalibrate", label = "Recalibrar altura" },
			{ widgetType = "same_line" },
			{ widgetType = "button", id = "body_rebuild", label = "Reconstruir corpo" },
			{ widgetType = "same_line" },
			{ widgetType = "button", id = "body_detectBones", label = "Detectar ossos agora" },
			{ widgetType = "same_line" },
			{ widgetType = "button", id = "body_logBones", label = "Listar ossos no log" },
			{ widgetType = "same_line" },
			{ widgetType = "button", id = "body_diagnostics", label = "Diagnostico no log" },
			{ widgetType = "spacing" },
			{ widgetType = "text", label = "Ajuste fino de bracos e maos: aba 'IK Dev Config'.", wrapped = true },
		},
	},
})

ik.init(SHOW_DEV_UI, LogLevel.Info)

-- Depois do ik.init, que é quem cria a aba "IK Dev Config": agora dá para
-- escondê-la. Aqui e não num onCreateOrUpdate porque aquele dispararia durante o
-- configui.create acima, quando o painel do IK ainda não existe.
applyDevMode()

-- O registro da câmera precisa acontecer depois que o main.lua registrou o
-- dele (ver a seção 2), e qualquer callback de tick já satisfaz isso: o
-- UEVRReady do main.lua roda durante o carregamento dos scripts, antes do
-- primeiro tick. O delay é só para não disputar o frame de inicialização.
uevrUtils.delay(2000, registerHeadCamera)

-- Se o perfil for carregado já dentro de um nível, o corpo é criado sozinho
-- pelo temporizador interno do módulo IK (1x por segundo, enquanto não existir).
uevrUtils.registerLevelChangeCallback(function()
	uevrUtils.delay(3000, applyHandsSetting)
	registerHeadCamera() -- protegido por flag: registra uma vez só
end)
