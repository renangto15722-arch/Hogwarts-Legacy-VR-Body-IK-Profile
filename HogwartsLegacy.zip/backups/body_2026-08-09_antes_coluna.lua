--[[
	body.lua — Corpo VR (IK) para Hogwarts Legacy
	--------------------------------------------------------------------------
	Cria um corpo completo em primeira pessoa (tronco, braços, mãos, pernas e
	pés) a partir do próprio esqueleto do personagem, usando o módulo de
	Inverse Kinematics da uevrlib (libs/ik.lua).

	Como funciona (mesmo esquema do perfil do Silent Hill f):
	  1. O módulo IK faz uma cópia PoseableMeshComponent das malhas do
	     personagem (corpo + roupas) e prende essa cópia no RootComponent do
	     pawn, deslocada para baixo até os pés.
	  2. Dois solvers de Two Bone IK giram RightArm/RightForeArm/RightHand e
	     LeftArm/LeftForeArm/LeftHand para que as mãos acompanhem os controles.
	  3. As poses de dedo do próprio perfil (helpers/hand_animations.lua) são
	     reaproveitadas nas mãos do corpo, então gatilho/grip continuam
	     animando os dedos.

	Os valores numéricos (altura, rotação, alinhamento da mão) ficam em
	data/ik_parameters.json e podem ser ajustados ao vivo:
	  - no painel "Corpo VR" (ajustes principais), ou
	  - no painel "IK Dev Config" (ajuste fino de ossos e offsets de mão).
]]--

local uevrUtils      = require("libs/uevr_utils")
local configui       = require("libs/configui")
local animation      = require("libs/animation")
local controllers    = require("libs/controllers")
local hands          = require("libs/hands")
local ik             = require("libs/ik")
local bodyYaw        = require("libs/body_yaw")
local handAnimations = require("helpers/hand_animations")
local mounts         = require("helpers/mounts")
require("libs/enums/unreal")

-- EVisibilityBasedAnimTickOption::AlwaysTickPoseAndRefreshBones — não está no
-- enums/unreal.lua da lib, então fica aqui o valor cru.
local ALWAYS_TICK_POSE_AND_REFRESH_BONES = 0

-- Deixe true para ter o painel "IK Dev Config" na UI do UEVR (ajuste fino).
local SHOW_DEV_UI = true

-- Osso da cabeça. É só o palpite inicial: se não existir na malha, a detecção
-- automática procura o nome certo.
local HEAD_BONE = "Head"

-- Componentes filhos de Pawn.Mesh que nunca devem entrar no corpo.
-- (nomes parciais, sem diferenciar maiúsculas/minúsculas)
local EXCLUDED_MESHES = { "preview", "shadowproxy" }

local currentRig    = nil   -- instância do rig de IK ativa
local bodyMeshes    = {}    -- cópias PoseableMesh criadas pelo IK
local meshTags      = {}    -- tags de animação encontradas na última criação
local pendingParams = {}    -- ajustes feitos antes do corpo existir
local headBone      = HEAD_BONE -- nome real do osso da cabeça nesta malha

local function log(text, level)
	uevrUtils.print("[body] " .. text, level or LogLevel.Info)
end

-- Sem isto NADA de Lua chega no log.txt: o uevr_utils nasce com
-- logToFile = false (uevr_utils.lua:1802) e o print() cru do Lua vai só para a
-- janela de console do UEVR, não para o arquivo — é por isso que procurar
-- "[body]" no log não devolvia nada, e nem o "UEVR is now ready" do main.lua
-- está lá. Ligar isto NÃO enche o log: o filtro de nível continua valendo e o
-- padrão é Error, então só passam erros de verdade e os marcos abaixo.
uevrUtils.setLogToFile(true)

-- Marcos que PRECISAM aparecer no log.txt. O uevrUtils.print só escreve quando
-- logLevel <= currentLogLevel, e o padrão do perfil é Error: mensagem Info não
-- chega no arquivo. Estes são poucos, acontecem uma vez cada e são exatamente o
-- que se lê quando algo não funciona, então vão como Error de propósito.
local function logMilestone(text)
	uevrUtils.print("[body] " .. text, LogLevel.Error)
end

local function isEnabled()
	return configui.getValue("body_enabled") == true
end

--------------------------------------------------------------------------
-- Seleção das malhas que formam o corpo
--------------------------------------------------------------------------

local function shortName(component)
	local fullName = component:get_full_name()
	return fullName:match("([^%.]+)$") or fullName
end

local function isExcluded(name)
	local lowerName = string.lower(name)
	for _, excluded in ipairs(EXCLUDED_MESHES) do
		if string.find(lowerName, excluded, 1, true) ~= nil then
			return true
		end
	end
	return false
end

local function isSkeletalMesh(component)
	if uevrUtils.getValid(component) == nil then return false end
	local class = uevrUtils.get_class("Class /Script/Engine.SkeletalMeshComponent")
	if class ~= nil and component.is_a ~= nil and not component:is_a(class) then
		return false
	end
	-- só interessa se realmente tem uma malha carregada (UE4 x UE5)
	return uevrUtils.getValid(component, {"SkeletalMesh"}) ~= nil
		or uevrUtils.getValid(component, {"SkeletalMeshAsset"}) ~= nil
end

--------------------------------------------------------------------------
-- A malha viva que serve de origem para o corpo VR.
--
-- SÓ MONTADO: a malha é a do personagem, não a da criatura.
--
-- Numa montaria de criatura (hipogrifo, graphorn) o pawn controlado passa a
-- ser A CRIATURA, e o bruxo vira `pawn:GetMountComponent().RiderCharacter` —
-- é o que o `mounts.getMountPawn` devolve, e é por isso que o main.lua o usa
-- em tudo que fala do personagem (hidePlayer, varinha, câmera).
--
-- Isso importa porque o corpo é recriado sozinho pelo temporizador do ik.lua
-- (`ik.lua:2535`, 1x por segundo enquanto não existir). Se essa recriação cai
-- no meio de um voo de hipogrifo e a malha vem de `pawn.Mesh`, o corpo VR é
-- montado a partir da MALHA DA CRIATURA — 142 ossos, esqueleto de asas. Foi
-- o que aconteceu em 06/08/2026.
--
-- A PÉ NADA MUDA: o bloco do montado nem roda, e o retorno continua sendo o
-- `pawn.Mesh` de sempre.
--------------------------------------------------------------------------
local function getPlayerBodyMesh(shouldLog)
	local playerPawn = uevrUtils.getValid(pawn)
	local baseMesh = playerPawn ~= nil and uevrUtils.getValid(playerPawn, {"Mesh"}) or nil

	if playerPawn ~= nil and not mounts.isWalking() then
		local rider = uevrUtils.getValid(mounts.getMountPawn(playerPawn))
		local riderMesh = rider ~= nil and uevrUtils.getValid(rider, {"Mesh"}) or nil
		if riderMesh ~= nil and riderMesh ~= baseMesh then
			baseMesh = riderMesh
			if shouldLog then
				logMilestone("Montado: corpo criado a partir da malha do personagem, nao da criatura")
			end
		end
	end

	return baseMesh
end

-- Chamada pelo libs/ik.lua quando o parâmetro "animation_mesh" está como "Custom".
-- Tem que ser a mesma malha viva usada como origem do corpo: o
-- CopyPoseFromSkeletalComponent do ik.lua exige esqueletos iguais, então apontar
-- para a criatura montada deixaria o corpo congelado na pose padrão.
function getCustomAnimationIKComponent(rigID)
	return getPlayerBodyMesh(false)
end

-- Chamada pelo libs/ik.lua quando o parâmetro "mesh" está como "Custom".
-- Retorna a lista de malhas que serão copiadas para formar o corpo.
-- A primeira da lista precisa ser a malha com o esqueleto completo (Pawn.Mesh),
-- porque é ela que os solvers usam como referência.
function getCustomIKComponent(rigID)
	meshTags = {}

	local baseMesh = getPlayerBodyMesh(true)

	if baseMesh == nil then
		log("Pawn.Mesh indisponível, corpo não foi criado", LogLevel.Warning)
		return {}
	end

	local templates = {}
	table.insert(templates, { descriptor = "Pawn.Mesh", instance = baseMesh, animation = "Body" })
	meshTags["Body"] = true

	if configui.getValue("body_meshMode") ~= 2 then
		local children = baseMesh.AttachChildren
		if children ~= nil then
			for _, child in ipairs(children) do
				if isSkeletalMesh(child) then
					local name = shortName(child)
					if isExcluded(name) then
						log("Malha ignorada: " .. name)
					else
						local tag = nil
						if string.find(name, "Arm") ~= nil then
							tag = "Arms"
						elseif string.find(name, "Glove") ~= nil then
							tag = "Gloves"
						end
						if tag ~= nil and meshTags[tag] == true then
							tag = nil -- só a primeira malha de cada tipo recebe as animações de dedo
						end
						if tag ~= nil then meshTags[tag] = true end

						table.insert(templates, {
							descriptor = "Pawn.Mesh(" .. name .. ")",
							instance = child,
							animation = tag,
							optional = true,
						})
						log("Malha do corpo: " .. name .. (tag ~= nil and (" [" .. tag .. "]") or ""))
					end
				end
			end
		end
	end

	log("Total de malhas no corpo: " .. #templates)
	return templates
end

--------------------------------------------------------------------------
-- Animação dos dedos reaproveitando as poses do perfil
--------------------------------------------------------------------------

-- O módulo hands_animation monta os IDs como "<mão>_<alvo>", então os alvos
-- precisam bater com o sufixo do ID: "hand", "glove", "body".
local function buildAnimationTable()
	local profile = {}
	local targets = { Body = "body", Arms = "hand", Gloves = "glove" }
	for tag, target in pairs(targets) do
		if meshTags[tag] == true then
			profile[tag] = {
				Left  = { AnimationID = "left_"  .. target },
				Right = { AnimationID = "right_" .. target },
			}
		end
	end
	return { animations = { Shared = handAnimations }, profiles = { Main = profile } }
end

--------------------------------------------------------------------------
-- Detecção automática dos ossos
--
-- Cada jogo nomeia os ossos do seu jeito (RightHand, hand_r, Bip01_R_Hand...)
-- e o ik.lua descarta o solver em silêncio quando o nome não existe na malha
-- (ele exige que o osso tenha 3 gerações de pais). Então, antes de aceitar o
-- corpo, conferimos os nomes contra a malha real e corrigimos o que estiver
-- errado. Nomes que já funcionam nunca são tocados.
--------------------------------------------------------------------------

-- palavras que descartam um osso como sendo a mão (dedos e ossos auxiliares)
local NOT_A_HAND = {
	"index", "middle", "ring", "pinky", "thumb", "finger", "twist", "roll",
	"ik", "attach", "socket", "weapon", "prop", "end", "tip", "ctrl", "helper",
}

local NOT_A_HEAD = { "top", "end", "attach", "socket", "ik", "ctrl", "helper", "hat", "wear" }

-- nomes exatos mais comuns, em ordem de preferência (minúsculas)
local HAND_NAMES = {
	[Handed.Right] = { "righthand", "hand_r", "r_hand", "hand_right", "bip01 r hand", "bip01_r_hand", "mixamorig:righthand" },
	[Handed.Left]  = { "lefthand",  "hand_l", "l_hand", "hand_left",  "bip01 l hand", "bip01_l_hand", "mixamorig:lefthand"  },
}

local HEAD_NAMES = { "head", "bip01 head", "bip01_head", "mixamorig:head", "b_head", "head_01" }

local function toBoneSet(names)
	local set = {}
	for _, name in ipairs(names) do
		set[string.lower(name)] = name
	end
	return set
end

local function containsAny(lowerName, words)
	for _, word in ipairs(words) do
		if string.find(lowerName, word, 1, true) ~= nil then return true end
	end
	return false
end

-- separadores usados pelas convenções de nome: hand_r, hand.r, hand-r, "Bip01 R Hand"
local SEPARATOR = "[_%.%-%s]"

local function hasSideMarker(lowerName, side)
	local word, letter = "left", "l"
	if side == Handed.Right then word, letter = "right", "r" end
	return string.find(lowerName, word, 1, true) ~= nil
		or string.match(lowerName, SEPARATOR .. letter .. "$") ~= nil
		or string.match(lowerName, SEPARATOR .. letter .. SEPARATOR) ~= nil
end

-- Procura o osso da mão: primeiro pelos nomes conhecidos, depois por
-- qualquer osso que contenha "hand" (ou "wrist") do lado certo. Entre vários
-- candidatos vence o nome mais curto, que é sempre a raiz da mão.
local function detectHandBone(names, set, side)
	for _, candidate in ipairs(HAND_NAMES[side]) do
		if set[candidate] ~= nil then return set[candidate] end
	end

	for _, keyword in ipairs({ "hand", "wrist" }) do
		local best = nil
		for _, name in ipairs(names) do
			local lower = string.lower(name)
			if string.find(lower, keyword, 1, true) ~= nil
				and not containsAny(lower, NOT_A_HAND)
				and hasSideMarker(lower, side)
				and (best == nil or #name < #best)
			then
				best = name
			end
		end
		if best ~= nil then return best end
	end

	return nil
end

local function detectHeadBone(names, set)
	for _, candidate in ipairs(HEAD_NAMES) do
		if set[candidate] ~= nil then return set[candidate] end
	end
	local best = nil
	for _, name in ipairs(names) do
		local lower = string.lower(name)
		if string.find(lower, "head", 1, true) ~= nil
			and not containsAny(lower, NOT_A_HEAD)
			and (best == nil or #name < #best)
		then
			best = name
		end
	end
	return best
end

-- Cadeia do osso até a raiz: {osso, pai, avô, ...}. Versão com limite — a
-- uevrUtils.getAncestorBones roda um while sem teto e um esqueleto com
-- hierarquia estranha travaria o jogo.
local function getBoneChain(mesh, boneName, maxDepth)
	local chain = { boneName }
	local current = boneName
	for _ = 1, (maxDepth or 6) do
		local parent = mesh:GetParentBone(current)
		if parent == nil then break end
		parent = parent:to_string()
		if parent == "" or parent == "None" or parent == current then break end
		table.insert(chain, parent)
		current = parent
	end
	return chain
end

-- Corrige os ossos de um solver. Devolve true se mudou alguma coisa.
-- A cadeia braço → antebraço → mão sai da própria hierarquia da malha, então
-- só a mão precisa ser adivinhada.
local function fixSolverBones(rig, mesh, names, set, solverId, solverParams)
	local side = Handed.Right
	if solverParams["end_control_type"] == 0 then side = Handed.Left end

	local endBone = solverParams["end_bone"] or ""
	if endBone ~= "" and set[string.lower(endBone)] ~= nil then
		return false -- o nome configurado existe na malha, não mexe
	end

	local detected = detectHandBone(names, set, side)
	-- se um lado foi achado e o outro não, espelha o nome
	if detected == nil then
		local other = detectHandBone(names, set, side == Handed.Right and Handed.Left or Handed.Right)
		if other ~= nil then
			detected = uevrUtils.findOppositeBone(other, side == Handed.Right, names)
		end
	end

	if detected == nil then
		log("Não achei o osso da mão " .. (side == Handed.Right and "direita" or "esquerda")
			.. " para o solver '" .. tostring(solverId) .. "'. Use 'Listar ossos no log' e "
			.. "escolha na aba IK Dev Config.", LogLevel.Warning)
		return false
	end

	local chain = getBoneChain(mesh, detected, 5)
	if #chain < 3 then
		log("Osso '" .. detected .. "' não tem antebraço e braço acima dele, ignorado", LogLevel.Warning)
		return false
	end

	log("Solver '" .. tostring(solverId) .. "': usando " .. chain[3] .. " -> " .. chain[2] .. " -> " .. chain[1])
	rig:setConfigParameter({ "solvers", solverId, "end_bone" }, chain[1], true)
	rig:setConfigParameter({ "solvers", solverId, "joint_bone" }, chain[2], true)
	rig:setConfigParameter({ "solvers", solverId, "start_bone" }, chain[3], true)

	-- ombro e espinha (usados só pelo modo "Somente braços") saem da mesma cadeia
	local shoulderKey = side == Handed.Right and "right_shoulder_bone_name" or "left_shoulder_bone_name"
	if chain[4] ~= nil then
		rig:setConfigParameter(shoulderKey, chain[4], true)
		if chain[5] ~= nil then
			rig:setConfigParameter("spine_bone_name", chain[5], true)
		end
	end

	return true
end

-- Devolve true se algum osso foi corrigido (nesse caso o corpo é reconstruído).
local function detectBones(rig, force)
	local mesh = bodyMeshes[1]
	if uevrUtils.getValid(mesh) == nil then return false end

	local names = uevrUtils.getBoneNames(mesh)
	if names == nil or #names == 0 then
		log("A malha do corpo não devolveu nenhum osso", LogLevel.Warning)
		return false
	end
	local set = toBoneSet(names)

	-- cabeça (não faz parte do rig, aplica na hora)
	if set[string.lower(headBone)] == nil or force then
		local detectedHead = detectHeadBone(names, set)
		if detectedHead ~= nil then
			if detectedHead ~= headBone then
				log("Osso da cabeça: " .. detectedHead)
			end
			headBone = detectedHead
		else
			log("Não achei o osso da cabeça; 'Esconder a cabeça' não vai funcionar", LogLevel.Warning)
		end
	end

	-- braços: lê a configuração gravada para saber quais solvers existem
	-- (não dá para ler do rig: quando o nome do osso está errado o ik.lua
	--  descarta o solver e ele nem aparece em rig.activeSolvers)
	if json == nil then return false end
	local params = json.load_file("ik_parameters.json")
	local rigParams = params ~= nil and params[rig.rigId or ""] or nil
	local solvers = rigParams ~= nil and rigParams.solvers or nil
	if solvers == nil then return false end

	local changed = false
	for solverId, solverParams in pairs(solvers) do
		if force then solverParams["end_bone"] = "" end
		if fixSolverBones(rig, mesh, names, set, solverId, solverParams) then
			changed = true
		end
	end
	return changed
end

--------------------------------------------------------------------------
-- Visibilidade
--------------------------------------------------------------------------

-- Roda a cada frame quando a animação do corpo está ligada, então usa o struct
-- reutilizável: é o mesmo vetor para todas as malhas do laço, consumido na hora.
local function applyHeadVisibility()
	local hideHead = configui.getValue("body_hideHead") == true
	local scale = hideHead and uevrUtils.vector(0.001, 0.001, 0.001, true) or uevrUtils.vector(1.0, 1.0, 1.0, true)
	for _, mesh in ipairs(bodyMeshes) do
		if uevrUtils.getValid(mesh) ~= nil and mesh.SetBoneScaleByName ~= nil then
			mesh:SetBoneScaleByName(uevrUtils.fname_from_string(headBone), scale, EBoneSpaces.ComponentSpace)
		end
	end
end

local function applyShadowSetting()
	local castShadow = configui.getValue("body_shadow") == true
	for _, mesh in ipairs(bodyMeshes) do
		if uevrUtils.getValid(mesh) ~= nil then
			mesh.bCastDynamicShadow = castShadow
			-- BoundsScale grande evita que o corpo seja descartado pelo frustum
			-- quando a origem da malha (nos pés) sai do campo de visão. O ik.lua
			-- já põe 16 na criação; reafirmamos porque é barato e é o tipo de
			-- coisa que, se falhar, o sintoma é o corpo sumindo.
			mesh.BoundsScale = 16.0
			-- bRenderInDepthPass NÃO é forçado: o exemplo do ik.md desliga, mas
			-- em Native Stereo tirar a malha do depth prepass é candidato a
			-- artefato de render. Fica o padrão do motor.
		end
	end
end

-- O corpo some em terceira pessoa e em cinemáticas, porque nesses casos o jogo
-- mostra o personagem original. Na montaria (vassoura/hipogrifo) é opcional: o
-- perfil esconde o jogador em primeira pessoa, então esconder o corpo também
-- deixa você sem corpo nenhum em cima da vassoura.
local function shouldHideBody()
	if configui.getValue("isFP") == false then return true end
	if not mounts.isWalking() and configui.getValue("body_hideOnMount") == true then return true end
	local playerPawn = uevrUtils.getValid(pawn)
	if playerPawn == nil then return true end
	if playerPawn.InCinematic == true then return true end
	return false
end

-- O ik.lua consulta este callback a cada 200ms e esconde/mostra o corpo quando
-- a resposta muda. Se alguma das condições oscilar (o pawn.InCinematic entra e
-- sai durante certas animações), isso vira pisca-pisca a 5Hz. Por isso só
-- escondemos depois de duas leituras seguidas pedindo para esconder — voltar a
-- aparecer continua imediato.
local hideStreak = 0
local bodyHidden = false

-- Estado JÁ FILTRADO, e é este que o resto do arquivo deve usar.
--
-- Chamar shouldHideBody() cru a cada frame era um erro meu: as pernas, a
-- posição do corpo e a câmera faziam isso, e o InCinematic — que este arquivo
-- já documentava como instável — ligava e desligava as três de um frame para o
-- outro. O corpo parava e voltava, e com a câmera na cabeça ela ainda saltava
-- entre o osso da cabeça e a câmera normal do perfil. Dava exatamente a
-- "flicada", e mais forte com a câmera na cabeça ligada.
local function isBodyHidden()
	return bodyHidden
end

uevrUtils.registerUEVRCallback("is_hands_hidden", function()
	if not isEnabled() then return nil end
	if shouldHideBody() then
		hideStreak = hideStreak + 1
	else
		hideStreak = 0
	end
	bodyHidden = hideStreak >= 2
	return bodyHidden, 20
end)

-- NOTA: existiu aqui uma "trava de cabeça" que mexia na POSIÇÃO do corpo a cada
-- frame para encostar o osso da cabeça no HMD. Ela era a causa do corpo piscar e
-- foi removida. A posição é configurada em jogo, pelo campo "Posicao".

--------------------------------------------------------------------------
-- 1. Animação das pernas — receita do perfil do Silent Hill f, restrita
--
-- O ik.lua cria o corpo com useDefaultPose = true, ou seja, pose de referência
-- parada, e só mexe nos braços. É por isso que as pernas não andavam.
--
-- No Silent Hill f o corpo ganha animação copiando a pose da malha que o jogo
-- anima (libs/montage.lua dispara isso por montagem). Copiar a pose INTEIRA,
-- porém, anima o corpo todo — e aí o tronco, a cabeça e principalmente os dedos
-- passam a seguir a animação do jogo em vez do VR. Então copiamos só a subárvore
-- de ossos das pernas, da coxa para baixo, e o resto fica como estava.
--
-- A conta é a mesma do animation.copyDescendantTransforms da lib: lê o osso na
-- malha de origem em espaço de componente, e reancora no quadril da cópia, que
-- continua parado. Por isso as pernas andam "penduradas" na cintura do corpo VR
-- em vez de arrastarem o corpo junto.
--
-- Um detalhe que também veio do SHf: o pawn_parameters.json deles esconde o
-- corpo real com `hideSettingsRenderInMainPass` em vez de SetVisibility,
-- justamente para a malha continuar animando. O perfil do Hogwarts usa
-- SetVisibility, então forçamos VisibilityBasedAnimTickOption nas malhas de
-- origem para os ossos continuarem sendo atualizados mesmo escondidas.
--------------------------------------------------------------------------

local RTS_COMPONENT = 2 -- ERelativeTransformSpace::RTS_Component

local FOOT_NAMES = {
	[Handed.Right] = { "rightfoot", "foot_r", "r_foot", "bip01 r foot", "mixamorig:rightfoot" },
	[Handed.Left]  = { "leftfoot",  "foot_l", "l_foot", "bip01 l foot", "mixamorig:leftfoot"  },
}
local NOT_A_FOOT = { "toe", "ball", "ik", "attach", "socket", "twist", "roll", "ctrl", "helper", "end", "tip" }

local legBones = nil       -- { {name=..., fname=...}, ... } coxa para baixo
local legAnchorFName = nil -- quadril: a âncora das pernas

-- Posição do quadril na POSE DE REFERÊNCIA, capturada quando o corpo nasce.
-- É a partir dela que o quadril é reposicionado a cada frame — nunca a partir
-- do valor lido de volta do osso, que é o que nós mesmos escrevemos no frame
-- anterior e faria a posição derivar sozinha.
local referenceHip = nil
-- Altura do quadril na malha de ORIGEM com o personagem em pé, capturada no
-- primeiro frame. É contra esta que o agachamento é medido, e não contra a pose
-- de referência: as duas não coincidem. A pose de referência é a bind pose crua
-- (perna reta), enquanto a pose animada de "em pé" tem sempre um joelho mole —
-- a diferença entre elas é livre, pode ser para cima ou para baixo, e entrava
-- inteira na conta do agachamento. Se a bind pose fosse mais BAIXA que o "em
-- pé" animado, a diferença comia a folga e o agachamento quase não passava.
local standingSourceHipZ = nil
-- O quanto o quadril está abaixado agora (0 = em pé), suavizado.
local hipDrop = 0

-- O quadril da animação balança o tempo todo: sobe e desce a cada passo e joga
-- para os lados. Como o tronco é filho do quadril, copiar esse balanço fazia o
-- TRONCO INTEIRO (e a câmera presa na cabeça dele) balançar junto.
--
-- Separação por amplitude, que aqui é limpa: o balanço do andar fica na casa
-- dos 2-4 cm, um agachamento passa de 30. Abaixo do limite não é agachamento, é
-- balanço, e vira zero. O lerp só suaviza a transição.
local HIP_DROP_DEADZONE = 8.0
local HIP_DROP_LERP = 10.0

local function keepSourceMeshesAnimating(rig)
	for _, template in pairs(rig.meshTemplates or {}) do
		local source = template.instance
		if uevrUtils.getValid(source) ~= nil and source.VisibilityBasedAnimTickOption ~= nil then
			source.VisibilityBasedAnimTickOption = ALWAYS_TICK_POSE_AND_REFRESH_BONES
		end
	end
end

local function detectFootBone(names, set, side)
	for _, candidate in ipairs(FOOT_NAMES[side]) do
		if set[candidate] ~= nil then return set[candidate] end
	end
	for _, keyword in ipairs({ "foot", "ankle" }) do
		local best = nil
		for _, name in ipairs(names) do
			local lower = string.lower(name)
			if string.find(lower, keyword, 1, true) ~= nil
				and not containsAny(lower, NOT_A_FOOT)
				and hasSideMarker(lower, side)
				and (best == nil or #name < #best)
			then
				best = name
			end
		end
		if best ~= nil then return best end
	end
	return nil
end

-- Acha o pé de cada lado e sobe a hierarquia: pé -> canela -> coxa -> quadril.
-- A lista final é coxa + todos os descendentes dela (canela, pé, dedos, twist).
local function detectLegBones(mesh)
	legBones, legAnchorFName = nil, nil
	referenceHip, standingSourceHipZ, hipDrop = nil, nil, 0
	if uevrUtils.getValid(mesh) == nil then return end

	local names = uevrUtils.getBoneNames(mesh)
	if names == nil or #names == 0 then return end
	local set = toBoneSet(names)

	local bones, anchor = {}, nil
	for _, side in ipairs({ Handed.Right, Handed.Left }) do
		local foot = detectFootBone(names, set, side)
		if foot ~= nil then
			local chain = getBoneChain(mesh, foot, 4) -- {pé, canela, coxa, quadril}
			if #chain >= 4 then
				local thigh = chain[3]
				anchor = anchor or chain[4]
				table.insert(bones, thigh)
				for _, descendant in ipairs(animation.getDescendantBones(mesh, thigh, false)) do
					table.insert(bones, descendant)
				end
			end
		end
	end

	if #bones == 0 or anchor == nil then
		log("Não achei os ossos das pernas — a animação das pernas fica desligada", LogLevel.Warning)
		return
	end

	legBones = {}
	for _, name in ipairs(bones) do
		table.insert(legBones, { name = name, fname = uevrUtils.fname_from_string(name) })
	end
	legAnchorFName = uevrUtils.fname_from_string(anchor)

	-- A cópia ainda está na pose de referência aqui (nasce com
	-- useDefaultPose = true e nada escreveu nela), então este é o único momento
	-- em que dá para ler a posição "de pé" do quadril.
	local hipTransform = mesh:GetBoneTransformByName(legAnchorFName, EBoneSpaces.ComponentSpace)
	if hipTransform ~= nil and hipTransform.Translation ~= nil then
		referenceHip = {
			X = hipTransform.Translation.X,
			Y = hipTransform.Translation.Y,
			Z = hipTransform.Translation.Z,
		}
	end

	logMilestone("Pernas: " .. #legBones .. " ossos, ancoradas em " .. anchor
		.. ", quadril de pe em Z=" .. (referenceHip and string.format("%.1f", referenceHip.Z) or "?"))
end

-- A malha de origem da cópia principal é quem carrega a animação do jogo.
local function getSourceMesh()
	if currentRig == nil then return nil end
	local reference = bodyMeshes[1]
	if reference == nil then return nil end
	for _, template in pairs(currentRig.meshTemplates or {}) do
		if template.mesh == reference then return template.instance end
	end
	return nil
end

local function copyLegPose(engine, delta)
	if not isEnabled() or currentRig == nil or legBones == nil then return end
	if configui.getValue("body_animate") == false then return end
	if configui.getValue("body_onlyArms") == true then return end
	if isBodyHidden() then return end

	local reference = bodyMeshes[1]
	if uevrUtils.getValid(reference) == nil or reference.SetBoneTransformByName == nil then return end

	local source = getSourceMesh()
	if uevrUtils.getValid(source) == nil or source.GetSocketTransform == nil then return end

	local sourceAnchor = source:GetSocketTransform(legAnchorFName, RTS_COMPONENT)
	local targetAnchor = reference:GetBoneTransformByName(legAnchorFName, EBoneSpaces.ComponentSpace)
	if sourceAnchor == nil or targetAnchor == nil then return end

	-- O quadril continua sendo ÂNCORA — é o que mantém o tronco parado. A única
	-- coisa que a animação move nele é a ALTURA, e só quando é agachamento de
	-- verdade (ver HIP_DROP_DEADZONE): copiar a translação inteira trazia junto
	-- o balanço de cada passo, e o tronco, que é filho do quadril, balançava
	-- todo — com a câmera presa na cabeça, direto no olho.
	--
	-- X e Y vêm sempre da pose de referência. A rotação também fica intocada: o
	-- quadril é a raiz do esqueleto, então girá-lo giraria o tronco inteiro e
	-- brigaria com o "Corpo acompanha a visao".
	--
	-- Tudo é reconstruído a partir de referenceHip, capturado na criação, e não
	-- do que está no osso: o osso guarda o que escrevemos no frame anterior, e
	-- realimentar isso faria a posição derivar sozinha.
	-- linha do "em pé", medida na própria malha animada no primeiro frame
	if standingSourceHipZ == nil then
		standingSourceHipZ = sourceAnchor.Translation.Z
	end

	if referenceHip ~= nil then
		local target = 0
		if configui.getValue("body_followCrouch") ~= false then
			-- só para baixo, e só o que passar da folga: andar não é agachar
			target = math.min(0, sourceAnchor.Translation.Z - standingSourceHipZ + HIP_DROP_DEADZONE)
		end
		if delta ~= nil and delta > 0 then
			hipDrop = hipDrop + (target - hipDrop) * math.min(1, HIP_DROP_LERP * delta)
		else
			hipDrop = target
		end

		-- escrito sempre, inclusive com hipDrop = 0: é assim que o quadril volta
		-- para a altura de pé quando o agachamento é desligado no painel
		targetAnchor.Translation.X = referenceHip.X
		targetAnchor.Translation.Y = referenceHip.Y
		targetAnchor.Translation.Z = referenceHip.Z + hipDrop

		for _, component in ipairs(bodyMeshes) do
			if uevrUtils.getValid(component) ~= nil and component.SetBoneTransformByName ~= nil then
				component:SetBoneTransformByName(legAnchorFName, targetAnchor, EBoneSpaces.ComponentSpace)
			end
		end
	end

	-- As pernas são reancoradas no quadril (que agora pode estar abaixado), então
	-- elas continuam rigidamente presas a ele — sem rasgo na cintura. Parado ou
	-- agachado de verdade, hipDrop bate com o agachamento da animação e os pés
	-- caem no lugar certo; andando, sobra a diferença do balanço, que é o
	-- deslizezinho de pé que o método sempre teve.
	local align = kismet_math_library:ComposeTransforms(
		kismet_math_library:InvertTransform(sourceAnchor), targetAnchor)

	-- Ajuste manual das pernas, do painel. Entra DEPOIS da reancoragem, em
	-- espaço de componente, então é um empurrão simples no conjunto todo — coxa,
	-- canela, pé e dedos andam juntos e continuam presos entre si.
	--
	-- Serve para o caso de as pernas nascerem deslocadas do tronco: como elas
	-- são reancoradas no quadril e o tronco fica na pose de referência, uma
	-- diferença entre as duas poses aparece como perna fora do lugar. Aqui você
	-- corrige sem mexer em nada mais.
	local legOffset = configui.getValue("body_legOffset")
	local lx = legOffset and (legOffset.x or legOffset.X or 0) or 0
	local ly = legOffset and (legOffset.y or legOffset.Y or 0) or 0
	local lz = legOffset and (legOffset.z or legOffset.Z or 0) or 0
	local hasLegOffset = (lx ~= 0 or ly ~= 0 or lz ~= 0)

	for _, bone in ipairs(legBones) do
		local transform = source:GetSocketTransform(bone.fname, RTS_COMPONENT)
		if transform ~= nil then
			local aligned = kismet_math_library:ComposeTransforms(transform, align)
			if hasLegOffset and aligned.Translation ~= nil then
				aligned.Translation.X = aligned.Translation.X + lx
				aligned.Translation.Y = aligned.Translation.Y + ly
				aligned.Translation.Z = aligned.Translation.Z + lz
			end
			for _, component in ipairs(bodyMeshes) do
				if uevrUtils.getValid(component) ~= nil and component.SetBoneTransformByName ~= nil then
					component:SetBoneTransformByName(bone.fname, aligned, EBoneSpaces.ComponentSpace)
				end
			end
		end
	end
end

-- Prioridade 10 = roda ANTES do tick do ik.lua (que é 0). Como só mexemos em
-- osso de perna e o IK só mexe em braço, os dois não se atropelam.
uevrUtils.registerPreEngineTickCallback(function(engine, delta)
	local ok, err = pcall(copyLegPose, engine, delta)
	if not ok then
		log("Falha ao animar as pernas: " .. tostring(err), LogLevel.Warning)
	end
end, 10)

--------------------------------------------------------------------------
-- 1b. SÓ MONTADO: destravar o Z do ik.lua para os braços mirarem certo
--
-- Era este o motivo das mãos ficarem paradas no hipogrifo, e não o solver.
--
-- O tick do ik.lua (ik.lua:417) começa escrevendo, todo frame,
--     RelativeLocation.Z = offset + (offset + CapsuleHalfHeight)
-- e SÓ DEPOIS resolve os braços. Montado numa criatura, o pawn é a CRIATURA e
-- essa cápsula é enorme: a cópia era atirada para longe em Z bem no instante em
-- que os solvers convertem a posição dos controles para o espaço do componente.
-- O alvo caía fora do alcance do braço, o solver saturava, e a mão congelava
-- numa pose só. A imagem parecia certa porque a posição era corrigida logo
-- depois, no tick de prioridade -10 (o "corpo copia a malha do jogo").
--
-- A saída é do próprio ik.lua: com `coupling == 2` ele não toca no Z
-- (ik.lua:418). Trocamos o campo na instância do rig só enquanto estiver
-- montado, e devolvemos o valor original ao desmontar.
--
-- Duas condições de segurança:
--   * só quando "corpo copia a malha do jogo" está ligado — é ele que escreve a
--     posição do corpo montado. Sem ele, ninguém cuidaria do Z;
--   * a devolução compara antes de escrever, então A PÉ ISTO É UM NO-OP: o
--     valor já é o original e nada é tocado.
--
-- Prioridade 20 = antes de tudo o que é nosso e antes do ik.lua.
--------------------------------------------------------------------------

--------------------------------------------------------------------------
-- SÓ MONTADO: o ik.lua tem que olhar para o PERSONAGEM, não para a criatura.
--
-- O rig não resolve tudo pela malha: em dois pontos ele vai buscar o pawn —
-- `ik.lua:493` (a quem o corpo é anexado, no `RootComponent`) e `ik.lua:411`
-- (a `CapsuleHalfHeight` que entra na conta do Z a cada tick). Montado numa
-- criatura o pawn controlado É A CRIATURA, então o corpo do bruxo era ancorado
-- na raiz do hipogrifo e recebia a altura de cápsula dele.
--
-- O próprio ik.lua já prevê isso e nunca era usado: `M.setPawn` (ik.lua:80)
-- troca só essa referência — `getPawn()` devolve `pawnObject or pawn`. Não mexe
-- em quem o jogo controla, só em de onde o rig lê raiz e cápsula.
--
-- A PÉ É UM NO-OP: `getMountPawn` devolve o próprio pawn, e nada muda.
--------------------------------------------------------------------------
local lastRigPawn = nil

local function updateRigPawn()
	local playerPawn = uevrUtils.getValid(pawn)
	if playerPawn == nil then
		-- sem pawn válido, devolve o padrão: com pawnObject nil o getPawn()
		-- do ik.lua cai sozinho no pawn global.
		if lastRigPawn ~= nil then
			lastRigPawn = nil
			ik.setPawn(nil)
		end
		return
	end

	local rigPawn = uevrUtils.getValid(mounts.getMountPawn(playerPawn)) or playerPawn
	if rigPawn == lastRigPawn then return end
	lastRigPawn = rigPawn

	ik.setPawn(rigPawn)
	if rigPawn ~= playerPawn then
		logMilestone("Montado: ik.lua ancorado no personagem, nao na criatura")
	else
		logMilestone("ik.lua ancorado no pawn controlado")
	end
end

-- valor original do `coupling` do rig (vem de parent_type), guardado na criação
local rigCoupling = nil

local function updateMountCoupling()
	if currentRig == nil then return end

	local wantFree = not mounts.isWalking()
		and configui.getValue("body_mountArmsIK") ~= false
		and configui.getValue("body_mountFollowMesh") ~= false

	if wantFree then
		if currentRig.coupling ~= 2 then
			currentRig.coupling = 2
			logMilestone("Montado: Z do ik.lua liberado, bracos miram na posicao real do corpo")
		end
	elseif rigCoupling ~= nil and currentRig.coupling ~= rigCoupling then
		currentRig.coupling = rigCoupling
		logMilestone("Desmontado: Z do ik.lua devolvido (coupling " .. tostring(rigCoupling) .. ")")
	end
end

-- DIAGNÓSTICO, sem efeito nenhum no jogo: registra no log toda vez que o estado
-- de montaria MUDA, com os números crus do momento. É o que responde, sem
-- adivinhação, duas perguntas que o log de hoje deixou em aberto:
--
--   * o estado de montaria oscila sozinho? (no log de 06/08 houve um
--     "desmontado" seguido de "montado" 0,5 s depois, o que não é gente
--     desmontando — e cada oscilação joga o corpo entre a conta de quem está
--     montado e a de quem está a pé);
--   * montado, onde estão de fato a malha do jogo, a cópia e a sua cabeça.
-- Ossos do braço direito, só para o diagnóstico abaixo.
local diagArmBone, diagHandBone = nil, nil

local function detectDiagArmBones(mesh)
	diagArmBone, diagHandBone = nil, nil
	if uevrUtils.getValid(mesh) == nil then return end
	local names = uevrUtils.getBoneNames(mesh)
	if names == nil or #names == 0 then return end
	local hand = detectHandBone(names, toBoneSet(names), Handed.Right)
	if hand == nil then return end
	local chain = getBoneChain(mesh, hand, 5)
	diagHandBone = uevrUtils.fname_from_string(hand)
	if chain[3] ~= nil then diagArmBone = uevrUtils.fname_from_string(chain[3]) end
end

-- DIAGNÓSTICO DOS BRAÇOS, sem efeito no jogo. A cada 2 s, e só montado, anota o
-- que decide se a mão segue o controle:
--
--   * "animando pela malha" — se algum callback `is_hands_animating_from_mesh`
--     responder true, o ik.lua NEM CHAMA os solvers (ik.lua:435): ele copia a
--     pose do braço da malha do jogo. Mão parada segurando a rédea seria
--     exatamente isso;
--   * ombro, mão e controle em MUNDO, mais a distância ombro→controle. Se essa
--     distância for muito maior que o braço, o solver satura e a mão congela no
--     limite do alcance, mesmo rodando normalmente.
local diagTimer = 0

local function logArmDiagnostics(delta)
	if mounts.isWalking() then diagTimer = 0 return end
	if currentRig == nil or #bodyMeshes == 0 then return end
	diagTimer = diagTimer + (delta or 0)
	if diagTimer < 2.0 then return end
	diagTimer = 0

	local mesh = bodyMeshes[1]
	if uevrUtils.getValid(mesh) == nil or mesh.GetBoneLocationByName == nil then return end

	local function fmt(v)
		if v == nil then return "nil" end
		return string.format("(%.0f, %.0f, %.0f)", v.X or 0, v.Y or 0, v.Z or 0)
	end

	local animLeft = uevrUtils.executeUEVRCallbacksWithPriorityBooleanResult(
		"is_hands_animating_from_mesh", Handed.Left)
	local animRight = uevrUtils.executeUEVRCallbacksWithPriorityBooleanResult(
		"is_hands_animating_from_mesh", Handed.Right)

	local shoulder = diagArmBone ~= nil and mesh:GetBoneLocationByName(diagArmBone, EBoneSpaces.WorldSpace) or nil
	local hand = diagHandBone ~= nil and mesh:GetBoneLocationByName(diagHandBone, EBoneSpaces.WorldSpace) or nil
	local controller = controllers.getController(1)
	local controllerLoc = uevrUtils.getValid(controller) ~= nil and controller:K2_GetComponentLocation() or nil

	local reach = "?"
	if shoulder ~= nil and controllerLoc ~= nil then
		reach = string.format("%.0f", kismet_math_library:Vector_Distance(shoulder, controllerLoc))
	end
	local erro = "?"
	if hand ~= nil and controllerLoc ~= nil then
		erro = string.format("%.0f", kismet_math_library:Vector_Distance(hand, controllerLoc))
	end

	local solvers = 0
	for _ in pairs(currentRig.activeSolvers or {}) do solvers = solvers + 1 end

	logMilestone("[bracos] solvers=" .. solvers
		.. ", animando pela malha: esq=" .. tostring(animLeft) .. " dir=" .. tostring(animRight)
		.. ", ombro=" .. fmt(shoulder) .. ", mao=" .. fmt(hand)
		.. ", controle=" .. fmt(controllerLoc)
		.. ", ombro->controle=" .. reach .. "cm, mao->controle=" .. erro .. "cm")
end

local lastLoggedMountType = nil

local function logMountStateChange()
	local mountType = mounts.getMountType()
	if mountType == lastLoggedMountType then return end
	lastLoggedMountType = mountType

	local function fmt(v)
		if v == nil then return "nil" end
		return string.format("(%.0f, %.0f, %.0f)", v.X or 0, v.Y or 0, v.Z or 0)
	end
	local function nameOf(obj)
		if uevrUtils.getValid(obj) == nil or obj.get_full_name == nil then return "nil" end
		local full = obj:get_full_name()
		return full:sub(-60)
	end

	-- O TIPO SAI PRIMEIRO, antes de qualquer coisa que possa estourar. Estava no
	-- fim: bastava uma das leituras abaixo falhar para a linha inteira sumir, e
	-- como `lastLoggedMountType` já foi atualizado acima, aquela transição nunca
	-- mais era registrada. Foi assim que a montaria em criatura passou batida.
	logMilestone("--- montaria mudou: tipo=" .. tostring(mountType)
		.. ", voando=" .. tostring(mounts.getIsFlying()) .. " ---")

	local playerPawn = uevrUtils.getValid(pawn)
	local rider = playerPawn ~= nil and uevrUtils.getValid(mounts.getMountPawn(playerPawn)) or nil
	local source = getSourceMesh()
	local mesh = bodyMeshes[1]
	local hmd = controllers.getController(2)
	local root = uevrUtils.getValid(playerPawn, {"RootComponent"})
	logMilestone("  pawn=" .. nameOf(playerPawn) .. ", personagem=" .. nameOf(rider))
	logMilestone("  capsula=" .. tostring(root ~= nil and root.CapsuleHalfHeight or "nil")
		.. ", root=" .. fmt(root ~= nil and root:K2_GetComponentLocation() or nil))
	logMilestone("  malha do jogo=" .. nameOf(source) .. " em "
		.. fmt(uevrUtils.getValid(source) ~= nil and source:K2_GetComponentLocation() or nil))
	logMilestone("  copia=" .. fmt(uevrUtils.getValid(mesh) ~= nil and mesh:K2_GetComponentLocation() or nil)
		.. ", cabeca=" .. fmt(uevrUtils.getValid(mesh) ~= nil and mesh.GetSocketLocation ~= nil
			and mesh:GetSocketLocation(uevrUtils.fname_from_string(headBone)) or nil)
		.. ", HMD=" .. fmt(uevrUtils.getValid(hmd) ~= nil and hmd:K2_GetComponentLocation() or nil))
end

-- Estas falhas iam como Warning e o filtro do perfil é Error, então NUNCA
-- chegavam no log.txt: um pcall que estoura todo frame ficava completamente
-- invisível. Agora vão como marco (Error), e cada mensagem distinta sai só uma
-- vez para não encher o arquivo a 30 Hz.
local loggedTickFailures = {}

local function logTickFailure(prefix, err)
	local text = prefix .. ": " .. tostring(err)
	if loggedTickFailures[text] then return end
	loggedTickFailures[text] = true
	logMilestone(text)
end

uevrUtils.registerPreEngineTickCallback(function(engine, delta)
	-- antes do coupling: quem for refazer o rig neste frame já pega o pawn certo
	local okPawn, errPawn = pcall(updateRigPawn)
	if not okPawn then
		logTickFailure("Falha ao apontar o pawn do rig", errPawn)
	end
	local ok, err = pcall(updateMountCoupling)
	if not ok then
		logTickFailure("Falha ao ajustar o coupling na montaria", err)
	end
	local okLog, errLog = pcall(logMountStateChange)
	if not okLog then
		logTickFailure("Falha ao registrar a mudanca de montaria", errLog)
	end
	local okArms, errArms = pcall(logArmDiagnostics, delta)
	if not okArms then
		logTickFailure("Falha no diagnostico dos bracos", errArms)
	end
end, 20)

--------------------------------------------------------------------------
-- 1c. SÓ MONTADO (criatura): o tronco acompanha o headset
--
-- Na montaria o corpo não tem yaw próprio — ele herda a rotação da malha do
-- jogo, que aponta para onde a criatura aponta. Olhar para o lado deixava você
-- de perfil dentro do próprio corpo. Aqui o tronco gira para onde você olha,
-- com zona morta, sensibilidade e limite, sem NADA se mover: nem o jogador, nem
-- a criatura, nem a posição do corpo. É só a rotação de um osso.
--
-- POR QUE NA CINTURA E NÃO NO QUADRIL. As pernas penduram no quadril: girá-lo
-- levaria as duas junto e tiraria os pés do estribo. Girando o osso logo acima
-- dele — o primeiro da coluna — sobe tudo o que tem que subir (tronco, ombros,
-- braços, pescoço, cabeça) e as pernas ficam onde a animação as pôs. O efeito é
-- o mesmo que você descreveu; muda só onde a torção começa.
--
-- O "endireitar a coluna" não entra aqui de propósito: neste modo a cópia está
-- em pose de referência do peito para cima, ou seja, já ereta. Não há reclinada
-- para corrigir — ela só apareceria se a pose do jogo fosse copiada.
--
-- A rotação é sempre calculada a partir da POSE DE REFERÊNCIA capturada na
-- criação, nunca do que está no osso: o osso guarda o que nós escrevemos no
-- frame anterior, e realimentar isso faria a torção crescer sozinha.
--
-- Prioridade 5 = depois das pernas (10) e antes do IK (0), para os braços serem
-- resolvidos já com o tronco na direção final.
--------------------------------------------------------------------------

local waistFName    = nil   -- primeiro osso da coluna (filho do quadril)
local waistRef      = nil   -- pose de referência dele, em números
local waistYawState = 0     -- torção já aplicada (suavizada)
local waistApplied  = false -- há uma torção escrita no osso agora?
local waistWarned   = false

local WAIST_LERP = 8.0

local function detectWaistBone(mesh)
	waistFName, waistRef, waistYawState, waistApplied = nil, nil, 0, false
	if uevrUtils.getValid(mesh) == nil or legAnchorFName == nil then return end
	if mesh.GetParentBone == nil or mesh.GetBoneTransformByName == nil then return end

	local names = uevrUtils.getBoneNames(mesh)
	if names == nil or #names == 0 then return end

	-- filho direto do quadril que não é perna: é a cintura. Entre candidatos
	-- vence o nome mais curto, que é sempre a raiz da coluna (Spine, e não
	-- Spine_twist_01 e afins).
	local isLeg = {}
	for _, bone in ipairs(legBones or {}) do isLeg[string.lower(bone.name)] = true end

	local hipName = legAnchorFName:to_string()
	local best = nil
	for _, name in ipairs(names) do
		if not isLeg[string.lower(name)] then
			local parent = mesh:GetParentBone(uevrUtils.fname_from_string(name))
			if parent ~= nil and parent:to_string() == hipName then
				if best == nil or #name < #best then best = name end
			end
		end
	end

	if best == nil then
		log("Não achei o osso da cintura — o tronco não vai acompanhar a visão na montaria", LogLevel.Warning)
		return
	end

	local fname = uevrUtils.fname_from_string(best)
	-- A cópia ainda está na pose de referência aqui (nasce com useDefaultPose e
	-- nada escreveu nela), então este é o único momento em que dá para ler a
	-- pose "neutra" da cintura.
	local transform = mesh:GetBoneTransformByName(fname, EBoneSpaces.ComponentSpace)
	local q = transform ~= nil and transform.Rotation or nil
	if transform == nil or transform.Translation == nil or q == nil or q.W == nil then
		log("Não consegui ler a pose da cintura ('" .. best .. "')", LogLevel.Warning)
		return
	end

	local rot = uevrUtils.rotatorFromQuat(q.X, q.Y, q.Z, q.W)
	local scale = transform.Scale3D
	waistFName = fname
	-- guardado em NÚMEROS: struct do motor devolvida por Get... é reaproveitada
	waistRef = {
		lx = transform.Translation.X, ly = transform.Translation.Y, lz = transform.Translation.Z,
		pitch = rot.Pitch, yaw = rot.Yaw, roll = rot.Roll,
		sx = scale ~= nil and scale.X or 1, sy = scale ~= nil and scale.Y or 1,
		sz = scale ~= nil and scale.Z or 1,
	}

	logMilestone("Cintura: '" .. best .. "' (acima de '" .. hipName .. "')")
end

local function writeWaist(yaw)
	local rotation = uevrUtils.rotator(waistRef.pitch, waistRef.yaw, waistRef.roll)
	if yaw ~= 0 then
		rotation = kismet_math_library:ComposeRotators(rotation, uevrUtils.rotator(0, yaw, 0))
	end
	local transform = kismet_math_library:MakeTransform(
		uevrUtils.vector(waistRef.lx, waistRef.ly, waistRef.lz),
		rotation,
		uevrUtils.vector(waistRef.sx, waistRef.sy, waistRef.sz))
	for _, component in ipairs(bodyMeshes) do
		if uevrUtils.getValid(component) ~= nil and component.SetBoneTransformByName ~= nil then
			component:SetBoneTransformByName(waistFName, transform, EBoneSpaces.ComponentSpace)
		end
	end
end

local function waistFollowActive()
	if waistFName == nil or waistRef == nil then return false end
	if not isEnabled() or currentRig == nil or #bodyMeshes == 0 then return false end
	if mounts.isWalking() then return false end
	-- vassoura fica de fora: lá a regra é não modificar nada
	if mounts.isOnBroom() then return false end
	if configui.getValue("body_mountHipAlign") == false then return false end
	if configui.getValue("body_mountFollowMesh") == false then return false end
	if isBodyHidden() then return false end
	return true
end

local function updateWaistFollow(engine, delta)
	if not waistFollowActive() then
		-- Desmontou: devolve a cintura à pose de referência UMA vez. Sem isto o
		-- osso guardaria a última torção para sempre, porque a pé ninguém mais
		-- escreve nele. Em regime, a pé, isto não escreve nada.
		if waistApplied then
			waistApplied = false
			waistYawState = 0
			local ok = pcall(writeWaist, 0)
			if not ok and not waistWarned then
				waistWarned = true
				logMilestone("Cintura: nao consegui devolver a pose de referencia")
			end
		end
		return
	end

	local hmd = controllers.getController(2)
	local mesh = bodyMeshes[1]
	if uevrUtils.getValid(hmd) == nil or uevrUtils.getValid(mesh) == nil then return end

	local hmdRot = hmd:K2_GetComponentRotation()
	local bodyRot = mesh:K2_GetComponentRotation()
	if hmdRot == nil or bodyRot == nil then return end

	-- Montado, a rotação do corpo é a da malha do jogo (o "corpo copia a malha"
	-- escreve ela inteira), então o quanto você está torcido é simplesmente a
	-- diferença entre o headset e ela.
	local diff = uevrUtils.clampAngle180(hmdRot.Yaw - bodyRot.Yaw)

	local deadzone = configui.getValue("body_mountHipDeadzone") or 0
	local target = 0
	if math.abs(diff) > deadzone then
		local sign = diff >= 0 and 1 or -1
		target = (diff - sign * deadzone) * (configui.getValue("body_mountHipSensitivity") or 0)
		local limit = configui.getValue("body_mountHipMaxYaw") or 60
		target = math.max(-limit, math.min(limit, target))
	end

	if delta ~= nil and delta > 0 then
		waistYawState = waistYawState + (target - waistYawState) * math.min(1, WAIST_LERP * delta)
	else
		waistYawState = target
	end

	waistApplied = true
	writeWaist(waistYawState)
end

uevrUtils.registerPreEngineTickCallback(function(engine, delta)
	local ok, err = pcall(updateWaistFollow, engine, delta)
	if not ok then
		log("Falha ao girar a cintura: " .. tostring(err), LogLevel.Warning)
	end
end, 5)

--------------------------------------------------------------------------
-- 2. Altura do corpo: agachar no jogo e agachar de verdade
--
-- Dois problemas diferentes com o mesmo sintoma — o corpo parece SUBIR quando
-- você abaixa.
--
-- (a) AGACHAR NO JOGO. O ik.lua tira a altura do corpo do CapsuleHalfHeight
--     (ik.lua:417: RelativeLocation.Z = off + (off + altura)), e a cápsula
--     encolhe ao agachar. O pawn também desce junto. Em vez de adivinhar
--     quanto vem de cada um — o que dependeria de como o motor trata
--     bCrouchMaintainsBaseLocation neste jogo —, medimos o resultado: a malha
--     de ORIGEM (Pawn.Mesh) é posicionada pelo próprio jogo e está sempre com
--     os pés no lugar certo. A distância entre a origem dela e a nossa é
--     constante enquanto está tudo bem; o que mudar nela é erro nosso, e é o
--     que devolvemos. Sem suposição nenhuma sobre a cápsula.
--
--     Isso mantém os PÉS plantados. Quem faz o corpo realmente agachar é a
--     cópia da translação do quadril, na seção 1.
--
-- (b) AGACHAR DE VERDADE, no espaço real. O "Corpo segue a posicao da cabeca"
--     sempre tratou só X e Y — o Z nunca seguiu o HMD (está escrito lá: "Só X
--     e Y"). Então o corpo continuava de pé enquanto você abaixava e o tronco
--     subia na sua frente. Agora o HMD abaixo da linha de referência desce o
--     corpo junto.
--
--     Isto NÃO é a "trava de cabeça" que fazia o corpo piscar. Aquela empurrava
--     o corpo até o osso da cabeça encostar no HMD a cada frame, realimentando
--     a própria medida — corpo move, medida muda, corpo move de novo. Aqui a
--     conta é aberta: HMD contra uma linha de referência fixa, capturada quando
--     o corpo nasce. Não lê nada que a gente mesmo escreveu, e só desce.
--------------------------------------------------------------------------

-- altura do HMD sobre o pawn quando o corpo nasceu (a linha de referência de (b))
local standingHeadZ = nil
-- o quanto o corpo já desceu por causa do agachamento real, suavizado
local duckOffset = 0

local function resetHeightCalibration()
	standingHeadZ = nil
	standingSourceHipZ = nil -- a linha do "em pé" do quadril (seção 1)
	duckOffset = 0
end

-- REMOVIDO: a correção que perseguia a malha do jogo.
--
-- Ela media `malhaDeOrigemZ - rootZ - ikZ` e devolvia ao corpo o que mudasse
-- nessa distância, para manter os pés plantados quando a cápsula encolhesse.
-- A premissa era que a malha de origem só se mexe em relação à cápsula quando
-- algo de fato mudou. É falsa: a UE desloca a malha em relação à cápsula para
-- suavizar degrau e subida, então o número oscila SOZINHO justamente ao subir.
-- Isso ia direto para a altura do corpo — e recalibrar só reposicionava a linha
-- de base, sem tirar a oscilação.
--
-- A altura do corpo volta a ser inteiramente do ik.lua, que é como estava antes
-- de eu mexer. Quem trata o agachamento é só a altura do quadril (seção 1), que
-- é medida em espaço de componente, dentro do esqueleto, e por isso não sabe
-- nem se importa com a altura do terreno.
--
-- Se o agachamento do jogo ainda mexer na altura de um jeito errado, o sinal
-- certo é o CapsuleHalfHeight (que o ik.lua já usa e o diagnóstico imprime):
-- ele muda em degrau no agachamento e não tem ruído nenhum. Perseguir a malha,
-- não.

-- 5 cm de folga para respirar/mexer a cabeça não mexerem no corpo.
local DUCK_DEADZONE = 5.0
local DUCK_LERP = 12.0

local function updateDuckOffset(hmd, rootZ, delta)
	if configui.getValue("body_followCrouchReal") == false then
		duckOffset = 0
		return 0
	end
	if uevrUtils.getValid(hmd) == nil then return duckOffset end

	local hmdLoc = hmd:K2_GetComponentLocation()
	if hmdLoc == nil then return duckOffset end

	-- medido contra o pawn, não contra o mundo: subir escada não conta como
	-- levantar, descer ladeira não conta como agachar
	local height = hmdLoc.Z - rootZ
	if standingHeadZ == nil then
		standingHeadZ = height
		return 0
	end

	-- só para baixo. Ficar na ponta dos pés ou pular não levanta o corpo, que
	-- deixaria os pés no ar.
	local target = math.min(0, height - standingHeadZ + DUCK_DEADZONE)

	if delta ~= nil and delta > 0 then
		local alpha = math.min(1, DUCK_LERP * delta)
		duckOffset = duckOffset + (target - duckOffset) * alpha
	else
		duckOffset = target
	end
	return duckOffset
end

--------------------------------------------------------------------------
-- 3. Câmera atracada à cabeça do corpo
--
-- Por padrão a câmera deste perfil ORBITA o pawn: o main.lua:130 põe ela em
--     pawnPos + RotateAngleAxis(playerOffset(19,-3,70), yawDaVisão)
-- e sobra para o corpo correr atrás dela (é o que faz o "Corpo segue a posicao
-- da cabeca"). Este modo inverte a conta: a câmera passa a ficar NA CABEÇA do
-- corpo e o corpo fica parado em relação ao pawn. O pescoço fica sempre no
-- lugar certo debaixo da sua vista, sem perseguição e sem o vaivém da órbita.
--
-- A ROTAÇÃO não é tocada: continua vindo do headset, mais o yaw desacoplado que
-- o main.lua escreve em rotation.y. Mexemos só em position.
--
-- O deslocamento roomscale do HMD é somado pelo UEVR DEPOIS deste callback,
-- então andar e se inclinar no espaço real continuam funcionando: o que
-- mudamos é a base sobre a qual esse deslocamento é aplicado.
--
-- Ordem de registro importa: o main.lua registra o callback dele dentro do
-- UEVRReady, que roda durante o carregamento do script. Registrar o nosso aqui
-- no corpo do arquivo o colocaria ANTES na fila, e o do main.lua sobrescreveria
-- a nossa posição. Por isso o registro sai de um uevrUtils.delay — qualquer
-- callback de tick roda depois de todos os scripts terem carregado.
--------------------------------------------------------------------------

-- Altura do osso da cabeça do corpo MEDIDA A PARTIR DO PAWN. É a única coisa
-- que o tick guarda para o callback da câmera usar: sendo relativa, não
-- envelhece entre o tick e o render. nil = a câmera da cabeça não escreve nada
-- e vale a câmera normal do perfil.
local headCameraHeight = nil

-- true = neste frame a câmera sai do osso da cabeça (montaria), e a altura
-- acima não é usada. Decidido no tick, para o callback da câmera não ter que
-- consultar o painel duas vezes por frame.
local headCameraOnMount = false

local function headCameraActive()
	if not isEnabled() or currentRig == nil or #bodyMeshes == 0 then return false end
	if configui.getValue("body_headCamera") ~= true then return false end
	if configui.getValue("body_onlyArms") == true then return false end -- sem corpo, sem cabeça
	if isBodyHidden() then return false end
	return true
end

-- MONTARIA: true = a câmera é atracada direto no osso da cabeça da malha, em vez
-- de na vertical do pawn.
--
-- A conta do modo a pé (horizontal do pawn + altura da cabeça) só fecha para
-- quem está EM PÉ: ali a cabeça fica praticamente em cima da origem do pawn, e
-- tirar o X/Y do pawn é de propósito — o corpo tem yaw próprio e o osso da
-- cabeça fica fora do eixo de giro, então usar o X/Y da cabeça faria o mundo
-- deslizar quando o corpo virasse.
--
-- Na montaria nada disso vale. A vassoura deita o personagem e o hipogrifo o
-- transfere para o RiderCharacter, que é OUTRO ator: a origem do pawn deixa de
-- ficar debaixo da cabeça e a câmera vai parar longe do pescoço. Em compensação
-- o motivo do cuidado some também — com "corpo copia a malha do jogo" o corpo
-- não tem mais yaw próprio (bodyYawState é zerado), ele herda a rotação inteira
-- da malha, então não há arco para fazer o mundo deslizar.
--
-- Por isso o modo montaria só entra quando o corpo está mesmo copiando a malha.
-- Com essa opção desligada o corpo volta a ficar em pé preso ao pawn, e aí é a
-- conta do modo a pé que descreve onde ele está.
local function mountHeadCameraActive()
	if mounts.isWalking() then return false end
	if configui.getValue("body_headCameraMount") == false then return false end
	if configui.getValue("body_mountFollowMesh") == false then return false end
	return true
end

local function getHeadWorldLocation()
	local mesh = bodyMeshes[1]
	if uevrUtils.getValid(mesh) == nil or mesh.GetSocketLocation == nil then return nil end
	-- "Esconder a cabeca" encolhe o osso (SetBoneScaleByName), não o move: a
	-- posição continua valendo mesmo com a cabeça invisível.
	return mesh:GetSocketLocation(uevrUtils.fname_from_string(headBone))
end

-- O tick guarda uma ALTURA RELATIVA AO PAWN; o callback compõe a posição final
-- com leituras frescas. A divisão do trabalho é toda por causa de dois erros já
-- pagos, que valem ficar escritos:
--
-- 1) NÃO usar "view_index == 0" para identificar o primeiro olho. Este jogo é
--    UE4, e lá o índice vem do EStereoscopicPass: eSSP_LEFT_EYE = 1,
--    eSSP_RIGHT_EYE = 2 — nunca 0. Uma versão calculava a câmera dentro do
--    callback só quando view_index era 0, e a conta rodou uma única vez na
--    vida: a câmera congelou num ponto do mundo e o personagem saiu andando.
--    Aqui não há teste de olho nenhum — o callback recalcula sempre, e os dois
--    olhos batem porque leem o mesmo estado dentro do quadro.
--
-- 2) NÃO guardar posição em MUNDO no tick. O callback da câmera roda depois do
--    tick do motor, ou seja, depois de o personagem já ter andado naquele
--    quadro. Uma posição em mundo calculada no tick chega atrasada, e o corpo
--    — filho do RootComponent, portanto já na posição nova — aparecia adiantado
--    em relação à câmera. O desvio é velocidade x tempo de quadro: invisível
--    parado, visível andando, escancarado na vassoura. Altura relativa não
--    envelhece, porque é somada à posição do pawn do próprio instante.
local function updateHeadCameraLocation(engine, delta)
	if not headCameraActive() then
		headCameraHeight = nil
		headCameraOnMount = false
		return
	end

	-- Na montaria não há altura para guardar: a posição inteira é lida do osso
	-- da cabeça dentro do próprio callback (ver applyMountHeadCamera).
	if mountHeadCameraActive() then
		headCameraOnMount = true
		headCameraHeight = nil
		return
	end
	headCameraOnMount = false

	local head = getHeadWorldLocation()
	-- Sem posição nova, ZERA em vez de manter a antiga. Uma câmera parada num
	-- ponto do mundo enquanto o personagem anda é o pior desfecho possível em
	-- VR; devolver a câmera normal do perfil é feio, mas jogável.
	if head == nil then
		headCameraHeight = nil
		return
	end

	-- O tick calcula UMA COISA SÓ: a altura da cabeça do corpo MEDIDA A PARTIR
	-- DO PAWN. Tudo o mais é feito no callback, com leitura fresca.
	--
	-- Foi aqui que nasceu o "corpo indo um pouco para a frente quando ando".
	-- Antes o tick guardava a posição em MUNDO, lida do pawn. Só que o callback
	-- da câmera roda depois do tick do motor, ou seja, depois de o personagem já
	-- ter andado naquele quadro: a câmera saía um quadro atrasada em relação ao
	-- corpo, que é filho do RootComponent e portanto já estava na posição nova.
	-- O desvio é velocidade x tempo de quadro — imperceptível parado, visível
	-- andando, escancarado na vassoura.
	--
	-- Guardando só uma ALTURA RELATIVA AO PAWN, o atraso cancela: no callback
	-- ela é somada à posição do pawn daquele instante. É o mesmo padrão do
	-- perfil do Silent Hill f (melee.lua:456), que lê o pawn dentro do callback
	-- e soma um deslocamento fixo.
	local rootComponent = uevrUtils.getValid(pawn, {"RootComponent"})
	if rootComponent == nil then
		headCameraHeight = nil
		return
	end
	local rootLoc = rootComponent:K2_GetComponentLocation()
	if rootLoc == nil then
		headCameraHeight = nil
		return
	end

	-- Desconta o agachamento REAL. O corpo já desceu esse tanto (seção 2b), e o
	-- UEVR soma o deslocamento roomscale do HMD depois do callback da câmera —
	-- sem descontar, abaixar no espaço real desceria a câmera duas vezes. O
	-- agachamento do JOGO não entra nesta conta: aquele o UEVR não tem como
	-- somar, e tem que vir mesmo da cabeça do corpo.
	local height = head.Z - rootLoc.Z - duckOffset

	local smooth = configui.getValue("body_headCameraSmooth") or 0
	if headCameraHeight ~= nil and smooth > 0 then
		local alpha = 1 - math.min(0.95, smooth)
		height = headCameraHeight + (height - headCameraHeight) * alpha
	end

	headCameraHeight = height
end

-- Prioridade -20 = roda depois do updateBodyTransform (-10), para ler o osso da
-- cabeça já com a posição e a altura deste frame.
uevrUtils.registerPreEngineTickCallback(function(engine, delta)
	local ok, err = pcall(updateHeadCameraLocation, engine, delta)
	if not ok then
		log("Falha ao calcular a camera da cabeca: " .. tostring(err), LogLevel.Warning)
	end
end, -20)

-- MONTARIA: a câmera vai direto para o osso da cabeça do corpo, os três eixos.
--
-- Aqui não há nada guardado do tick, e é de propósito: o osso é lido AGORA,
-- dentro do callback, que roda depois do tick do motor. Uma posição de cabeça
-- calculada no tick chegaria um quadro atrasada, e na vassoura — onde a
-- velocidade é alta — um quadro de atraso é justamente o que aparecia como
-- corpo adiantado em relação à câmera.
--
-- Lendo o osso da CÓPIA (e não da malha do jogo) a câmera pega a cabeça que
-- você realmente vê: o corpo montado é posto sobre a malha do jogo com o
-- "Ajuste na montaria" por cima, e esse ajuste já está embutido na posição do
-- osso. Nenhuma das duas contas precisa ser repetida aqui.
--
-- Esconder a cabeça encolhe o osso (SetBoneScaleByName), não o move — a posição
-- continua valendo com ela invisível.
local function applyMountHeadCamera(position, rotation)
	local head = getHeadWorldLocation()
	-- Sem osso, não escrevemos nada: vale a câmera de montaria do main.lua, que
	-- é o comportamento antigo. Congelar a câmera num ponto do mundo seria bem
	-- pior.
	if head == nil then return end

	local x, y, z = head.X, head.Y, head.Z

	-- Ajuste próprio da montaria, medido no espaço da VISÃO (X = para onde você
	-- olha), igual ao ajuste do modo a pé. O de pé não serve aqui: lá ele
	-- corrige a distância do osso da cabeça até os olhos de quem está em pé, e
	-- na vassoura o personagem está deitado, com a cabeça em outro ângulo.
	local offset = configui.getValue("body_headCameraMountOffset")
	if offset ~= nil then
		local rotated = kismet_math_library:RotateAngleAxis(
			uevrUtils.vector(offset.x or offset.X or 0, offset.y or offset.Y or 0, 0),
			rotation.y, uevrUtils.vector(0, 0, 1))
		x, y = x + rotated.X, y + rotated.Y
		z = z + (offset.z or offset.Z or 0)
	end

	position.x = x
	position.y = y
	position.z = z
end

-- Aqui tudo o que depende de posição é lido AGORA, no mesmo instante em que o
-- main.lua lê para a câmera dele. Nada de valor guardado do tick a não ser a
-- altura relativa, que não envelhece.
--
-- Os dois olhos recebem o mesmo valor sem precisar de nenhum teste de
-- view_index: as leituras são as mesmas dentro do quadro.
local function applyHeadCamera(position, rotation)
	if headCameraOnMount then
		return applyMountHeadCamera(position, rotation)
	end
	if headCameraHeight == nil then return end

	local rootComponent = uevrUtils.getValid(pawn, {"RootComponent"})
	if rootComponent == nil then return end
	local rootLoc = rootComponent:K2_GetComponentLocation()
	if rootLoc == nil then return end

	local x, y, z = rootLoc.X, rootLoc.Y, rootLoc.Z + headCameraHeight

	-- O ajuste dos olhos é medido no espaço da VISÃO (X = para onde você olha),
	-- porque representa onde os olhos ficam em relação ao osso da cabeça. Usa o
	-- rotation.y deste quadro, que já traz o yaw desacoplado escrito pelo
	-- main.lua e é a leitura mais fresca que existe.
	local offset = configui.getValue("body_headCameraOffset")
	if offset ~= nil then
		local rotated = kismet_math_library:RotateAngleAxis(
			uevrUtils.vector(offset.x or offset.X or 0, offset.y or offset.Y or 0, 0),
			rotation.y, uevrUtils.vector(0, 0, 1))
		x, y = x + rotated.X, y + rotated.Y
		z = z + (offset.z or offset.Z or 0)
	end

	position.x = x
	position.y = y
	position.z = z
end

local headCameraRegistered = false

local function registerHeadCamera()
	if headCameraRegistered then return end
	headCameraRegistered = true

	uevr.params.sdk.callbacks.on_early_calculate_stereo_view_offset(
		function(device, view_index, world_to_meters, position, rotation, is_double)
			-- pcall obrigatório: isto roda dentro do caminho da câmera, uma vez
			-- por olho. Um erro solto aqui derruba a renderização.
			local ok, err = pcall(applyHeadCamera, position, rotation)
			if not ok then
				log("Falha na camera da cabeca: " .. tostring(err), LogLevel.Warning)
			end
		end)

	logMilestone("Camera atracada a cabeca: callback registrado")
end

--------------------------------------------------------------------------
-- 4. Tronco acompanhando a visão
--
-- O corpo é filho do RootComponent do pawn, então ele gira com o PAWN. Só que
-- este perfil usa decoupled yaw: virar a cabeça não vira o pawn. O corpo ficava
-- para trás e dava o tranco quando o pawn finalmente alinhava.
--
-- No Silent Hill f isso não aparece porque lá o shf.lua zera o InputTurn e
-- mantém o pawn sempre alinhado com o HMD (não há yaw desacoplado). Como aqui o
-- yaw desacoplado é proposital, usamos o libs/body_yaw.lua da uevrlib, que é
-- feito para isto: gira o corpo em direção ao yaw do HMD com lerp e uma zona
-- morta, para giros pequenos de cabeça não arrastarem o corpo.
--------------------------------------------------------------------------

-- Por que a posição precisa ser recalculada todo frame:
--
-- A câmera deste perfil não fica no pawn. O main.lua:130 faz
--     camera = pawnPos + RotateAngleAxis(playerOffset(19,-3,70), yawDaVisão)
-- ou seja, ela ORBITA a origem do pawn num raio de ~19 cm. Virar 180° com yaw
-- desacoplado move a câmera uns 38 cm. O corpo, preso ao RootComponent com um
-- deslocamento fixo, não acompanhava essa órbita — daí ele aparecer mais para
-- frente ou mais para trás dependendo de para onde você estava olhando.
--
-- Em vez de repetir a fórmula do main.lua (que ainda depende do offset de
-- montaria), medimos direto onde o HMD está em relação ao pawn e usamos isso
-- como base horizontal do corpo. Isso cobre a órbita da câmera, o roomscale e
-- as montarias de uma vez só.
--
-- Só X e Y. O Z continua sendo do tick do ik.lua (prioridade 0, logo antes
-- desta função), que é o valor que você ajusta em "Posicao".

-- Para onde o corpo olha. É uma variável NOSSA e nunca é lida de volta do
-- componente — ler de volta era o caminho por onde o analógico virava o corpo:
--
-- o corpo é filho do RootComponent, e o jogo gira o pawn na direção do
-- movimento (empurrar o analógico para trás vira o personagem 180°). Essa
-- rotação acontece no tick do motor, que roda DEPOIS deste callback e arrasta
-- junto tudo que está preso ao root. No frame seguinte,
-- mesh:K2_GetComponentRotation().Yaw já vinha girado pelo pawn, o
-- bodyYaw.update lia aquilo como "o corpo está virado para lá" e ia atrás — o
-- corpo acabava seguindo a direção do analógico em vez da do headset.
--
-- Com o estado próprio, a direção do corpo depende só do HMD. O que o pawn faz
-- com a própria rotação deixa de importar, porque escrevemos a rotação em
-- mundo todo frame.
local bodyYawState = nil

local function updateBodyTransform(engine, delta)
	if not isEnabled() or currentRig == nil or #bodyMeshes == 0 then return end
	if isBodyHidden() then return end

	local followView = configui.getValue("body_followView") ~= false
	local followPosition = configui.getValue("body_followPosition") ~= false
	-- Não há mais saída antecipada com os dois desligados: a correção de altura
	-- da seção 2 vale sempre. Com os dois desligados, o X/Y calculado abaixo dá
	-- exatamente o meshLocationOffset, que é o que o ik.lua já tinha escrito.

	local rootComponent = uevrUtils.getValid(pawn, {"RootComponent"})
	if rootComponent == nil then return end
	local mesh = bodyMeshes[1]
	if uevrUtils.getValid(mesh) == nil then return end

	--------------------------------------------------------------------------
	-- MONTARIA (vassoura, hipogrifo): o corpo copia a malha do jogo.
	--
	-- Todo o posicionamento normal daqui pressupõe alguém EM PÉ: X/Y vêm de um
	-- offset ajustado a pé, o Z sai da altura da cápsula, e a rotação é só de
	-- yaw — corpo sempre na vertical. Na vassoura nada disso vale: o jogo deita
	-- o personagem sobre ela e a vassoura inclina (pitch e roll), coisa que este
	-- código nem trata. Daí o corpo aparecer numa posição completamente
	-- diferente, em vez de em cima da vassoura.
	--
	-- Aqui a conta é abandonada e o corpo simplesmente vai para onde está a
	-- malha do jogo, com a rotação dela inteira — pitch e roll inclusive. É uma
	-- cópia de uma transform que o motor já calculou, não uma perseguição: não
	-- há erro para acumular.
	--
	-- Em MUNDO, e não em relativo, para não depender de a malha do jogo estar
	-- pendurada no mesmo pai que a nossa cópia — no hipogrifo o personagem passa
	-- a ser o RiderCharacter, que é outro ator.
	--------------------------------------------------------------------------
	if not mounts.isWalking() and configui.getValue("body_mountFollowMesh") ~= false then
		local source = getSourceMesh()
		if uevrUtils.getValid(source) ~= nil and source.K2_GetComponentLocation ~= nil then
			local srcLoc = source:K2_GetComponentLocation()
			local srcRot = source:K2_GetComponentRotation()
			if srcLoc ~= nil and srcRot ~= nil then
				local mountOffset = configui.getValue("body_mountOffset")
				local mx = mountOffset and (mountOffset.x or mountOffset.X or 0) or 0
				local my = mountOffset and (mountOffset.y or mountOffset.Y or 0) or 0
				local mz = mountOffset and (mountOffset.z or mountOffset.Z or 0) or 0

				-- o ajuste é medido no espaço do CORPO montado, então acompanha
				-- para onde a vassoura aponta
				local rotated = kismet_math_library:RotateAngleAxis(
					uevrUtils.vector(mx, my, 0), srcRot.Yaw, uevrUtils.vector(0, 0, 1))

				for _, component in ipairs(bodyMeshes) do
					if uevrUtils.getValid(component) ~= nil and component.K2_SetWorldLocation ~= nil then
						component:K2_SetWorldLocation(
							uevrUtils.vector(srcLoc.X + rotated.X, srcLoc.Y + rotated.Y, srcLoc.Z + mz, true),
							false, reusable_hit_result, false)
						component:K2_SetWorldRotation(
							uevrUtils.rotator(srcRot.Pitch, srcRot.Yaw, srcRot.Roll),
							false, reusable_hit_result, false)
					end
				end

				-- o yaw livre do corpo perde o sentido montado; recomeça do pawn
				-- quando você desmontar
				bodyYawState = nil
				return
			end
		end
	end

	local hmd = controllers.getController(2)
	local pawnYaw = rootComponent:K2_GetComponentRotation().Yaw
	-- o offset de Yaw do painel faz parte da rotação da malha, não da direção
	-- para onde o corpo "olha", então entra e sai da conta
	local meshYawOffset = configui.getValue("body_yaw") or 0

	-- 1) para onde o corpo olha
	local newYaw = pawnYaw
	if followView then
		if bodyYawState == nil then bodyYawState = pawnYaw end
		newYaw = bodyYawState
		if uevrUtils.getValid(hmd) ~= nil and delta ~= nil and delta > 0 then
			newYaw = bodyYaw.update(newYaw, hmd:K2_GetComponentRotation().Yaw, delta) or newYaw
		end
		bodyYawState = newYaw
	else
		-- desligado: o corpo volta a girar com o pawn, e na próxima vez que for
		-- ligado começa de onde o pawn estiver
		bodyYawState = nil
	end

	-- 2) posição horizontal: base embaixo do HMD + o ajuste do painel.
	-- O ajuste é medido no espaço do CORPO (X = para onde o corpo olha), então
	-- ele gira junto com o corpo; sem isso, "um pouco para trás" viraria "um
	-- pouco para frente" assim que você se virasse.
	local x, y = 0, 0
	local offset = currentRig.meshLocationOffset
	if offset ~= nil then
		local rotated = kismet_math_library:RotateAngleAxis(
			uevrUtils.vector(offset.X, offset.Y, 0), newYaw - pawnYaw, uevrUtils.vector(0, 0, 1))
		x, y = rotated.X, rotated.Y
	end
	-- Com a câmera atracada à cabeça, quem se move é a câmera, não o corpo.
	-- Manter os dois ligados seria o corpo perseguir a câmera que persegue o
	-- corpo — realimentação. Então este modo tem prioridade.
	if followPosition and not headCameraActive() and uevrUtils.getValid(hmd) ~= nil then
		local hmdLoc = hmd:K2_GetComponentLocation()
		local rootLoc = rootComponent:K2_GetComponentLocation()
		-- diferença em mundo -> espaço do pawn, que é onde RelativeLocation vive
		local inPawnSpace = kismet_math_library:RotateAngleAxis(
			uevrUtils.vector(hmdLoc.X - rootLoc.X, hmdLoc.Y - rootLoc.Y, 0),
			-pawnYaw, uevrUtils.vector(0, 0, 1))
		x = x + inPawnSpace.X
		y = y + inPawnSpace.Y
	end

	-- 3) altura (ver seção 2). Sobrou só o agachamento real, que vem desligado.
	-- O ik.lua reescreve RelativeLocation.Z no tick de prioridade 0, logo antes
	-- deste, então o valor lido abaixo é sempre o dele, limpo — a correção não
	-- se acumula de um frame para o outro.
	local rootZ = rootComponent:K2_GetComponentLocation().Z
	local zAdjust = updateDuckOffset(hmd, rootZ, delta)

	for _, component in ipairs(bodyMeshes) do
		if uevrUtils.getValid(component) ~= nil and component.K2_SetRelativeLocation ~= nil then
			local z = component.RelativeLocation ~= nil and component.RelativeLocation.Z or 0
			component:K2_SetRelativeLocation(
				uevrUtils.vector(x, y, z + zAdjust, true), false, reusable_hit_result, false)
		end
	end

	if followView then
		local rotation = uevrUtils.rotator(0, newYaw + meshYawOffset, 0)
		for _, component in ipairs(bodyMeshes) do
			if uevrUtils.getValid(component) ~= nil and component.K2_SetWorldRotation ~= nil then
				component:K2_SetWorldRotation(rotation, false, reusable_hit_result, false)
			end
		end
	end
end

-- Prioridade -10 = roda DEPOIS do tick do ik.lua, para a rotação final do corpo
-- ser a nossa. Continua no pré-tick: escrever transform no pós-tick foi o que
-- fez o corpo piscar da outra vez.
uevrUtils.registerPreEngineTickCallback(function(engine, delta)
	local ok, err = pcall(updateBodyTransform, engine, delta)
	if not ok then
		log("Falha ao posicionar o corpo: " .. tostring(err), LogLevel.Warning)
	end
end, -10)

--------------------------------------------------------------------------
-- Criação do rig
--------------------------------------------------------------------------

-- Reconstruir o corpo também reconstrói a varinha. Ela é presa na criação — ao
-- controle (connectToController) ou ao socket da mão (connectToSocket) — e esse
-- vínculo não sobrevive ao rig novo: a varinha fica para trás, presa a uma mão
-- que não existe mais.
--
-- Só DESCONECTAMOS. Quem reconecta é o poll do próprio main.lua (linha 1009:
-- "if isFP and not isWandDisabled and not isInCinematic and not
-- wand.isConnected() then connectWand()"), que roda a cada frame e já monta a
-- varinha no estado certo, com o corpo novo no lugar. Refazer a conexão daqui
-- duplicaria essa lógica e correria o risco de rodar antes do corpo existir.
--
-- pcall obrigatório: chamamos isto de dentro de callbacks e timers, e os timers
-- do uevr_utils rodam SEM proteção (uevr_utils:1123) — um erro aqui derrubaria
-- os outros timers do perfil no mesmo frame.
local function rebuildWand()
	if type(_G.disconnectWand) ~= "function" then return end
	local ok, err = pcall(_G.disconnectWand)
	if ok then
		log("Varinha desconectada para reconectar junto com o corpo")
	else
		log("Falha ao reconectar a varinha: " .. tostring(err), LogLevel.Warning)
	end
end

local function rebuild()
	ik.destroyAll()
	currentRig = nil
	bodyMeshes = {}
	bodyYawState = nil
	headCameraHeight = nil
	headCameraOnMount = false
	resetHeightCalibration()
	rebuildWand()
end

-- Parâmetros que podem esperar o corpo existir. "hide_body" fica de fora
-- porque desligá-lo faz o próprio módulo IK reconstruir o rig.
local QUEUEABLE_PARAMS = { mesh_location_offset = true, mesh_rotation_offset = true }

-- Aplica um parâmetro do rig e grava em data/ik_parameters.json.
local function setRigParam(key, value)
	if currentRig ~= nil then
		currentRig:setConfigParameter(key, value, true)
	elseif QUEUEABLE_PARAMS[key] then
		pendingParams[key] = value
	end
end

local function applyPendingParams(rig)
	local queued = pendingParams
	pendingParams = {}
	for key, value in pairs(queued) do
		rig:setConfigParameter(key, value, true)
	end
end

ik.registerOnMeshCreatedCallback(function(meshList, rig)
	currentRig = rig
	bodyMeshes = meshList or {}
	if #bodyMeshes == 0 then
		log("Nenhuma malha foi criada para o corpo", LogLevel.Warning)
		return
	end

	-- Confere os nomes de osso contra a malha real. Se algum estava errado, os
	-- solvers deste rig já nasceram mortos: grava os corretos e reconstrói.
	-- Na reconstrução os nomes já batem, então isso acontece uma vez só.
	--
	-- MONTADO, NÃO. Esta detecção GRAVA em data/ik_parameters.json
	-- (setConfigParameter com persist = true). Se o corpo tiver nascido do
	-- esqueleto errado — e montado é justamente quando isso pode acontecer —, o
	-- que ela grava são os ossos da criatura por cima dos seus, junto com os
	-- offsets ajustados em jogo. Aconteceu em 06/08/2026: `wing_elbow_left`,
	-- `wing_wrist_right`, `wing_clavicle_left`. A pé, com o personagem certo em
	-- mãos, ela volta a rodar normalmente.
	if not mounts.isWalking() then
		rig.bodyBonesChecked = true
	end
	if configui.getValue("body_autoDetectBones") ~= false and not rig.bodyBonesChecked then
		rig.bodyBonesChecked = true
		if detectBones(rig, false) then
			log("Ossos corrigidos — reconstruindo o corpo")
			uevrUtils.delay(200, rebuild) -- fora do callback de criação
			return
		end
	end

	applyShadowSetting()
	applyHeadVisibility()
	keepSourceMeshesAnimating(rig)
	detectLegBones(bodyMeshes[1])
	-- o valor de fábrica do Z automático, para devolver ao desmontar (seção 1b)
	rigCoupling = rig.coupling or 1
	-- depois das pernas: a cintura é achada excluindo os ossos delas (seção 1c)
	detectWaistBone(bodyMeshes[1])
	detectDiagArmBones(bodyMeshes[1])

	-- reaproveita as poses de dedo do perfil nas mãos do corpo
	rig:setAnimationsFromHandsParametersFile(buildAnimationTable())
	rig:initHandAnimations(rig.meshTemplates)

	logMilestone("Corpo criado com " .. #bodyMeshes .. " malha(s)")

	applyPendingParams(rig)

	-- e a varinha volta junto. Aqui cobre também os caminhos que não passam pelo
	-- botão "Reconstruir corpo": troca de malhas, redetecção de ossos e a
	-- criação automática no começo do nível.
	rebuildWand()
end)

ik.registerOnDestroyCallback(function()
	currentRig = nil
	bodyMeshes = {}
end)

--------------------------------------------------------------------------
-- As mãos antigas (presas aos controles) e o corpo não podem coexistir:
-- as duas usariam os mesmos IDs de animação e as mãos ficariam duplicadas.
--------------------------------------------------------------------------

-- Quem decide se as mãos existem é a variável global showHands, lida pelo
-- main.lua a cada poll. Mexemos direto nela e nas malhas, e repetimos de tempos
-- em tempos para o caso de algum outro caminho recriar as mãos. NÃO chamamos
-- configui.setValue("showHands", ...): isso dispara o onUpdate do main.lua, que
-- roda disconnectWand() + gesturesModule.reset() + disconnectHands(). Chamar
-- essas funções num momento arbitrário (tela de load, menu) pode dar erro, e um
-- erro aqui é grave: o uevr_utils executa os timers sem pcall (uevr_utils:1123),
-- então a exceção derruba os outros timers do perfil no mesmo frame.
-- Efeito colateral aceito: o checkbox "Show Hands" continua marcado na tela
-- mesmo com as mãos desligadas.
local function enforceHandsOff()
	if not isEnabled() then return end
	if configui.getValue("body_replaceHands") == false then return end

	if _G.showHands ~= false then
		_G.showHands = false
		log("'Show Hands' desligado — as mãos agora vêm do corpo")
	end

	if hands.exists() then
		log("Destruindo as mãos antigas presas aos controles")
		hands.destroyHands()
		hands.reset()
	end
end

-- Quando o corpo é desligado, devolve as mãos do perfil.
local function restoreHands()
	if _G.showHands == false then
		log("Religando 'Show Hands'")
		_G.showHands = true
	end
end

uevrUtils.setInterval(2000, function()
	local ok, err = pcall(enforceHandsOff)
	if not ok then
		log("Falha ao desligar as mãos: " .. tostring(err), LogLevel.Warning)
	end
end)

--------------------------------------------------------------------------
-- Refazer o corpo ao montar e ao desmontar
--
-- Montar troca o pawn controlado (a criatura passa a ser o pawn), troca a malha
-- que anima o personagem e troca a cápsula que dá a altura do corpo. Em vez de
-- tentar remendar cada uma dessas coisas com o corpo já montado, o corpo é
-- destruído e refeito do zero na transição — que é quando o ik.lua recria tudo
-- com o estado novo, inclusive escolhendo a malha do personagem em vez da da
-- criatura (ver getCustomIKComponent).
--
-- Só na transição a pé <-> montado. Trocar de vassoura para hipogrifo, por
-- exemplo, não refaz nada.
--
-- Quem recria é o temporizador do ik.lua (1x por segundo), então o corpo fica
-- ausente por até um segundo depois de montar. É o preço, e é previsível.
--
-- A espera mínima entre reconstruções existe porque destruir e criar o corpo é
-- caro: se o estado de montaria oscilasse, isto viraria um laço.
--------------------------------------------------------------------------
local lastMountTypeForRebuild = nil
local rebuildWait = 0
local REBUILD_COOLDOWN = 10 -- passagens do temporizador de 200 ms = 2 segundos

uevrUtils.setInterval(200, function()
	local ok, err = pcall(function()
		if rebuildWait > 0 then rebuildWait = rebuildWait - 1 end

		local mountType = mounts.getMountType()
		if lastMountTypeForRebuild == nil then
			lastMountTypeForRebuild = mountType
			return
		end
		if mountType == lastMountTypeForRebuild then return end

		local eraAPe = (lastMountTypeForRebuild == 6)
		local estaAPe = (mountType == 6)
		lastMountTypeForRebuild = mountType

		-- troca entre tipos de montaria (vassoura -> hipogrifo): não refaz
		if eraAPe == estaAPe then return end
		if not isEnabled() then return end
		if configui.getValue("body_mountRebuild") == false then return end
		if rebuildWait > 0 then return end
		rebuildWait = REBUILD_COOLDOWN

		logMilestone(estaAPe and "Desmontou: refazendo o corpo" or "Montou: refazendo o corpo")
		rebuild()
	end)
	if not ok then
		log("Falha ao refazer o corpo na montaria: " .. tostring(err), LogLevel.Warning)
	end
end)

--------------------------------------------------------------------------
-- Painel de configuração
--------------------------------------------------------------------------

configui.onCreateOrUpdate("body_enabled", function(value)
	ik.setAutoCreateArms(value == true)
	if value ~= true then
		rebuild()
		restoreHands()
	else
		uevrUtils.delay(1000, enforceHandsOff)
	end
end)

configui.onCreateOrUpdate("body_replaceHands", function(value)
	if value == false then
		restoreHands()
	else
		uevrUtils.delay(1000, enforceHandsOff)
	end
end)

configui.onCreateOrUpdate("body_meshMode", function(value)
	if currentRig ~= nil then rebuild() end
end)

configui.onCreateOrUpdate("body_hideHead", function(value)
	applyHeadVisibility()
end)

configui.onCreateOrUpdate("body_shadow", function(value)
	applyShadowSetting()
end)

configui.onCreateOrUpdate("body_followViewDeadzone", function(value)
	bodyYaw.setMinAngularDeviation(value)
end)

-- Os três abaixo usam onUpdate (e não onCreateOrUpdate) de propósito: quem manda
-- na posição do corpo é data/ik_parameters.json, lido pelo IK a cada criação.
-- O painel só grava por cima quando o jogador realmente mexe no controle.
configui.onUpdate("body_onlyArms", function(value)
	setRigParam("hide_body", value == true)
end)

configui.onUpdate("body_location", function(value)
	if value == nil then return end
	setRigParam("mesh_location_offset", { value.x or value.X or 0, value.y or value.Y or 0, value.z or value.Z or 0 })
end)

configui.onUpdate("body_yaw", function(value)
	setRigParam("mesh_rotation_offset", { 0, value or 0, 0 })
end)

configui.onUpdate("body_rebuild", function()
	log("Reconstruindo o corpo")
	rebuild()
end)

-- Fique de pé, na altura em que você joga, e clique. As duas linhas de
-- referência da seção 2 são recapturadas no frame seguinte.
configui.onUpdate("body_recalibrate", function()
	resetHeightCalibration()
	logMilestone("Altura recalibrada")
end)

configui.onUpdate("body_detectBones", function()
	if currentRig == nil then
		log("Corpo não está criado", LogLevel.Warning)
		return
	end
	if detectBones(currentRig, true) then
		log("Ossos redetectados — reconstruindo o corpo")
		uevrUtils.delay(200, rebuild)
	else
		applyHeadVisibility()
	end
end)

-- Despeja no log.txt o estado que interessa quando a câmera ou a altura do
-- corpo estão erradas. Vai como Error de propósito (ver logMilestone): é para
-- ser lido depois, no arquivo.
local function logDiagnostics()
	local function fmt(v)
		if v == nil then return "nil" end
		return string.format("(%.1f, %.1f, %.1f)", v.X or v.x or 0, v.Y or v.y or 0, v.Z or v.z or 0)
	end

	logMilestone("--- diagnostico ---")
	logMilestone("corpo criado: " .. tostring(currentRig ~= nil) .. ", malhas: " .. #bodyMeshes
		.. ", escondido (filtrado): " .. tostring(isBodyHidden())
		.. ", escondido (cru): " .. tostring(shouldHideBody()))
	logMilestone("headCamera marcado: " .. tostring(configui.getValue("body_headCamera"))
		.. ", ativo agora: " .. tostring(headCameraActive())
		.. ", altura da cabeca sobre o pawn: "
		.. (headCameraHeight and string.format("%.1f", headCameraHeight) or "nil"))
	logMilestone("montaria: tipo=" .. tostring(mounts.getMountType())
		.. ", voando=" .. tostring(mounts.getIsFlying())
		.. ", camera no osso da cabeca: " .. tostring(mountHeadCameraActive())
		.. ", usando esse modo agora: " .. tostring(headCameraOnMount))

	local rootComponent = uevrUtils.getValid(pawn, {"RootComponent"})
	if rootComponent ~= nil then
		logMilestone("pawn root: " .. fmt(rootComponent:K2_GetComponentLocation())
			.. ", CapsuleHalfHeight: " .. tostring(rootComponent.CapsuleHalfHeight))
	end

	local hmd = controllers.getController(2)
	if uevrUtils.getValid(hmd) ~= nil then
		logMilestone("HMD: " .. fmt(hmd:K2_GetComponentLocation()))
	end

	logMilestone("altura: linha da cabeca=" .. tostring(standingHeadZ)
		.. ", agachamento real=" .. string.format("%.1f", duckOffset)
		.. ", quadril abaixado=" .. string.format("%.1f", hipDrop)
		.. ", quadril de pe (origem)=" .. (standingSourceHipZ and string.format("%.1f", standingSourceHipZ) or "nil")
		.. ", quadril na pose de referencia=" .. (referenceHip and string.format("%.1f", referenceHip.Z) or "nil"))

	local source = getSourceMesh()
	if uevrUtils.getValid(source) ~= nil then
		logMilestone("malha de origem no mundo: " .. fmt(source:K2_GetComponentLocation()))
	end

	local mesh = bodyMeshes[1]
	if uevrUtils.getValid(mesh) ~= nil then
		logMilestone("corpo relativo: " .. fmt(mesh.RelativeLocation)
			.. ", mundo: " .. fmt(mesh:K2_GetComponentLocation()))
		logMilestone("osso da cabeca '" .. headBone .. "' no mundo: " .. fmt(getHeadWorldLocation()))

		-- Quadril: na malha de origem é a pose animada do jogo. Com "Corpo
		-- acompanha o agachamento" LIGADO os dois têm que bater (é o que a
		-- cópia da translação faz); DESLIGADO, a cópia fica na pose de
		-- referência e a diferença mostra o quanto o personagem agachou.
		if legAnchorFName ~= nil and currentRig ~= nil then
			if uevrUtils.getValid(source) ~= nil then
				local sourceHip = source:GetSocketTransform(legAnchorFName, RTS_COMPONENT)
				local targetHip = mesh:GetBoneTransformByName(legAnchorFName, EBoneSpaces.ComponentSpace)
				if sourceHip ~= nil and targetHip ~= nil then
					logMilestone("quadril (espaco de componente) origem: " .. fmt(sourceHip.Translation)
						.. ", copia: " .. fmt(targetHip.Translation))
				end
			end
		end
	end
	logMilestone("--- fim ---")
end

configui.onUpdate("body_diagnostics", function()
	local ok, err = pcall(logDiagnostics)
	if not ok then
		log("Falha no diagnostico: " .. tostring(err), LogLevel.Warning)
	end
end)

configui.onUpdate("body_logBones", function()
	local mesh = bodyMeshes[1]
	if uevrUtils.getValid(mesh) == nil then
		log("Corpo não está criado", LogLevel.Warning)
		return
	end
	animation.logBoneNames(mesh)
end)

configui.create({
	{
		panelLabel = "Corpo VR",
		saveFile = "config_body",
		layout = {
			{ widgetType = "text", label = "Corpo completo em primeira pessoa (tronco, bracos, maos, pernas e pes)." },
			{ widgetType = "spacing" },
			{ widgetType = "checkbox", id = "body_enabled", label = "Ativar corpo VR", initialValue = true },
			{ widgetType = "checkbox", id = "body_replaceHands", label = "Usar as maos do corpo (desliga Show Hands)", initialValue = true },
			{ widgetType = "checkbox", id = "body_hideHead", label = "Esconder a cabeca", initialValue = true },
			{ widgetType = "checkbox", id = "body_shadow", label = "Corpo projeta sombra", initialValue = true },
			{ widgetType = "checkbox", id = "body_onlyArms", label = "Somente bracos (esconde tronco e pernas)", initialValue = false },
			{ widgetType = "checkbox", id = "body_hideOnMount", label = "Esconder o corpo na montaria (vassoura, hipogrifo)", initialValue = false },
			{ widgetType = "text", label = "  Como o perfil ja esconde o jogador, ligar isso deixa voce sem corpo nenhum na vassoura." },
			{ widgetType = "spacing" },
			{
				widgetType = "checkbox",
				id = "body_animate",
				label = "Animar as pernas pelo jogo",
				initialValue = true,
			},
			{ widgetType = "text", label = "  So da cintura para baixo. Tronco, cabeca e dedos continuam como estavam." },
			{
				widgetType = "checkbox",
				id = "body_followCrouch",
				label = "Corpo acompanha o agachamento do jogo",
				initialValue = true,
			},
			{ widgetType = "text", label = "  Sem isso, agachar levanta os pes em vez de baixar o corpo." },
			{
				widgetType = "checkbox",
				id = "body_followCrouchReal",
				label = "Corpo acompanha voce agachando de verdade",
				initialValue = false,
			},
			{ widgetType = "text", label = "  DESLIGADO: deixa resquicio de corpo na tela. Usa a altura do HMD ('Recalibrar altura' em pe)." },
			{
				widgetType = "checkbox",
				id = "body_followPosition",
				label = "Corpo segue a posicao da cabeca",
				initialValue = true,
			},
			{ widgetType = "text", label = "  Sem isso o corpo fica preso ao pawn, e a camera deste perfil orbita o pawn." },
			{ widgetType = "spacing" },
			{
				widgetType = "checkbox",
				id = "body_headCamera",
				label = "Camera atracada a cabeca do corpo",
				initialValue = false,
			},
			{ widgetType = "text", label = "  A camera vai ate a cabeca em vez de o corpo ir atras da camera." },
			{ widgetType = "text", label = "  A rotacao continua sendo do headset. Substitui o 'Corpo segue a posicao da cabeca'." },
			{ widgetType = "text", label = "  Com isso ligado, deixe X e Y de 'Posicao' perto de zero: eles giram junto com o corpo" },
			{ widgetType = "text", label = "  e fazem o corpo bambear em volta da sua vista quando ele vira." },
			{
				widgetType = "drag_float3",
				id = "body_headCameraOffset",
				label = "  Ajuste dos olhos (X frente, Y direita, Z altura)",
				speed = 0.5,
				range = { -100, 100 },
				initialValue = { 8, 0, 4 },
			},
			{
				widgetType = "slider_float",
				id = "body_headCameraSmooth",
				label = "  Suavizacao",
				speed = 0.01,
				range = { 0, 0.95 },
				initialValue = 0.5,
			},
			{
				widgetType = "checkbox",
				id = "body_headCameraMount",
				label = "  Na montaria, camera no osso da cabeca",
				initialValue = true,
			},
			{ widgetType = "text", label = "    A pe a camera fica na vertical do pawn (a cabeca esta em cima dele)." },
			{ widgetType = "text", label = "    Montado nao: a vassoura deita o personagem e o hipogrifo o passa para outro ator," },
			{ widgetType = "text", label = "    entao a camera vai direto para a cabeca do corpo, nos tres eixos." },
			{
				widgetType = "drag_float3",
				id = "body_headCameraMountOffset",
				label = "    Ajuste dos olhos na montaria (X frente, Y direita, Z altura)",
				speed = 0.5,
				range = { -200, 200 },
				initialValue = { 0, 0, 0 },
			},
			{
				widgetType = "checkbox",
				id = "body_followView",
				label = "Corpo acompanha a visao (giro)",
				initialValue = true,
			},
			{
				widgetType = "slider_int",
				id = "body_followViewDeadzone",
				label = "  Angulo para o corpo comecar a virar",
				speed = 1.0,
				range = { 1, 90 },
				initialValue = 40,
			},
			{
				widgetType = "combo",
				id = "body_meshMode",
				label = "Malhas",
				selections = { "Corpo + roupas", "Somente Pawn.Mesh" },
				initialValue = 1,
				width = 220,
			},
			{ widgetType = "spacing" },
			{ widgetType = "text", label = "Pernas: empurra coxa, canela, pe e dedos juntos (X frente, Y direita, Z altura)" },
			{
				widgetType = "drag_float3",
				id = "body_legOffset",
				label = "Ajuste das pernas",
				speed = 0.5,
				range = { -100, 100 },
				initialValue = { 0, 0, 0 },
			},
			{ widgetType = "spacing" },
			{
				widgetType = "checkbox",
				id = "body_mountFollowMesh",
				label = "Na montaria, corpo copia a malha do jogo",
				initialValue = true,
			},
			{ widgetType = "text", label = "  Sem isso o corpo fica na posicao de quem esta EM PE, e em pe na vertical," },
			{ widgetType = "text", label = "  enquanto a vassoura deita o personagem e inclina. Copiando a malha, ele" },
			{ widgetType = "text", label = "  ganha pitch e roll de graca e fica em cima da vassoura." },
			{
				widgetType = "drag_float3",
				id = "body_mountOffset",
				label = "  Ajuste na montaria",
				speed = 0.5,
				range = { -200, 200 },
				initialValue = { 0, 0, 0 },
			},
			{
				widgetType = "checkbox",
				id = "body_mountRebuild",
				label = "  Refazer o corpo ao montar e ao desmontar",
				initialValue = true,
			},
			{ widgetType = "text", label = "    Montar troca o pawn, a malha que anima e a capsula da altura. Em vez de remendar" },
			{ widgetType = "text", label = "    com o corpo em pe, ele e destruido e refeito com o estado novo. Some por ~1s." },
			{
				widgetType = "checkbox",
				id = "body_mountArmsIK",
				label = "  Na montaria, bracos pelo IK",
				initialValue = true,
			},
			{ widgetType = "text", label = "    O ik.lua reescreve a altura do corpo pela capsula do pawn todo frame, e no" },
			{ widgetType = "text", label = "    hipogrifo o pawn e A CRIATURA (capsula enorme): o alvo saia do alcance do braco" },
			{ widgetType = "text", label = "    e a mao congelava. Ligado, essa altura automatica fica quieta enquanto montado." },
			{
				widgetType = "checkbox",
				id = "body_mountHipAlign",
				label = "  Na montaria, tronco acompanha o headset (so criaturas)",
				initialValue = true,
			},
			{ widgetType = "text", label = "    Gira o osso da cintura, logo acima do quadril. Nada se move de lugar — nem voce," },
			{ widgetType = "text", label = "    nem a criatura, nem o corpo. As pernas ficam onde a animacao as pos. Vassoura nao entra." },
			{
				widgetType = "slider_float",
				id = "body_mountHipSensitivity",
				label = "    Sensibilidade",
				speed = 0.01,
				range = { 0, 1 },
				initialValue = 0.5,
			},
			{
				widgetType = "slider_int",
				id = "body_mountHipDeadzone",
				label = "    Angulo para comecar a girar",
				speed = 1.0,
				range = { 0, 60 },
				initialValue = 15,
			},
			{
				widgetType = "slider_int",
				id = "body_mountHipMaxYaw",
				label = "    Limite do giro (graus)",
				speed = 1.0,
				range = { 0, 90 },
				initialValue = 60,
			},
			{ widgetType = "spacing" },
			{ widgetType = "text", label = "Posicao do corpo: X = frente, Y = direita, Z = altura" },
			{
				widgetType = "drag_float3",
				id = "body_location",
				label = "Posicao",
				speed = 0.5,
				range = { -300, 300 },
				-- valores ajustados em jogo pelo Renan (04/08/2026)
				initialValue = { 0, -4.5, -87 },
			},
			{
				widgetType = "drag_float",
				id = "body_yaw",
				label = "Rotacao (Yaw)",
				speed = 1.0,
				range = { -360, 360 },
				-- valor ajustado em jogo pelo Renan (04/08/2026)
				initialValue = 13,
			},
			{ widgetType = "spacing" },
			{
				widgetType = "checkbox",
				id = "body_autoDetectBones",
				label = "Detectar ossos automaticamente",
				initialValue = true,
			},
			{ widgetType = "text", label = "  Corrige nomes de osso que nao existem na malha. Nomes que ja funcionam nao sao alterados." },
			{ widgetType = "spacing" },
			{ widgetType = "button", id = "body_recalibrate", label = "Recalibrar altura" },
			{ widgetType = "same_line" },
			{ widgetType = "button", id = "body_rebuild", label = "Reconstruir corpo" },
			{ widgetType = "same_line" },
			{ widgetType = "button", id = "body_detectBones", label = "Detectar ossos agora" },
			{ widgetType = "same_line" },
			{ widgetType = "button", id = "body_logBones", label = "Listar ossos no log" },
			{ widgetType = "same_line" },
			{ widgetType = "button", id = "body_diagnostics", label = "Diagnostico no log" },
			{ widgetType = "spacing" },
			{ widgetType = "text", label = "Ajuste fino de bracos e maos: aba 'IK Dev Config'.", wrapped = true },
		},
	},
})

ik.init(SHOW_DEV_UI, LogLevel.Info)

-- O registro da câmera precisa acontecer depois que o main.lua registrou o
-- dele (ver a seção 2), e qualquer callback de tick já satisfaz isso: o
-- UEVRReady do main.lua roda durante o carregamento dos scripts, antes do
-- primeiro tick. O delay é só para não disputar o frame de inicialização.
uevrUtils.delay(2000, registerHeadCamera)

-- Se o perfil for carregado já dentro de um nível, o corpo é criado sozinho
-- pelo temporizador interno do módulo IK (1x por segundo, enquanto não existir).
uevrUtils.registerLevelChangeCallback(function()
	uevrUtils.delay(3000, applyHandsSetting)
	registerHeadCamera() -- protegido por flag: registra uma vez só
end)
