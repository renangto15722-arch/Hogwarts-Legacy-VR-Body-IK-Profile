--[[
	body.lua — Corpo VR (IK) para Hogwarts Legacy
	--------------------------------------------------------------------------
	Cria um corpo completo em primeira pessoa (tronco, braços, mãos, pernas e
	pés) a partir do próprio esqueleto do personagem, usando o módulo de
	Inverse Kinematics da uevrlib (libs/ik.lua).

	Como funciona (mesmo esquema do perfil do Silent Hill f):
	  1. O módulo IK faz uma cópia PoseableMeshComponent das malhas do
	     personagem (corpo + roupas) e prende essa cópia no RootComponent do
	     pawn, deslocada para baixo até os pés.
	  2. Dois solvers de Two Bone IK giram RightArm/RightForeArm/RightHand e
	     LeftArm/LeftForeArm/LeftHand para que as mãos acompanhem os controles.
	  3. As poses de dedo do próprio perfil (helpers/hand_animations.lua) são
	     reaproveitadas nas mãos do corpo, então gatilho/grip continuam
	     animando os dedos.

	Os valores numéricos (altura, rotação, alinhamento da mão) ficam em
	data/ik_parameters.json e podem ser ajustados ao vivo:
	  - no painel "Corpo VR" (ajustes principais), ou
	  - no painel "IK Dev Config" (ajuste fino de ossos e offsets de mão).
]]--

local uevrUtils      = require("libs/uevr_utils")
local configui       = require("libs/configui")
local animation      = require("libs/animation")
local controllers    = require("libs/controllers")
local hands          = require("libs/hands")
local ik             = require("libs/ik")
local bodyYaw        = require("libs/body_yaw")
local handAnimations = require("helpers/hand_animations")
local mounts         = require("helpers/mounts")
require("libs/enums/unreal")

-- EVisibilityBasedAnimTickOption::AlwaysTickPoseAndRefreshBones — não está no
-- enums/unreal.lua da lib, então fica aqui o valor cru.
local ALWAYS_TICK_POSE_AND_REFRESH_BONES = 0

-- Deixe true para ter o painel "IK Dev Config" na UI do UEVR (ajuste fino).
local SHOW_DEV_UI = true

-- Osso da cabeça. É só o palpite inicial: se não existir na malha, a detecção
-- automática procura o nome certo.
local HEAD_BONE = "Head"

-- Componentes filhos de Pawn.Mesh que nunca devem entrar no corpo.
-- (nomes parciais, sem diferenciar maiúsculas/minúsculas)
local EXCLUDED_MESHES = { "preview", "shadowproxy" }

local currentRig    = nil   -- instância do rig de IK ativa
local bodyMeshes    = {}    -- cópias PoseableMesh criadas pelo IK
local meshTags      = {}    -- tags de animação encontradas na última criação
local headBone      = HEAD_BONE -- nome real do osso da cabeça nesta malha

local function log(text, level)
	uevrUtils.print("[body] " .. text, level or LogLevel.Info)
end

-- Sem isto NADA de Lua chega no log.txt: o uevr_utils nasce com
-- logToFile = false (uevr_utils.lua:1802) e o print() cru do Lua vai só para a
-- janela de console do UEVR, não para o arquivo — é por isso que procurar
-- "[body]" no log não devolvia nada, e nem o "UEVR is now ready" do main.lua
-- está lá. Ligar isto NÃO enche o log: o filtro de nível continua valendo e o
-- padrão é Error, então só passam erros de verdade e os marcos abaixo.
uevrUtils.setLogToFile(true)

-- Marcos que PRECISAM aparecer no log.txt. O uevrUtils.print só escreve quando
-- logLevel <= currentLogLevel, e o padrão do perfil é Error: mensagem Info não
-- chega no arquivo. Estes são poucos, acontecem uma vez cada e são exatamente o
-- que se lê quando algo não funciona, então vão como Error de propósito.
local function logMilestone(text)
	uevrUtils.print("[body] " .. text, LogLevel.Error)
end

local function isEnabled()
	return configui.getValue("body_enabled") == true
end

--------------------------------------------------------------------------
-- Seleção das malhas que formam o corpo
--------------------------------------------------------------------------

local function shortName(component)
	local fullName = component:get_full_name()
	return fullName:match("([^%.]+)$") or fullName
end

local function isExcluded(name)
	local lowerName = string.lower(name)
	for _, excluded in ipairs(EXCLUDED_MESHES) do
		if string.find(lowerName, excluded, 1, true) ~= nil then
			return true
		end
	end
	return false
end

local function isSkeletalMesh(component)
	if uevrUtils.getValid(component) == nil then return false end
	local class = uevrUtils.get_class("Class /Script/Engine.SkeletalMeshComponent")
	if class ~= nil and component.is_a ~= nil and not component:is_a(class) then
		return false
	end
	-- só interessa se realmente tem uma malha carregada (UE4 x UE5)
	return uevrUtils.getValid(component, {"SkeletalMesh"}) ~= nil
		or uevrUtils.getValid(component, {"SkeletalMeshAsset"}) ~= nil
end

--------------------------------------------------------------------------
-- A malha viva que serve de origem para o corpo VR.
--
-- SÓ MONTADO: a malha é a do personagem, não a da criatura.
--
-- Numa montaria de criatura (hipogrifo, graphorn) o pawn controlado passa a
-- ser A CRIATURA, e o bruxo vira `pawn:GetMountComponent().RiderCharacter` —
-- é o que o `mounts.getMountPawn` devolve, e é por isso que o main.lua o usa
-- em tudo que fala do personagem (hidePlayer, varinha, câmera).
--
-- Isso importa porque o corpo é recriado sozinho pelo temporizador do ik.lua
-- (`ik.lua:2535`, 1x por segundo enquanto não existir). Se essa recriação cai
-- no meio de um voo de hipogrifo e a malha vem de `pawn.Mesh`, o corpo VR é
-- montado a partir da MALHA DA CRIATURA — 142 ossos, esqueleto de asas. Foi
-- o que aconteceu em 06/08/2026.
--
-- A PÉ NADA MUDA: o bloco do montado nem roda, e o retorno continua sendo o
-- `pawn.Mesh` de sempre.
--------------------------------------------------------------------------
local function getPlayerBodyMesh(shouldLog)
	local playerPawn = uevrUtils.getValid(pawn)
	local baseMesh = playerPawn ~= nil and uevrUtils.getValid(playerPawn, {"Mesh"}) or nil

	if playerPawn ~= nil and not mounts.isWalking() then
		local rider = uevrUtils.getValid(mounts.getMountPawn(playerPawn))
		local riderMesh = rider ~= nil and uevrUtils.getValid(rider, {"Mesh"}) or nil
		if riderMesh ~= nil and riderMesh ~= baseMesh then
			baseMesh = riderMesh
			if shouldLog then
				logMilestone("Montado: corpo criado a partir da malha do personagem, nao da criatura")
			end
		end
	end

	return baseMesh
end

-- Chamada pelo libs/ik.lua quando o parâmetro "animation_mesh" está como "Custom".
-- Tem que ser a mesma malha viva usada como origem do corpo: o
-- CopyPoseFromSkeletalComponent do ik.lua exige esqueletos iguais, então apontar
-- para a criatura montada deixaria o corpo congelado na pose padrão.
function getCustomAnimationIKComponent(rigID)
	return getPlayerBodyMesh(false)
end

-- Chamada pelo libs/ik.lua quando o parâmetro "mesh" está como "Custom".
-- Retorna a lista de malhas que serão copiadas para formar o corpo.
-- A primeira da lista precisa ser a malha com o esqueleto completo (Pawn.Mesh),
-- porque é ela que os solvers usam como referência.
function getCustomIKComponent(rigID)
	meshTags = {}

	local baseMesh = getPlayerBodyMesh(true)

	if baseMesh == nil then
		log("Pawn.Mesh indisponível, corpo não foi criado", LogLevel.Warning)
		return {}
	end

	local templates = {}
	table.insert(templates, { descriptor = "Pawn.Mesh", instance = baseMesh, animation = "Body" })
	meshTags["Body"] = true

	if configui.getValue("body_meshMode") ~= 2 then
		local children = baseMesh.AttachChildren
		if children ~= nil then
			for _, child in ipairs(children) do
				if isSkeletalMesh(child) then
					local name = shortName(child)
					if isExcluded(name) then
						log("Malha ignorada: " .. name)
					else
						local tag = nil
						if string.find(name, "Arm") ~= nil then
							tag = "Arms"
						elseif string.find(name, "Glove") ~= nil then
							tag = "Gloves"
						end
						if tag ~= nil and meshTags[tag] == true then
							tag = nil -- só a primeira malha de cada tipo recebe as animações de dedo
						end
						if tag ~= nil then meshTags[tag] = true end

						table.insert(templates, {
							descriptor = "Pawn.Mesh(" .. name .. ")",
							instance = child,
							animation = tag,
							optional = true,
						})
						log("Malha do corpo: " .. name .. (tag ~= nil and (" [" .. tag .. "]") or ""))
					end
				end
			end
		end
	end

	log("Total de malhas no corpo: " .. #templates)
	return templates
end

--------------------------------------------------------------------------
-- Animação dos dedos reaproveitando as poses do perfil
--------------------------------------------------------------------------

-- O módulo hands_animation monta os IDs como "<mão>_<alvo>", então os alvos
-- precisam bater com o sufixo do ID: "hand", "glove", "body".
local function buildAnimationTable()
	local profile = {}
	local targets = { Body = "body", Arms = "hand", Gloves = "glove" }
	for tag, target in pairs(targets) do
		if meshTags[tag] == true then
			profile[tag] = {
				Left  = { AnimationID = "left_"  .. target },
				Right = { AnimationID = "right_" .. target },
			}
		end
	end
	return { animations = { Shared = handAnimations }, profiles = { Main = profile } }
end

--------------------------------------------------------------------------
-- Detecção automática dos ossos
--
-- Cada jogo nomeia os ossos do seu jeito (RightHand, hand_r, Bip01_R_Hand...)
-- e o ik.lua descarta o solver em silêncio quando o nome não existe na malha
-- (ele exige que o osso tenha 3 gerações de pais). Então, antes de aceitar o
-- corpo, conferimos os nomes contra a malha real e corrigimos o que estiver
-- errado. Nomes que já funcionam nunca são tocados.
--------------------------------------------------------------------------

-- palavras que descartam um osso como sendo a mão (dedos e ossos auxiliares)
local NOT_A_HAND = {
	"index", "middle", "ring", "pinky", "thumb", "finger", "twist", "roll",
	"ik", "attach", "socket", "weapon", "prop", "end", "tip", "ctrl", "helper",
}

local NOT_A_HEAD = { "top", "end", "attach", "socket", "ik", "ctrl", "helper", "hat", "wear" }

-- nomes exatos mais comuns, em ordem de preferência (minúsculas)
local HAND_NAMES = {
	[Handed.Right] = { "righthand", "hand_r", "r_hand", "hand_right", "bip01 r hand", "bip01_r_hand", "mixamorig:righthand" },
	[Handed.Left]  = { "lefthand",  "hand_l", "l_hand", "hand_left",  "bip01 l hand", "bip01_l_hand", "mixamorig:lefthand"  },
}

local HEAD_NAMES = { "head", "bip01 head", "bip01_head", "mixamorig:head", "b_head", "head_01" }

local function toBoneSet(names)
	local set = {}
	for _, name in ipairs(names) do
		set[string.lower(name)] = name
	end
	return set
end

local function containsAny(lowerName, words)
	for _, word in ipairs(words) do
		if string.find(lowerName, word, 1, true) ~= nil then return true end
	end
	return false
end

-- separadores usados pelas convenções de nome: hand_r, hand.r, hand-r, "Bip01 R Hand"
local SEPARATOR = "[_%.%-%s]"

local function hasSideMarker(lowerName, side)
	local word, letter = "left", "l"
	if side == Handed.Right then word, letter = "right", "r" end
	return string.find(lowerName, word, 1, true) ~= nil
		or string.match(lowerName, SEPARATOR .. letter .. "$") ~= nil
		or string.match(lowerName, SEPARATOR .. letter .. SEPARATOR) ~= nil
end

-- Procura o osso da mão: primeiro pelos nomes conhecidos, depois por
-- qualquer osso que contenha "hand" (ou "wrist") do lado certo. Entre vários
-- candidatos vence o nome mais curto, que é sempre a raiz da mão.
local function detectHandBone(names, set, side)
	for _, candidate in ipairs(HAND_NAMES[side]) do
		if set[candidate] ~= nil then return set[candidate] end
	end

	for _, keyword in ipairs({ "hand", "wrist" }) do
		local best = nil
		for _, name in ipairs(names) do
			local lower = string.lower(name)
			if string.find(lower, keyword, 1, true) ~= nil
				and not containsAny(lower, NOT_A_HAND)
				and hasSideMarker(lower, side)
				and (best == nil or #name < #best)
			then
				best = name
			end
		end
		if best ~= nil then return best end
	end

	return nil
end

local function detectHeadBone(names, set)
	for _, candidate in ipairs(HEAD_NAMES) do
		if set[candidate] ~= nil then return set[candidate] end
	end
	local best = nil
	for _, name in ipairs(names) do
		local lower = string.lower(name)
		if string.find(lower, "head", 1, true) ~= nil
			and not containsAny(lower, NOT_A_HEAD)
			and (best == nil or #name < #best)
		then
			best = name
		end
	end
	return best
end

-- Cadeia do osso até a raiz: {osso, pai, avô, ...}. Versão com limite — a
-- uevrUtils.getAncestorBones roda um while sem teto e um esqueleto com
-- hierarquia estranha travaria o jogo.
local function getBoneChain(mesh, boneName, maxDepth)
	local chain = { boneName }
	local current = boneName
	for _ = 1, (maxDepth or 6) do
		local parent = mesh:GetParentBone(current)
		if parent == nil then break end
		parent = parent:to_string()
		if parent == "" or parent == "None" or parent == current then break end
		table.insert(chain, parent)
		current = parent
	end
	return chain
end

-- Corrige os ossos de um solver. Devolve true se mudou alguma coisa.
-- A cadeia braço → antebraço → mão sai da própria hierarquia da malha, então
-- só a mão precisa ser adivinhada.
local function fixSolverBones(rig, mesh, names, set, solverId, solverParams)
	local side = Handed.Right
	if solverParams["end_control_type"] == 0 then side = Handed.Left end

	local endBone = solverParams["end_bone"] or ""
	if endBone ~= "" and set[string.lower(endBone)] ~= nil then
		return false -- o nome configurado existe na malha, não mexe
	end

	local detected = detectHandBone(names, set, side)
	-- se um lado foi achado e o outro não, espelha o nome
	if detected == nil then
		local other = detectHandBone(names, set, side == Handed.Right and Handed.Left or Handed.Right)
		if other ~= nil then
			detected = uevrUtils.findOppositeBone(other, side == Handed.Right, names)
		end
	end

	if detected == nil then
		log("Não achei o osso da mão " .. (side == Handed.Right and "direita" or "esquerda")
			.. " para o solver '" .. tostring(solverId) .. "'. Use 'Listar ossos no log' e "
			.. "escolha na aba IK Dev Config.", LogLevel.Warning)
		return false
	end

	local chain = getBoneChain(mesh, detected, 5)
	if #chain < 3 then
		log("Osso '" .. detected .. "' não tem antebraço e braço acima dele, ignorado", LogLevel.Warning)
		return false
	end

	log("Solver '" .. tostring(solverId) .. "': usando " .. chain[3] .. " -> " .. chain[2] .. " -> " .. chain[1])
	rig:setConfigParameter({ "solvers", solverId, "end_bone" }, chain[1], true)
	rig:setConfigParameter({ "solvers", solverId, "joint_bone" }, chain[2], true)
	rig:setConfigParameter({ "solvers", solverId, "start_bone" }, chain[3], true)

	-- ombro e espinha (usados só pelo modo "Somente braços") saem da mesma cadeia
	local shoulderKey = side == Handed.Right and "right_shoulder_bone_name" or "left_shoulder_bone_name"
	if chain[4] ~= nil then
		rig:setConfigParameter(shoulderKey, chain[4], true)
		if chain[5] ~= nil then
			rig:setConfigParameter("spine_bone_name", chain[5], true)
		end
	end

	return true
end

-- Devolve true se algum osso foi corrigido (nesse caso o corpo é reconstruído).
local function detectBones(rig, force)
	local mesh = bodyMeshes[1]
	if uevrUtils.getValid(mesh) == nil then return false end

	local names = uevrUtils.getBoneNames(mesh)
	if names == nil or #names == 0 then
		log("A malha do corpo não devolveu nenhum osso", LogLevel.Warning)
		return false
	end
	local set = toBoneSet(names)

	-- cabeça (não faz parte do rig, aplica na hora)
	if set[string.lower(headBone)] == nil or force then
		local detectedHead = detectHeadBone(names, set)
		if detectedHead ~= nil then
			if detectedHead ~= headBone then
				log("Osso da cabeça: " .. detectedHead)
			end
			headBone = detectedHead
		else
			log("Não achei o osso da cabeça; 'Esconder a cabeça' não vai funcionar", LogLevel.Warning)
		end
	end

	-- braços: lê a configuração gravada para saber quais solvers existem
	-- (não dá para ler do rig: quando o nome do osso está errado o ik.lua
	--  descarta o solver e ele nem aparece em rig.activeSolvers)
	if json == nil then return false end
	local params = json.load_file("ik_parameters.json")
	local rigParams = params ~= nil and params[rig.rigId or ""] or nil
	local solvers = rigParams ~= nil and rigParams.solvers or nil
	if solvers == nil then return false end

	local changed = false
	for solverId, solverParams in pairs(solvers) do
		if force then solverParams["end_bone"] = "" end
		if fixSolverBones(rig, mesh, names, set, solverId, solverParams) then
			changed = true
		end
	end
	return changed
end

--------------------------------------------------------------------------
-- Visibilidade
--------------------------------------------------------------------------

-- Roda a cada frame quando a animação do corpo está ligada, então usa o struct
-- reutilizável: é o mesmo vetor para todas as malhas do laço, consumido na hora.
--
-- SEMPRE ATIVO (10/08/2026, a pedido do Renan): o checkbox "Esconder a cabeca"
-- saiu do painel. Em primeira pessoa a câmera fica DENTRO da cabeça — mostrá-la
-- só rende o interior do crânio na cara do jogador, então nunca houve motivo
-- real para desligar. O osso é encolhido (escala 0,001), não movido: a POSIÇÃO
-- dele continua valendo, e é dela que sai a câmera atracada à cabeça.
local function applyHeadVisibility()
	local scale = uevrUtils.vector(0.001, 0.001, 0.001, true)
	for _, mesh in ipairs(bodyMeshes) do
		if uevrUtils.getValid(mesh) ~= nil and mesh.SetBoneScaleByName ~= nil then
			mesh:SetBoneScaleByName(uevrUtils.fname_from_string(headBone), scale, EBoneSpaces.ComponentSpace)
		end
	end
end

local function applyShadowSetting()
	local castShadow = configui.getValue("body_shadow") == true
	for _, mesh in ipairs(bodyMeshes) do
		if uevrUtils.getValid(mesh) ~= nil then
			mesh.bCastDynamicShadow = castShadow
			-- BoundsScale grande evita que o corpo seja descartado pelo frustum
			-- quando a origem da malha (nos pés) sai do campo de visão. O ik.lua
			-- já põe 16 na criação; reafirmamos porque é barato e é o tipo de
			-- coisa que, se falhar, o sintoma é o corpo sumindo.
			mesh.BoundsScale = 16.0
			-- bRenderInDepthPass NÃO é forçado: o exemplo do ik.md desliga, mas
			-- em Native Stereo tirar a malha do depth prepass é candidato a
			-- artefato de render. Fica o padrão do motor.
		end
	end
end

-- O corpo some em terceira pessoa e em cinemáticas, porque nesses casos o jogo
-- mostra o personagem original.
--
-- NA MONTARIA NÃO SOME (10/08/2026): existiu aqui um "Esconder o corpo na
-- montaria", removido a pedido do Renan. Ele nunca ganhava em caso nenhum —
-- como o perfil já esconde o jogador em primeira pessoa, ligá-lo deixava você
-- sem corpo NENHUM em cima da vassoura, e por isso vinha desligado desde
-- sempre. Todo o trabalho da montaria (copiar a malha do jogo, o giro e a
-- postura da cintura) existe justamente para o corpo aparecer certo lá.
local function shouldHideBody()
	if configui.getValue("isFP") == false then return true end
	local playerPawn = uevrUtils.getValid(pawn)
	if playerPawn == nil then return true end
	if playerPawn.InCinematic == true then return true end
	return false
end

-- O ik.lua consulta este callback a cada 200ms e esconde/mostra o corpo quando
-- a resposta muda. Se alguma das condições oscilar (o pawn.InCinematic entra e
-- sai durante certas animações), isso vira pisca-pisca a 5Hz. Por isso só
-- escondemos depois de duas leituras seguidas pedindo para esconder — voltar a
-- aparecer continua imediato.
local hideStreak = 0
local bodyHidden = false

-- Estado JÁ FILTRADO, e é este que o resto do arquivo deve usar.
--
-- Chamar shouldHideBody() cru a cada frame era um erro meu: as pernas, a
-- posição do corpo e a câmera faziam isso, e o InCinematic — que este arquivo
-- já documentava como instável — ligava e desligava as três de um frame para o
-- outro. O corpo parava e voltava, e com a câmera na cabeça ela ainda saltava
-- entre o osso da cabeça e a câmera normal do perfil. Dava exatamente a
-- "flicada", e mais forte com a câmera na cabeça ligada.
local function isBodyHidden()
	return bodyHidden
end

uevrUtils.registerUEVRCallback("is_hands_hidden", function()
	if not isEnabled() then return nil end
	if shouldHideBody() then
		hideStreak = hideStreak + 1
	else
		hideStreak = 0
	end
	bodyHidden = hideStreak >= 2
	return bodyHidden, 20
end)

-- NOTA: existiu aqui uma "trava de cabeça" que mexia na POSIÇÃO do corpo a cada
-- frame para encostar o osso da cabeça no HMD. Ela era a causa do corpo piscar e
-- foi removida. A posição é configurada em jogo, pelo campo "Posicao".

--------------------------------------------------------------------------
-- 1. Animação das pernas — receita do perfil do Silent Hill f, restrita
--
-- O ik.lua cria o corpo com useDefaultPose = true, ou seja, pose de referência
-- parada, e só mexe nos braços. É por isso que as pernas não andavam.
--
-- No Silent Hill f o corpo ganha animação copiando a pose da malha que o jogo
-- anima (libs/montage.lua dispara isso por montagem). Copiar a pose INTEIRA,
-- porém, anima o corpo todo — e aí o tronco, a cabeça e principalmente os dedos
-- passam a seguir a animação do jogo em vez do VR. Então copiamos só a subárvore
-- de ossos das pernas, da coxa para baixo, e o resto fica como estava.
--
-- A conta é a mesma do animation.copyDescendantTransforms da lib: lê o osso na
-- malha de origem em espaço de componente, e reancora no quadril da cópia, que
-- continua parado. Por isso as pernas andam "penduradas" na cintura do corpo VR
-- em vez de arrastarem o corpo junto.
--
-- Um detalhe que também veio do SHf: o pawn_parameters.json deles esconde o
-- corpo real com `hideSettingsRenderInMainPass` em vez de SetVisibility,
-- justamente para a malha continuar animando. O perfil do Hogwarts usa
-- SetVisibility, então forçamos VisibilityBasedAnimTickOption nas malhas de
-- origem para os ossos continuarem sendo atualizados mesmo escondidas.
--------------------------------------------------------------------------

local RTS_COMPONENT = 2 -- ERelativeTransformSpace::RTS_Component

local FOOT_NAMES = {
	[Handed.Right] = { "rightfoot", "foot_r", "r_foot", "bip01 r foot", "mixamorig:rightfoot" },
	[Handed.Left]  = { "leftfoot",  "foot_l", "l_foot", "bip01 l foot", "mixamorig:leftfoot"  },
}
local NOT_A_FOOT = { "toe", "ball", "ik", "attach", "socket", "twist", "roll", "ctrl", "helper", "end", "tip" }

local legBones = nil       -- { {name=..., fname=...}, ... } coxa para baixo
local legAnchorFName = nil -- quadril: a âncora das pernas

-- Posição do quadril na POSE DE REFERÊNCIA, capturada quando o corpo nasce.
-- É a partir dela que o quadril é reposicionado a cada frame — nunca a partir
-- do valor lido de volta do osso, que é o que nós mesmos escrevemos no frame
-- anterior e faria a posição derivar sozinha.
local referenceHip = nil
-- Altura do quadril na malha de ORIGEM com o personagem em pé, capturada no
-- primeiro frame. É contra esta que o agachamento é medido, e não contra a pose
-- de referência: as duas não coincidem. A pose de referência é a bind pose crua
-- (perna reta), enquanto a pose animada de "em pé" tem sempre um joelho mole —
-- a diferença entre elas é livre, pode ser para cima ou para baixo, e entrava
-- inteira na conta do agachamento. Se a bind pose fosse mais BAIXA que o "em
-- pé" animado, a diferença comia a folga e o agachamento quase não passava.
local standingSourceHipZ = nil
-- O quanto o quadril está abaixado agora (0 = em pé), suavizado.
local hipDrop = 0

-- O quanto o quadril escrito neste quadro saiu da pose de referência, em espaço
-- de componente. A cintura (seção 1c) é escrita em espaço de componente, ou
-- seja, em posição ABSOLUTA dentro do esqueleto — se ela ficasse na translação
-- da pose de referência enquanto o quadril anda (o que acontece montado, onde o
-- quadril é copiado inteiro), o tronco descolaria das pernas. Somando este
-- deslocamento, a cintura acompanha o quadril como filha dele.
local hipShift = { X = 0, Y = 0, Z = 0 }

-- O quadril da animação balança o tempo todo: sobe e desce a cada passo e joga
-- para os lados. Como o tronco é filho do quadril, copiar esse balanço fazia o
-- TRONCO INTEIRO (e a câmera presa na cabeça dele) balançar junto.
--
-- Separação por amplitude, que aqui é limpa: o balanço do andar fica na casa
-- dos 2-4 cm, um agachamento passa de 30. Abaixo do limite não é agachamento, é
-- balanço, e vira zero.
--
-- SEM LERP (10/08/2026). Havia um aqui, com constante de ~100 ms, "só para
-- suavizar a transição" — e ele não era necessário: a conta já é contínua na
-- borda da zona morta (no limite, `target` vale exatamente 0 e cresce dali),
-- então não há degrau para amortecer. O que ele fazia de fato era ATRASAR.
--
-- Aparecia na ROLAGEM: o quadril do jogo despenca de uma vez, o nosso ia atrás
-- amortecido, e como o tronco é filho do quadril e a câmera está na cabeça do
-- tronco, os 100 ms chegavam inteiros na vista. Agora o quadril acompanha no
-- mesmo quadro.
local HIP_DROP_DEADZONE = 8.0

local function keepSourceMeshesAnimating(rig)
	for _, template in pairs(rig.meshTemplates or {}) do
		local source = template.instance
		if uevrUtils.getValid(source) ~= nil and source.VisibilityBasedAnimTickOption ~= nil then
			source.VisibilityBasedAnimTickOption = ALWAYS_TICK_POSE_AND_REFRESH_BONES
		end
	end
end

local function detectFootBone(names, set, side)
	for _, candidate in ipairs(FOOT_NAMES[side]) do
		if set[candidate] ~= nil then return set[candidate] end
	end
	for _, keyword in ipairs({ "foot", "ankle" }) do
		local best = nil
		for _, name in ipairs(names) do
			local lower = string.lower(name)
			if string.find(lower, keyword, 1, true) ~= nil
				and not containsAny(lower, NOT_A_FOOT)
				and hasSideMarker(lower, side)
				and (best == nil or #name < #best)
			then
				best = name
			end
		end
		if best ~= nil then return best end
	end
	return nil
end

-- Acha o pé de cada lado e sobe a hierarquia: pé -> canela -> coxa -> quadril.
-- A lista final é coxa + todos os descendentes dela (canela, pé, dedos, twist).
local function detectLegBones(mesh)
	legBones, legAnchorFName = nil, nil
	referenceHip, standingSourceHipZ, hipDrop = nil, nil, 0
	hipShift.X, hipShift.Y, hipShift.Z = 0, 0, 0
	if uevrUtils.getValid(mesh) == nil then return end

	local names = uevrUtils.getBoneNames(mesh)
	if names == nil or #names == 0 then return end
	local set = toBoneSet(names)

	local bones, anchor = {}, nil
	for _, side in ipairs({ Handed.Right, Handed.Left }) do
		local foot = detectFootBone(names, set, side)
		if foot ~= nil then
			local chain = getBoneChain(mesh, foot, 4) -- {pé, canela, coxa, quadril}
			if #chain >= 4 then
				local thigh = chain[3]
				anchor = anchor or chain[4]
				table.insert(bones, thigh)
				for _, descendant in ipairs(animation.getDescendantBones(mesh, thigh, false)) do
					table.insert(bones, descendant)
				end
			end
		end
	end

	if #bones == 0 or anchor == nil then
		log("Não achei os ossos das pernas — a animação das pernas fica desligada", LogLevel.Warning)
		return
	end

	legBones = {}
	for _, name in ipairs(bones) do
		table.insert(legBones, { name = name, fname = uevrUtils.fname_from_string(name) })
	end
	legAnchorFName = uevrUtils.fname_from_string(anchor)

	-- A cópia ainda está na pose de referência aqui (nasce com
	-- useDefaultPose = true e nada escreveu nela), então este é o único momento
	-- em que dá para ler a posição "de pé" do quadril.
	local hipTransform = mesh:GetBoneTransformByName(legAnchorFName, EBoneSpaces.ComponentSpace)
	if hipTransform ~= nil and hipTransform.Translation ~= nil then
		referenceHip = {
			X = hipTransform.Translation.X,
			Y = hipTransform.Translation.Y,
			Z = hipTransform.Translation.Z,
		}
	end

	logMilestone("Pernas: " .. #legBones .. " ossos, ancoradas em " .. anchor
		.. ", quadril de pe em Z=" .. (referenceHip and string.format("%.1f", referenceHip.Z) or "?"))
end

-- A malha de origem da cópia principal é quem carrega a animação do jogo.
local function getSourceMesh()
	if currentRig == nil then return nil end
	local reference = bodyMeshes[1]
	if reference == nil then return nil end
	for _, template in pairs(currentRig.meshTemplates or {}) do
		if template.mesh == reference then return template.instance end
	end
	return nil
end

local function copyLegPose(engine, delta)
	-- Sem cópia de pernas o quadril fica na pose de referência, então a cintura
	-- não tem deslocamento para acompanhar — zerar aqui evita que um hipShift
	-- velho continue empurrando o tronco depois de desligar a animação.
	if not isEnabled() or currentRig == nil or legBones == nil
		or configui.getValue("body_animate") == false
		or configui.getValue("body_onlyArms") == true
		or isBodyHidden()
	then
		hipShift.X, hipShift.Y, hipShift.Z = 0, 0, 0
		return
	end

	local reference = bodyMeshes[1]
	if uevrUtils.getValid(reference) == nil or reference.SetBoneTransformByName == nil then return end

	local source = getSourceMesh()
	if uevrUtils.getValid(source) == nil or source.GetSocketTransform == nil then return end

	local sourceAnchor = source:GetSocketTransform(legAnchorFName, RTS_COMPONENT)
	local targetAnchor = reference:GetBoneTransformByName(legAnchorFName, EBoneSpaces.ComponentSpace)
	if sourceAnchor == nil or targetAnchor == nil then return end

	-- O quadril continua sendo ÂNCORA — é o que mantém o tronco parado. A única
	-- coisa que a animação move nele é a ALTURA, e só quando é agachamento de
	-- verdade (ver HIP_DROP_DEADZONE): copiar a translação inteira trazia junto
	-- o balanço de cada passo, e o tronco, que é filho do quadril, balançava
	-- todo — com a câmera presa na cabeça, direto no olho.
	--
	-- X e Y vêm sempre da pose de referência. A rotação também fica intocada: o
	-- quadril é a raiz do esqueleto, então girá-lo giraria o tronco inteiro e
	-- brigaria com o "Corpo acompanha a visao".
	--
	-- Tudo é reconstruído a partir de referenceHip, capturado na criação, e não
	-- do que está no osso: o osso guarda o que escrevemos no frame anterior, e
	-- realimentar isso faria a posição derivar sozinha.
	-- linha do "em pé", medida na própria malha animada no primeiro frame — e só
	-- a pé, senão um corpo criado em cima do hipogrifo grava a altura de quem
	-- está sentado como se fosse a de quem está de pé
	if standingSourceHipZ == nil and mounts.isWalking() then
		standingSourceHipZ = sourceAnchor.Translation.Z
	end

	-- MONTADO: o quadril vai para onde a animação do jogo o põe, sem nada disso.
	--
	-- Toda a prudência acima — prender X e Y, exigir 8 cm de folga na altura —
	-- existe por causa do BALANÇO DO ANDAR. Montado não há passo nenhum, e a
	-- pose sentada acabava presa na altura de quem está de pé: o tronco flutuava
	-- acima da sela e sobrava compensar isso na mão, pelo "Ajuste na montaria".
	--
	-- Copiando o quadril inteiro, a cópia senta onde o personagem do jogo senta,
	-- e o `align` abaixo vira identidade na translação — as pernas caem em cima
	-- das pernas dele. Não é perseguição: é a mesma pose, lida uma vez por
	-- quadro em espaço de componente.
	local mounted = not mounts.isWalking()

	if mounted or referenceHip ~= nil then
		if mounted then
			targetAnchor.Translation.X = sourceAnchor.Translation.X
			targetAnchor.Translation.Y = sourceAnchor.Translation.Y
			targetAnchor.Translation.Z = sourceAnchor.Translation.Z
			hipDrop = 0
		else
			hipDrop = 0
			if configui.getValue("body_followCrouch") ~= false and standingSourceHipZ ~= nil then
				-- só para baixo, e só o que passar da folga: andar não é agachar
				hipDrop = math.min(0, sourceAnchor.Translation.Z - standingSourceHipZ + HIP_DROP_DEADZONE)
			end

			-- escrito sempre, inclusive com hipDrop = 0: é assim que o quadril volta
			-- para a altura de pé quando o agachamento é desligado no painel
			targetAnchor.Translation.X = referenceHip.X
			targetAnchor.Translation.Y = referenceHip.Y
			targetAnchor.Translation.Z = referenceHip.Z + hipDrop
		end

		-- guardado para a cintura acompanhar (ver hipShift)
		if referenceHip ~= nil then
			hipShift.X = targetAnchor.Translation.X - referenceHip.X
			hipShift.Y = targetAnchor.Translation.Y - referenceHip.Y
			hipShift.Z = targetAnchor.Translation.Z - referenceHip.Z
		end

		for _, component in ipairs(bodyMeshes) do
			if uevrUtils.getValid(component) ~= nil and component.SetBoneTransformByName ~= nil then
				component:SetBoneTransformByName(legAnchorFName, targetAnchor, EBoneSpaces.ComponentSpace)
			end
		end
	end

	-- As pernas são reancoradas no quadril (que agora pode estar abaixado), então
	-- elas continuam rigidamente presas a ele — sem rasgo na cintura. Parado ou
	-- agachado de verdade, hipDrop bate com o agachamento da animação e os pés
	-- caem no lugar certo; andando, sobra a diferença do balanço, que é o
	-- deslizezinho de pé que o método sempre teve.
	local align = kismet_math_library:ComposeTransforms(
		kismet_math_library:InvertTransform(sourceAnchor), targetAnchor)

	-- Ajuste manual das pernas, do painel. Entra DEPOIS da reancoragem, em
	-- espaço de componente, então é um empurrão simples no conjunto todo — coxa,
	-- canela, pé e dedos andam juntos e continuam presos entre si.
	--
	-- Serve para o caso de as pernas nascerem deslocadas do tronco: como elas
	-- são reancoradas no quadril e o tronco fica na pose de referência, uma
	-- diferença entre as duas poses aparece como perna fora do lugar. Aqui você
	-- corrige sem mexer em nada mais.
	local legOffset = configui.getValue("body_legOffset")
	local lx = legOffset and (legOffset.x or legOffset.X or 0) or 0
	local ly = legOffset and (legOffset.y or legOffset.Y or 0) or 0
	local lz = legOffset and (legOffset.z or legOffset.Z or 0) or 0
	local hasLegOffset = (lx ~= 0 or ly ~= 0 or lz ~= 0)

	for _, bone in ipairs(legBones) do
		local transform = source:GetSocketTransform(bone.fname, RTS_COMPONENT)
		if transform ~= nil then
			local aligned = kismet_math_library:ComposeTransforms(transform, align)
			if hasLegOffset and aligned.Translation ~= nil then
				aligned.Translation.X = aligned.Translation.X + lx
				aligned.Translation.Y = aligned.Translation.Y + ly
				aligned.Translation.Z = aligned.Translation.Z + lz
			end
			for _, component in ipairs(bodyMeshes) do
				if uevrUtils.getValid(component) ~= nil and component.SetBoneTransformByName ~= nil then
					component:SetBoneTransformByName(bone.fname, aligned, EBoneSpaces.ComponentSpace)
				end
			end
		end
	end
end

-- Prioridade 10 = roda ANTES do tick do ik.lua (que é 0). Como só mexemos em
-- osso de perna e o IK só mexe em braço, os dois não se atropelam.
uevrUtils.registerPreEngineTickCallback(function(engine, delta)
	local ok, err = pcall(copyLegPose, engine, delta)
	if not ok then
		log("Falha ao animar as pernas: " .. tostring(err), LogLevel.Warning)
	end
end, 10)

--------------------------------------------------------------------------
-- 1b. SÓ MONTADO: destravar o Z do ik.lua para os braços mirarem certo
--
-- Era este o motivo das mãos ficarem paradas no hipogrifo, e não o solver.
--
-- O tick do ik.lua (ik.lua:417) começa escrevendo, todo frame,
--     RelativeLocation.Z = offset + (offset + CapsuleHalfHeight)
-- e SÓ DEPOIS resolve os braços. Montado numa criatura, o pawn é a CRIATURA e
-- essa cápsula é enorme: a cópia era atirada para longe em Z bem no instante em
-- que os solvers convertem a posição dos controles para o espaço do componente.
-- O alvo caía fora do alcance do braço, o solver saturava, e a mão congelava
-- numa pose só. A imagem parecia certa porque a posição era corrigida logo
-- depois, no tick de prioridade -10 (o "corpo copia a malha do jogo").
--
-- A saída é do próprio ik.lua: com `coupling == 2` ele não toca no Z
-- (ik.lua:418). Trocamos o campo na instância do rig só enquanto estiver
-- montado, e devolvemos o valor original ao desmontar.
--
-- Duas condições de segurança:
--   * só quando "corpo copia a malha do jogo" está ligado — é ele que escreve a
--     posição do corpo montado. Sem ele, ninguém cuidaria do Z;
--   * a devolução compara antes de escrever, então A PÉ ISTO É UM NO-OP: o
--     valor já é o original e nada é tocado.
--
-- Prioridade 20 = antes de tudo o que é nosso e antes do ik.lua.
--------------------------------------------------------------------------

--------------------------------------------------------------------------
-- SÓ MONTADO: o ik.lua tem que olhar para o PERSONAGEM, não para a criatura.
--
-- O rig não resolve tudo pela malha: em dois pontos ele vai buscar o pawn —
-- `ik.lua:493` (a quem o corpo é anexado, no `RootComponent`) e `ik.lua:411`
-- (a `CapsuleHalfHeight` que entra na conta do Z a cada tick). Montado numa
-- criatura o pawn controlado É A CRIATURA, então o corpo do bruxo era ancorado
-- na raiz do hipogrifo e recebia a altura de cápsula dele.
--
-- O próprio ik.lua já prevê isso e nunca era usado: `M.setPawn` (ik.lua:80)
-- troca só essa referência — `getPawn()` devolve `pawnObject or pawn`. Não mexe
-- em quem o jogo controla, só em de onde o rig lê raiz e cápsula.
--
-- A PÉ É UM NO-OP: `getMountPawn` devolve o próprio pawn, e nada muda.
--------------------------------------------------------------------------
local lastRigPawn = nil

local function updateRigPawn()
	local playerPawn = uevrUtils.getValid(pawn)
	if playerPawn == nil then
		-- sem pawn válido, devolve o padrão: com pawnObject nil o getPawn()
		-- do ik.lua cai sozinho no pawn global.
		if lastRigPawn ~= nil then
			lastRigPawn = nil
			ik.setPawn(nil)
		end
		return
	end

	local rigPawn = uevrUtils.getValid(mounts.getMountPawn(playerPawn)) or playerPawn
	if rigPawn == lastRigPawn then return end
	lastRigPawn = rigPawn

	ik.setPawn(rigPawn)
	if rigPawn ~= playerPawn then
		logMilestone("Montado: ik.lua ancorado no personagem, nao na criatura")
	else
		logMilestone("ik.lua ancorado no pawn controlado")
	end
end

-- valor original do `coupling` do rig (vem de parent_type), guardado na criação
local rigCoupling = nil

-- SOMENTE BRAÇOS usa o mesmo destravamento, e pelo mesmo motivo de fundo: a
-- conta do `ik.lua:417` descreve um corpo INTEIRO, com os pés no chão. Sem
-- tronco nem pernas ela não descreve nada — só joga a cópia 1,5 m abaixo de
-- onde os ombros têm de estar, todo frame, para a nossa correção desfazer logo
-- em seguida. Dois donos escrevendo o mesmo Z é a receita do pisca: basta um
-- frame em que o nosso tick não rode (ou role antes) para os braços irem parar
-- nos pés. Com coupling = 2 o ik.lua não toca no Z e nós somos o único dono.
local function updateMountCoupling()
	if currentRig == nil then return end

	local wantFree = configui.getValue("body_onlyArms") == true
		or (not mounts.isWalking()
			and configui.getValue("body_mountArmsIK") ~= false)

	if wantFree then
		if currentRig.coupling ~= 2 then
			currentRig.coupling = 2
			logMilestone("Z do ik.lua liberado, quem posiciona a copia e o body.lua")
		end
	elseif rigCoupling ~= nil and currentRig.coupling ~= rigCoupling then
		currentRig.coupling = rigCoupling
		logMilestone("Z do ik.lua devolvido (coupling " .. tostring(rigCoupling) .. ")")
	end
end

-- DIAGNÓSTICO, sem efeito nenhum no jogo: registra no log toda vez que o estado
-- de montaria MUDA, com os números crus do momento. É o que responde, sem
-- adivinhação, duas perguntas que o log de hoje deixou em aberto:
--
--   * o estado de montaria oscila sozinho? (no log de 06/08 houve um
--     "desmontado" seguido de "montado" 0,5 s depois, o que não é gente
--     desmontando — e cada oscilação joga o corpo entre a conta de quem está
--     montado e a de quem está a pé);
--   * montado, onde estão de fato a malha do jogo, a cópia e a sua cabeça.
-- Ossos do braço direito, só para o diagnóstico abaixo.
local diagArmBone, diagHandBone = nil, nil

local function detectDiagArmBones(mesh)
	diagArmBone, diagHandBone = nil, nil
	if uevrUtils.getValid(mesh) == nil then return end
	local names = uevrUtils.getBoneNames(mesh)
	if names == nil or #names == 0 then return end
	local hand = detectHandBone(names, toBoneSet(names), Handed.Right)
	if hand == nil then return end
	local chain = getBoneChain(mesh, hand, 5)
	diagHandBone = uevrUtils.fname_from_string(hand)
	if chain[3] ~= nil then diagArmBone = uevrUtils.fname_from_string(chain[3]) end
end

-- DIAGNÓSTICO DOS BRAÇOS, sem efeito no jogo. A cada 2 s, e só montado, anota o
-- que decide se a mão segue o controle:
--
--   * "animando pela malha" — se algum callback `is_hands_animating_from_mesh`
--     responder true, o ik.lua NEM CHAMA os solvers (ik.lua:435): ele copia a
--     pose do braço da malha do jogo. Mão parada segurando a rédea seria
--     exatamente isso;
--   * ombro, mão e controle em MUNDO, mais a distância ombro→controle. Se essa
--     distância for muito maior que o braço, o solver satura e a mão congela no
--     limite do alcance, mesmo rodando normalmente.
local diagTimer = 0

local function logArmDiagnostics(delta)
	if mounts.isWalking() then diagTimer = 0 return end
	if currentRig == nil or #bodyMeshes == 0 then return end
	diagTimer = diagTimer + (delta or 0)
	if diagTimer < 2.0 then return end
	diagTimer = 0

	local mesh = bodyMeshes[1]
	if uevrUtils.getValid(mesh) == nil or mesh.GetBoneLocationByName == nil then return end

	local function fmt(v)
		if v == nil then return "nil" end
		return string.format("(%.0f, %.0f, %.0f)", v.X or 0, v.Y or 0, v.Z or 0)
	end

	local animLeft = uevrUtils.executeUEVRCallbacksWithPriorityBooleanResult(
		"is_hands_animating_from_mesh", Handed.Left)
	local animRight = uevrUtils.executeUEVRCallbacksWithPriorityBooleanResult(
		"is_hands_animating_from_mesh", Handed.Right)

	local shoulder = diagArmBone ~= nil and mesh:GetBoneLocationByName(diagArmBone, EBoneSpaces.WorldSpace) or nil
	local hand = diagHandBone ~= nil and mesh:GetBoneLocationByName(diagHandBone, EBoneSpaces.WorldSpace) or nil
	local controller = controllers.getController(1)
	local controllerLoc = uevrUtils.getValid(controller) ~= nil and controller:K2_GetComponentLocation() or nil

	local reach = "?"
	if shoulder ~= nil and controllerLoc ~= nil then
		reach = string.format("%.0f", kismet_math_library:Vector_Distance(shoulder, controllerLoc))
	end
	local erro = "?"
	if hand ~= nil and controllerLoc ~= nil then
		erro = string.format("%.0f", kismet_math_library:Vector_Distance(hand, controllerLoc))
	end

	local solvers = 0
	for _ in pairs(currentRig.activeSolvers or {}) do solvers = solvers + 1 end

	logMilestone("[bracos] solvers=" .. solvers
		.. ", animando pela malha: esq=" .. tostring(animLeft) .. " dir=" .. tostring(animRight)
		.. ", ombro=" .. fmt(shoulder) .. ", mao=" .. fmt(hand)
		.. ", controle=" .. fmt(controllerLoc)
		.. ", ombro->controle=" .. reach .. "cm, mao->controle=" .. erro .. "cm")
end

local lastLoggedMountType = nil

local function logMountStateChange()
	local mountType = mounts.getMountType()
	if mountType == lastLoggedMountType then return end
	lastLoggedMountType = mountType

	local function fmt(v)
		if v == nil then return "nil" end
		return string.format("(%.0f, %.0f, %.0f)", v.X or 0, v.Y or 0, v.Z or 0)
	end
	local function nameOf(obj)
		if uevrUtils.getValid(obj) == nil or obj.get_full_name == nil then return "nil" end
		local full = obj:get_full_name()
		return full:sub(-60)
	end

	-- O TIPO SAI PRIMEIRO, antes de qualquer coisa que possa estourar. Estava no
	-- fim: bastava uma das leituras abaixo falhar para a linha inteira sumir, e
	-- como `lastLoggedMountType` já foi atualizado acima, aquela transição nunca
	-- mais era registrada. Foi assim que a montaria em criatura passou batida.
	logMilestone("--- montaria mudou: tipo=" .. tostring(mountType)
		.. ", voando=" .. tostring(mounts.getIsFlying()) .. " ---")

	local playerPawn = uevrUtils.getValid(pawn)
	local rider = playerPawn ~= nil and uevrUtils.getValid(mounts.getMountPawn(playerPawn)) or nil
	local source = getSourceMesh()
	local mesh = bodyMeshes[1]
	local hmd = controllers.getController(2)
	local root = uevrUtils.getValid(playerPawn, {"RootComponent"})
	logMilestone("  pawn=" .. nameOf(playerPawn) .. ", personagem=" .. nameOf(rider))
	logMilestone("  capsula=" .. tostring(root ~= nil and root.CapsuleHalfHeight or "nil")
		.. ", root=" .. fmt(root ~= nil and root:K2_GetComponentLocation() or nil))
	logMilestone("  malha do jogo=" .. nameOf(source) .. " em "
		.. fmt(uevrUtils.getValid(source) ~= nil and source:K2_GetComponentLocation() or nil))
	logMilestone("  copia=" .. fmt(uevrUtils.getValid(mesh) ~= nil and mesh:K2_GetComponentLocation() or nil)
		.. ", cabeca=" .. fmt(uevrUtils.getValid(mesh) ~= nil and mesh.GetSocketLocation ~= nil
			and mesh:GetSocketLocation(uevrUtils.fname_from_string(headBone)) or nil)
		.. ", HMD=" .. fmt(uevrUtils.getValid(hmd) ~= nil and hmd:K2_GetComponentLocation() or nil))
end

-- Estas falhas iam como Warning e o filtro do perfil é Error, então NUNCA
-- chegavam no log.txt: um pcall que estoura todo frame ficava completamente
-- invisível. Agora vão como marco (Error), e cada mensagem distinta sai só uma
-- vez para não encher o arquivo a 30 Hz.
local loggedTickFailures = {}

local function logTickFailure(prefix, err)
	local text = prefix .. ": " .. tostring(err)
	if loggedTickFailures[text] then return end
	loggedTickFailures[text] = true
	logMilestone(text)
end

uevrUtils.registerPreEngineTickCallback(function(engine, delta)
	-- antes do coupling: quem for refazer o rig neste frame já pega o pawn certo
	local okPawn, errPawn = pcall(updateRigPawn)
	if not okPawn then
		logTickFailure("Falha ao apontar o pawn do rig", errPawn)
	end
	local ok, err = pcall(updateMountCoupling)
	if not ok then
		logTickFailure("Falha ao ajustar o coupling na montaria", err)
	end
	local okLog, errLog = pcall(logMountStateChange)
	if not okLog then
		logTickFailure("Falha ao registrar a mudanca de montaria", errLog)
	end
	local okArms, errArms = pcall(logArmDiagnostics, delta)
	if not okArms then
		logTickFailure("Falha no diagnostico dos bracos", errArms)
	end
end, 20)

--------------------------------------------------------------------------
-- 1c. SÓ MONTADO (criatura): o tronco acompanha o headset
--
-- Na montaria o corpo não tem yaw próprio — ele herda a rotação da malha do
-- jogo, que aponta para onde a criatura aponta. Olhar para o lado deixava você
-- de perfil dentro do próprio corpo. Aqui o tronco gira para onde você olha,
-- com zona morta, sensibilidade e limite, sem NADA se mover: nem o jogador, nem
-- a criatura, nem a posição do corpo. É só a rotação de um osso.
--
-- POR QUE NA CINTURA E NÃO NO QUADRIL. As pernas penduram no quadril: girá-lo
-- levaria as duas junto e tiraria os pés do estribo. Girando o osso logo acima
-- dele — o primeiro da coluna — sobe tudo o que tem que subir (tronco, ombros,
-- braços, pescoço, cabeça) e as pernas ficam onde a animação as pôs. O efeito é
-- o mesmo que você descreveu; muda só onde a torção começa.
--
-- ENDIREITAR A COLUNA (09/08/2026). Do peito para cima a cópia está em pose de
-- referência, que é ereta — então a reclinada que aparece no hipogrifo NÃO vem
-- de osso nenhum. Ela vem da MALHA INTEIRA: montado, o corpo copia a rotação da
-- malha do jogo com pitch e roll inclusive (seção 4, "corpo copia a malha"), e
-- essa rotação é a do personagem sentado na criatura, deitado para trás. Como o
-- componente todo está inclinado, o tronco vertical dele sai inclinado junto.
--
-- Por isso o ajuste é feito AQUI, na cintura, e não na rotação do componente:
-- inclinar o componente de volta levaria as PERNAS junto e tiraria os pés do
-- estribo. Girando só a cintura, o tronco sobe e as pernas ficam onde a
-- animação as pôs — exatamente o mesmo motivo do giro de yaw.
--
-- A conta é fechada, não é perseguição: sabemos a rotação do componente (R_c) e
-- sabemos qual seria ela nivelada (mesmo yaw, pitch e roll zerados). A cintura
-- recebe a diferença entre as duas, convertida para o espaço do componente. Com
-- o controle em 0 a diferença é a identidade e NADA é escrito de diferente do
-- que já era escrito antes; em 1 a coluna fica na vertical do mundo.
--
-- A rotação é sempre calculada a partir da POSE DE REFERÊNCIA capturada na
-- criação, nunca do que está no osso: o osso guarda o que nós escrevemos no
-- frame anterior, e realimentar isso faria a torção crescer sozinha.
--
-- Prioridade 5 = depois das pernas (10) e antes do IK (0), para os braços serem
-- resolvidos já com o tronco na direção final.
--------------------------------------------------------------------------

local waistFName    = nil   -- primeiro osso da coluna (filho do quadril)
local waistRef      = nil   -- pose de referência dele, em números
local waistYawState = 0     -- torção já aplicada (suavizada)
local waistApplied  = false -- há uma torção escrita no osso agora?
local waistWarned   = false

local WAIST_LERP = 8.0

-- O endireitamento NÃO é suavizado de propósito: ele é uma função direta da
-- rotação da criatura, que já muda suave, e a câmera é compensada — então não
-- há degrau para amortecer. Um lerp aqui só atrasaria a correção e deixaria o
-- tronco balançando atrás da inclinação da montaria.

local function detectWaistBone(mesh)
	waistFName, waistRef, waistYawState, waistApplied = nil, nil, 0, false
	if uevrUtils.getValid(mesh) == nil or legAnchorFName == nil then return end
	if mesh.GetParentBone == nil or mesh.GetBoneTransformByName == nil then return end

	local names = uevrUtils.getBoneNames(mesh)
	if names == nil or #names == 0 then return end

	-- filho direto do quadril que não é perna: é a cintura. Entre candidatos
	-- vence o nome mais curto, que é sempre a raiz da coluna (Spine, e não
	-- Spine_twist_01 e afins).
	local isLeg = {}
	for _, bone in ipairs(legBones or {}) do isLeg[string.lower(bone.name)] = true end

	local hipName = legAnchorFName:to_string()
	local best = nil
	for _, name in ipairs(names) do
		if not isLeg[string.lower(name)] then
			local parent = mesh:GetParentBone(uevrUtils.fname_from_string(name))
			if parent ~= nil and parent:to_string() == hipName then
				if best == nil or #name < #best then best = name end
			end
		end
	end

	if best == nil then
		log("Não achei o osso da cintura — o tronco não vai acompanhar a visão na montaria", LogLevel.Warning)
		return
	end

	local fname = uevrUtils.fname_from_string(best)
	-- A cópia ainda está na pose de referência aqui (nasce com useDefaultPose e
	-- nada escreveu nela), então este é o único momento em que dá para ler a
	-- pose "neutra" da cintura.
	local transform = mesh:GetBoneTransformByName(fname, EBoneSpaces.ComponentSpace)
	local q = transform ~= nil and transform.Rotation or nil
	if transform == nil or transform.Translation == nil or q == nil or q.W == nil then
		log("Não consegui ler a pose da cintura ('" .. best .. "')", LogLevel.Warning)
		return
	end

	local rot = uevrUtils.rotatorFromQuat(q.X, q.Y, q.Z, q.W)
	local scale = transform.Scale3D
	waistFName = fname
	-- guardado em NÚMEROS: struct do motor devolvida por Get... é reaproveitada
	waistRef = {
		lx = transform.Translation.X, ly = transform.Translation.Y, lz = transform.Translation.Z,
		pitch = rot.Pitch, yaw = rot.Yaw, roll = rot.Roll,
		sx = scale ~= nil and scale.X or 1, sy = scale ~= nil and scale.Y or 1,
		sz = scale ~= nil and scale.Z or 1,
	}

	logMilestone("Cintura: '" .. best .. "' (acima de '" .. hipName .. "')")
end

-- Rotação que, aplicada na cintura, tira da coluna a inclinação que veio da
-- malha do jogo. Devolve nil quando não há nada a fazer — e nesse caso a escrita
-- da cintura fica exatamente como sempre foi.
--
-- A leitura é da MALHA DE ORIGEM e não da nossa cópia, de propósito. É a mesma
-- fonte que a seção 4 usa para posicionar o corpo, então as duas enxergam o
-- mesmo valor no mesmo quadro; ler de volta a rotação da nossa cópia seria ler
-- o que nós mesmos escrevemos (e a seção 4 escreve DEPOIS desta, no tick -10,
-- então viria de um quadro atrás).
local function computeSpineCorrection()
	local amount = configui.getValue("body_mountSpineUpright") or 0
	local trim   = configui.getValue("body_mountSpineTrim") or 0
	if amount <= 0 and trim == 0 then return nil end

	local source = getSourceMesh()
	if uevrUtils.getValid(source) == nil or source.K2_GetComponentRotation == nil then return nil end
	local srcRot = source:K2_GetComponentRotation()
	if srcRot == nil then return nil end

	amount = math.max(0, math.min(1, amount))
	local withRoll = configui.getValue("body_mountSpineRoll") ~= false

	-- para onde a rotação do componente vai ser puxada: mesmo yaw, pitch (e roll,
	-- se marcado) reduzidos pela fração escolhida. amount = 0 devolve a rotação
	-- original; amount = 1 deixa o tronco na vertical do mundo.
	local target = uevrUtils.rotator(
		srcRot.Pitch * (1 - amount),
		srcRot.Yaw,
		withRoll and (srcRot.Roll * (1 - amount)) or srcRot.Roll)

	-- Ajuste fino: uma inclinação a mais, medida no plano de quem está montado.
	-- Precisa ser em volta do eixo esquerda-direita DO PERSONAGEM, e o esqueleto
	-- não aponta para a frente do componente — daí o "Mesh Rotation Offset" do
	-- IK Dev Config, que é justamente a diferença entre um e outro. Tirando ele
	-- do yaw da malha sobra a direção para onde o personagem realmente olha.
	if trim ~= 0 then
		local rigYaw = 0
		if currentRig ~= nil and currentRig.meshRotationOffset ~= nil then
			rigYaw = currentRig.meshRotationOffset.Yaw or 0
		end
		local facingYaw = srcRot.Yaw - rigYaw
		-- desgira -> inclina em pitch (agora o pitch é o do personagem) -> gira de volta
		local lean = kismet_math_library:ComposeRotators(
			kismet_math_library:ComposeRotators(
				uevrUtils.rotator(0, -facingYaw, 0),
				uevrUtils.rotator(trim, 0, 0)),
			uevrUtils.rotator(0, facingYaw, 0))
		target = kismet_math_library:ComposeRotators(target, lean)
	end

	-- Diferença entre "como o componente deveria estar" e "como ele está".
	-- Transform em vez de rotator porque o inverso de um rotator não é o rotator
	-- negado — MakeTransform/InvertTransform/ComposeTransforms é o caminho que o
	-- resto deste arquivo já usa e que a lib garante.
	local one  = uevrUtils.vector(1, 1, 1)
	local zero = uevrUtils.vector(0, 0, 0)
	return kismet_math_library:ComposeTransforms(
		kismet_math_library:MakeTransform(zero, target, one),
		kismet_math_library:InvertTransform(
			kismet_math_library:MakeTransform(zero, uevrUtils.rotator(srcRot.Pitch, srcRot.Yaw, srcRot.Roll), one)))
end

-- Escreve a cintura. `correction` é o que computeSpineCorrection devolveu, ou nil.
--
-- A CABEÇA NÃO É TRATADA AQUI, e isso já foi tentado ao contrário. A primeira
-- versão (09/08/2026) reescrevia o osso da cabeça na posição que ele teria SEM a
-- correção, para a câmera não se mexer ao endireitar a coluna. O resultado em
-- jogo foi o oposto do que se queria: o pescoço esticava visivelmente (o Renan
-- descreveu como "chiclete") e a vista ficava descolada do corpo, porque a
-- coluna ia para a frente e a cabeça ficava para trás.
--
-- A cabeça é osso da coluna e tem de andar com ela. Quem quiser reposicionar a
-- vista usa o "Ajuste dos olhos", que é para isso.
local function writeWaist(yaw, correction)
	local rotation = uevrUtils.rotator(waistRef.pitch, waistRef.yaw, waistRef.roll)
	if yaw ~= 0 then
		rotation = kismet_math_library:ComposeRotators(rotation, uevrUtils.rotator(0, yaw, 0))
	end

	-- A translação é a da pose de referência MAIS o quanto o quadril saiu dela
	-- (hipShift). Escrever em espaço de componente é escrever posição absoluta
	-- dentro do esqueleto: sem essa soma, montado — onde o quadril é copiado
	-- inteiro — o tronco ficaria parado na pose de pé enquanto as pernas sentam,
	-- e o corpo se partiria na cintura.
	local lx = waistRef.lx + hipShift.X
	local ly = waistRef.ly + hipShift.Y
	local lz = waistRef.lz + hipShift.Z

	local transform = kismet_math_library:MakeTransform(
		uevrUtils.vector(lx, ly, lz),
		rotation,
		uevrUtils.vector(waistRef.sx, waistRef.sy, waistRef.sz))

	if correction ~= nil then
		-- A correção entra DEPOIS da rotação do osso, no espaço do componente.
		-- Composta só na rotação e remontada com a translação e a escala
		-- originais: assim é um giro puro em volta da junta da cintura, sem
		-- deslocar nada — que é o que mantém o tronco preso ao quadril.
		local rotated = kismet_math_library:ComposeTransforms(
			kismet_math_library:MakeTransform(uevrUtils.vector(0, 0, 0), rotation, uevrUtils.vector(1, 1, 1)),
			correction)
		local q = rotated ~= nil and rotated.Rotation or nil
		if q ~= nil and q.W ~= nil then
			transform = kismet_math_library:MakeTransform(
				uevrUtils.vector(lx, ly, lz),
				uevrUtils.rotatorFromQuat(q.X, q.Y, q.Z, q.W),
				uevrUtils.vector(waistRef.sx, waistRef.sy, waistRef.sz))
		end
	end

	for _, component in ipairs(bodyMeshes) do
		if uevrUtils.getValid(component) ~= nil and component.SetBoneTransformByName ~= nil then
			component:SetBoneTransformByName(waistFName, transform, EBoneSpaces.ComponentSpace)
		end
	end

end

-- Condições comuns às duas coisas que mexem na cintura (o giro atrás do headset
-- e o endireitar da coluna). O que separa uma da outra é decidido no tick: cada
-- uma tem o seu próprio controle no painel e uma pode estar ligada sem a outra.
local function waistControlActive()
	if waistFName == nil or waistRef == nil then return false end
	if not isEnabled() or currentRig == nil or #bodyMeshes == 0 then return false end
	if mounts.isWalking() then return false end
	-- vassoura fica de fora: lá a regra é não modificar nada
	if mounts.isOnBroom() then return false end
	if isBodyHidden() then return false end
	return true
end

local function updateWaistFollow(engine, delta)
	local active = waistControlActive()

	local correction = nil
	if active then
		local ok, result = pcall(computeSpineCorrection)
		if ok then correction = result end
	end

	local followYaw = active and configui.getValue("body_mountHipAlign") ~= false

	if not active or (not followYaw and correction == nil) then
		-- Desmontou (ou desligou tudo): devolve a cintura à pose de referência
		-- UMA vez. Sem isto o osso guardaria a última torção para sempre, porque
		-- a pé ninguém mais escreve nele. Em regime, a pé, isto não escreve nada.
		if waistApplied then
			waistApplied = false
			waistYawState = 0
			local ok = pcall(writeWaist, 0, nil)
			if not ok and not waistWarned then
				waistWarned = true
				logMilestone("Cintura: nao consegui devolver a pose de referencia")
			end
		end
		return
	end

	local target = 0
	if followYaw then
		local hmd = controllers.getController(2)
		local mesh = bodyMeshes[1]
		if uevrUtils.getValid(hmd) == nil or uevrUtils.getValid(mesh) == nil then return end

		local hmdRot = hmd:K2_GetComponentRotation()
		local bodyRot = mesh:K2_GetComponentRotation()
		if hmdRot == nil or bodyRot == nil then return end

		-- Montado, a rotação do corpo é a da malha do jogo (o "corpo copia a malha"
		-- escreve ela inteira), então o quanto você está torcido é simplesmente a
		-- diferença entre o headset e ela.
		local diff = uevrUtils.clampAngle180(hmdRot.Yaw - bodyRot.Yaw)

		local deadzone = configui.getValue("body_mountHipDeadzone") or 0
		if math.abs(diff) > deadzone then
			local sign = diff >= 0 and 1 or -1
			target = (diff - sign * deadzone) * (configui.getValue("body_mountHipSensitivity") or 0)
			local limit = configui.getValue("body_mountHipMaxYaw") or 60
			target = math.max(-limit, math.min(limit, target))
		end
	end

	if delta ~= nil and delta > 0 then
		waistYawState = waistYawState + (target - waistYawState) * math.min(1, WAIST_LERP * delta)
	else
		waistYawState = target
	end

	waistApplied = true
	writeWaist(waistYawState, correction)
end

uevrUtils.registerPreEngineTickCallback(function(engine, delta)
	local ok, err = pcall(updateWaistFollow, engine, delta)
	if not ok then
		log("Falha ao girar a cintura: " .. tostring(err), LogLevel.Warning)
	end
end, 5)

--------------------------------------------------------------------------
-- 2. Altura do corpo: agachar no jogo e agachar de verdade
--
-- Dois problemas diferentes com o mesmo sintoma — o corpo parece SUBIR quando
-- você abaixa.
--
-- (a) AGACHAR NO JOGO. O ik.lua tira a altura do corpo do CapsuleHalfHeight
--     (ik.lua:417: RelativeLocation.Z = off + (off + altura)), e a cápsula
--     encolhe ao agachar. O pawn também desce junto. Em vez de adivinhar
--     quanto vem de cada um — o que dependeria de como o motor trata
--     bCrouchMaintainsBaseLocation neste jogo —, medimos o resultado: a malha
--     de ORIGEM (Pawn.Mesh) é posicionada pelo próprio jogo e está sempre com
--     os pés no lugar certo. A distância entre a origem dela e a nossa é
--     constante enquanto está tudo bem; o que mudar nela é erro nosso, e é o
--     que devolvemos. Sem suposição nenhuma sobre a cápsula.
--
--     Isso mantém os PÉS plantados. Quem faz o corpo realmente agachar é a
--     cópia da translação do quadril, na seção 1.
--
-- (b) AGACHAR DE VERDADE, no espaço real. O "Corpo segue a posicao da cabeca"
--     sempre tratou só X e Y — o Z nunca seguiu o HMD (está escrito lá: "Só X
--     e Y"). Então o corpo continuava de pé enquanto você abaixava e o tronco
--     subia na sua frente. Agora o HMD abaixo da linha de referência desce o
--     corpo junto.
--
--     Isto NÃO é a "trava de cabeça" que fazia o corpo piscar. Aquela empurrava
--     o corpo até o osso da cabeça encostar no HMD a cada frame, realimentando
--     a própria medida — corpo move, medida muda, corpo move de novo. Aqui a
--     conta é aberta: HMD contra uma linha de referência fixa, capturada quando
--     o corpo nasce. Não lê nada que a gente mesmo escreveu, e só desce.
--------------------------------------------------------------------------

local function resetHeightCalibration()
	standingSourceHipZ = nil -- a linha do "em pé" do quadril (seção 1)
end

-- REMOVIDO: a correção que perseguia a malha do jogo.
--
-- Ela media `malhaDeOrigemZ - rootZ - ikZ` e devolvia ao corpo o que mudasse
-- nessa distância, para manter os pés plantados quando a cápsula encolhesse.
-- A premissa era que a malha de origem só se mexe em relação à cápsula quando
-- algo de fato mudou. É falsa: a UE desloca a malha em relação à cápsula para
-- suavizar degrau e subida, então o número oscila SOZINHO justamente ao subir.
-- Isso ia direto para a altura do corpo — e recalibrar só reposicionava a linha
-- de base, sem tirar a oscilação.
--
-- A altura do corpo volta a ser inteiramente do ik.lua, que é como estava antes
-- de eu mexer. Quem trata o agachamento é só a altura do quadril (seção 1), que
-- é medida em espaço de componente, dentro do esqueleto, e por isso não sabe
-- nem se importa com a altura do terreno.
--
-- 09/08/2026: a altura voltou a sair da malha do jogo, mas por outro caminho —
-- "Altura do corpo segue a malha do jogo", na seção 4. A diferença é toda entre
-- PERSEGUIR e ATRIBUIR: aqui media-se a diferença contra uma linha de base
-- capturada e devolvia-se a sobra por cima do valor do ik.lua (acumula, oscila,
-- descalibra); lá a altura simplesmente É a da malha, sem linha de base e sem
-- nada para acumular. O que este parágrafo continua condenando é a perseguição.

-- REMOVIDO (10/08/2026): o "agachar de verdade", que descia o corpo quando o HMD
-- baixava em relação a uma linha capturada na criação.
--
-- O comentário acima dizia que aquilo "não lê nada que a gente mesmo escreveu".
-- É FALSO, e foi o erro. O componente do HMD (`controllers.getController(2)`)
-- fica onde a VISTA está, e a vista é justamente o que a seção 3 escreve — com a
-- câmera atracada à cabeça, mexer no "Ajuste dos olhos" move o HMD junto.
--
-- Daí os dois sintomas: baixar os olhos baixava O PERSONAGEM (o HMD desceu, e
-- isso foi lido como agachamento), e o corpo PISCAVA entre duas alturas, porque
-- o laço fechava — corpo desce, cabeça desce, câmera desce, HMD desce, corpo
-- desce de novo.
--
-- É a mesma armadilha da "trava de cabeça" que já tinha sido removida antes por
-- fazer o corpo piscar. Não voltar por este caminho: qualquer medida do HMD que
-- alimente a altura do corpo realimenta a si mesma enquanto a câmera sair da
-- cabeça. Quem trata agachamento continua sendo a altura do quadril (seção 1),
-- medida em espaço de componente, dentro do esqueleto.

--------------------------------------------------------------------------
-- 3. Câmera atracada à cabeça do corpo
--
-- Por padrão a câmera deste perfil ORBITA o pawn: o main.lua:130 põe ela em
--     pawnPos + RotateAngleAxis(playerOffset(19,-3,70), yawDaVisão)
-- e sobra para o corpo correr atrás dela (é o que faz o "Corpo segue a posicao
-- da cabeca"). Este modo inverte a conta: a câmera passa a ficar NA CABEÇA do
-- corpo e o corpo fica parado em relação ao pawn. O pescoço fica sempre no
-- lugar certo debaixo da sua vista, sem perseguição e sem o vaivém da órbita.
--
-- A ROTAÇÃO não é tocada: continua vindo do headset, mais o yaw desacoplado que
-- o main.lua escreve em rotation.y. Mexemos só em position.
--
-- O deslocamento roomscale do HMD é somado pelo UEVR DEPOIS deste callback,
-- então andar e se inclinar no espaço real continuam funcionando: o que
-- mudamos é a base sobre a qual esse deslocamento é aplicado.
--
-- Ordem de registro importa: o main.lua registra o callback dele dentro do
-- UEVRReady, que roda durante o carregamento do script. Registrar o nosso aqui
-- no corpo do arquivo o colocaria ANTES na fila, e o do main.lua sobrescreveria
-- a nossa posição. Por isso o registro sai de um uevrUtils.delay — qualquer
-- callback de tick roda depois de todos os scripts terem carregado.
--------------------------------------------------------------------------

-- UM CASO SÓ (10/08/2026). A câmera vai ao osso da cabeça nos TRÊS EIXOS, a pé e
-- montado, sem ramo separado e sem nada guardado do tick.
--
-- Antes havia dois caminhos: montado o osso; a pé, horizontal do PAWN mais a
-- altura da cabeça. O X/Y do pawn era proteção contra deslize — com "corpo
-- acompanha a visão" o corpo tem giro próprio, o osso da cabeça fica fora desse
-- eixo, e usar o X/Y dele varria um arco quando o corpo virava. Isso já fez o
-- mundo deslizar aqui, com duas contribuições somadas: o osso fora do eixo e o
-- `mesh_location_offset` (X = -6.5 na época) girado junto.
--
-- O preço daquela proteção era a vista montado sentar alguns centímetros à
-- frente da vista a pé — dois pontos de vista diferentes para a mesma cabeça.
-- Com o offset hoje em ~[-2, -2], o arco que sobra é de poucos centímetros, e o
-- Renan preferiu a coerência: um comportamento só.
--
-- SE O MUNDO VOLTAR A DESLIZAR ao virar o corpo, é isto — e o suspeito é o X/Y
-- de `mesh_location_offset` ter crescido. Ele é o raio do arco.
local function headCameraActive()
	if not isEnabled() or currentRig == nil or #bodyMeshes == 0 then return false end
	if configui.getValue("body_headCamera") ~= true then return false end
	if configui.getValue("body_onlyArms") == true then return false end -- sem corpo, sem cabeça
	if isBodyHidden() then return false end
	return true
end

local function getHeadWorldLocation()
	local mesh = bodyMeshes[1]
	if uevrUtils.getValid(mesh) == nil or mesh.GetSocketLocation == nil then return nil end
	-- "Esconder a cabeca" encolhe o osso (SetBoneScaleByName), não o move: a
	-- posição continua valendo mesmo com a cabeça invisível.
	return mesh:GetSocketLocation(uevrUtils.fname_from_string(headBone))
end

--------------------------------------------------------------------------
-- JANELA DE 120° DO AJUSTE DOS OLHOS (10/08/2026)
--
-- Dois problemas do Renan, que têm a mesma raiz e por isso a mesma solução:
--
--   1. "quando mexo no X e no Y dos olhos, o olhar fica esquisito; quando eu
--      ando e viro, a configuração vira obsoleta";
--   2. "a cabeça pode ir pra frente 120 graus, 60 para cada lado; isso não deve
--      influenciar a inclinada pra trás".
--
-- A causa do (1): o X/Y era girado por `rotation.y`, ou seja, pela DIREÇÃO DO
-- OLHAR. Com X = 6, virar a cabeça faz a câmera percorrer um círculo de 6 cm em
-- volta do osso — e girar no analógico (yaw desacoplado) faz a mesma coisa sem
-- você mexer a cabeça de verdade. O mundo passa a girar em torno de um ponto
-- fora de você: é o "esquisito", e é por isso que o valor calibrado olhando
-- para um lado não serve para o outro.
--
-- Agora o X/Y é medido na FRENTE DO CORPO. Olhar em volta deixa de mover a
-- câmera, então a calibragem vale para qualquer direção.
--
-- E a janela: o empurrão para a frente só existe enquanto você olha dentro dos
-- 60° para cada lado. Dentro do MIOLO (45°) ele é cheio e constante — nada se
-- mexe, que é o ponto do item (1) —, e dos 45° aos 60° cai suavemente até zero.
-- A queda tem de ser suave: um corte seco seria a câmera saltando os 6 cm de
-- uma vez, no meio de um giro de cabeça.
--
-- Só o horizontal entra nessa conta. O Z (altura) fica intocado, e nada aqui
-- mexe em rotação — é isto o "não deve influenciar a inclinada pra trás".
--------------------------------------------------------------------------
local EYE_ARC_HALF = 60 -- meia janela; 120° no total, como pedido
local EYE_ARC_CORE = 45 -- até aqui o valor é cheio; daqui até a borda, cai a zero

local function normalizeYaw(angle)
	angle = angle % 360
	if angle > 180 then angle = angle - 360 end
	return angle
end

-- Para onde o CORPO aponta, em mundo.
--
-- Sai da rotação da própria cópia menos o "Mesh Rotation Offset" do rig, que é
-- justamente a diferença entre a frente do esqueleto e a frente do componente
-- (-88° neste perfil). Isso vale nos dois casos sem ramo nenhum: a pé nós
-- escrevemos `yawDoCorpo + offset`, e montado escrevemos a rotação da malha do
-- jogo, que carrega a mesma diferença por ser o mesmo esqueleto.
--
-- Ler a rotação de volta aqui é seguro e não é a armadilha documentada na seção
-- 4: aquilo era realimentar a lógica que ESCREVE a rotação. Aqui a leitura só
-- alimenta a câmera, e é feita dentro do callback, fresca, como a leitura do
-- osso da cabeça logo acima.
--
-- POR QUE NÃO DÁ PARA LER SÓ O `.Yaw` (10/08/2026). A pé o corpo está na
-- vertical e o Yaw do rotator é a direção, ponto. Montado não: a cópia recebe a
-- rotação da malha do jogo com pitch e roll grandes (na vassoura o personagem
-- fica quase deitado), e o Yaw de um rotator assim já não descreve para onde a
-- pessoa aponta — perto de 90° de pitch ele se confunde com o roll. Era essa a
-- razão de o ajuste "não alterar nada na vassoura": o ângulo saía fora da
-- janela de 120° e o fator dava zero.
--
-- A conta certa é vetorial e não sabe o que é gimbal: pegam-se os eixos do
-- componente EM MUNDO, combinam-se no ângulo do esqueleto (o Mesh Rotation
-- Offset é a diferença entre a frente do esqueleto e a do componente) e
-- projeta-se o resultado no plano do chão. Serve igual a pé, na vassoura e na
-- criatura.
local function getBodyForwardYaw()
	local mesh = bodyMeshes[1]
	if uevrUtils.getValid(mesh) == nil or mesh.K2_GetComponentRotation == nil then return nil end
	local rot = mesh:K2_GetComponentRotation()
	if rot == nil then return nil end

	local offsetYaw = 0
	if currentRig ~= nil and currentRig.meshRotationOffset ~= nil then
		offsetYaw = currentRig.meshRotationOffset.Yaw or 0
	end

	if kismet_math_library ~= nil and kismet_math_library.GetForwardVector ~= nil
		and kismet_math_library.GetRightVector ~= nil then
		local f = kismet_math_library:GetForwardVector(rot)
		local r = kismet_math_library:GetRightVector(rot)
		if f ~= nil and r ~= nil then
			-- girar o eixo X do componente em -offsetYaw em volta do "para cima"
			-- DELE: no plano do componente isso é cos(a)*frente + sen(a)*direita,
			-- com a = -offsetYaw. O yaw da UE cresce do X para o Y (a direita).
			local a = math.rad(-offsetYaw)
			local ca, sa = math.cos(a), math.sin(a)
			local vx = (f.X * ca) + (r.X * sa)
			local vy = (f.Y * ca) + (r.Y * sa)
			-- olhando reto para cima/baixo a projeção some; aí o valor antigo
			-- ainda é melhor que uma direção inventada
			if ((vx * vx) + (vy * vy)) > 0.0001 then
				return math.deg(math.atan(vy, vx))
			end
		end
	end

	return rot.Yaw - offsetYaw
end

-- 1 no miolo, 0 fora da janela, cosseno levantado no meio (sem degrau em
-- nenhuma das duas bordas).
local function eyeArcFactor(deltaYaw)
	local a = math.abs(normalizeYaw(deltaYaw))
	if a <= EYE_ARC_CORE then return 1 end
	if a >= EYE_ARC_HALF then return 0 end
	return 0.5 * (1 + math.cos(math.pi * (a - EYE_ARC_CORE) / (EYE_ARC_HALF - EYE_ARC_CORE)))
end

-- TUDO É LIDO AQUI, dentro do callback, no mesmo instante em que o main.lua lê
-- para a câmera dele. Nada é guardado no tick, e é isso que mantém a câmera em
-- dia — dois erros já pagos explicam por quê:
--
-- 1) NÃO guardar posição em MUNDO no tick. O callback da câmera roda DEPOIS do
--    tick do motor, ou seja, depois de o personagem já ter andado naquele
--    quadro. Uma posição calculada no tick chega atrasada, e o corpo — que já
--    está na posição nova — aparece adiantado em relação à câmera. O desvio é
--    velocidade x tempo de quadro: invisível parado, visível andando,
--    escancarado na vassoura. Lendo o osso aqui, o atraso não existe.
--
--    (Existiu aqui um meio-termo: guardar só a ALTURA relativa ao pawn, que não
--    envelhece. Funcionava, mas obrigava o X/Y a vir do pawn, e era essa a
--    origem da vista a pé e montado não baterem.)
--
-- 2) NÃO usar "view_index == 0" para identificar o primeiro olho. Este jogo é
--    UE4, e lá o índice vem do EStereoscopicPass: eSSP_LEFT_EYE = 1,
--    eSSP_RIGHT_EYE = 2 — nunca 0. Uma versão calculava a câmera só quando
--    view_index era 0, e a conta rodou uma única vez na vida: a câmera congelou
--    num ponto do mundo e o personagem saiu andando. Aqui não há teste de olho
--    nenhum — os dois recalculam e batem, porque leem o mesmo estado no quadro.
local function applyHeadCamera(position, rotation)
	if not headCameraActive() then return end

	-- É o osso da CÓPIA, e não o da malha do jogo: assim a câmera pega a cabeça
	-- que você realmente vê, já com tudo o que foi aplicado no corpo embutido na
	-- posição do osso.
	--
	-- Sem osso não escrevemos nada, e vale a câmera normal do perfil. Congelar a
	-- câmera num ponto do mundo seria bem pior.
	--
	-- Esconder a cabeça encolhe o osso (SetBoneScaleByName), não o move — a
	-- posição continua valendo com ela invisível.
	local head = getHeadWorldLocation()
	if head == nil then return end

	local x, y, z = head.X, head.Y, head.Z

	-- AJUSTE DOS OLHOS: onde os seus olhos ficam em relação ao osso da cabeça.
	-- O horizontal é medido na FRENTE DO CORPO e vale só dentro da janela de
	-- 120° — ver o bloco logo acima, que explica os dois porquês.
	--
	-- UM SÓ, PARA TUDO (decisão do Renan, reafirmada em 10/08/2026): a pé, na
	-- vassoura e na criatura. Existiu aqui, por algumas horas, um ajuste extra
	-- só para criatura — a ideia era compensar o fato de a cabeça da cópia não
	-- cair montado onde cai a pé (quadril na sela, tronco ereto, cintura girada
	-- pelo "Endireitar a coluna"). Foi REMOVIDO: o Renan quer um comportamento
	-- só, e dois campos para a mesma coisa é o defeito que já custou caro aqui
	-- (dois painéis gravando a posição do corpo). Se a vista montado incomodar,
	-- o lugar de mexer é a postura da cintura, que é o que desloca a cabeça.
	-- IGUAL EM TUDO: a pé, na vassoura e em criatura (10/08/2026, a pedido do
	-- Renan). Houve aqui, por pouco tempo, uma regra que desligava o horizontal
	-- montado — ela existia só para contornar a leitura errada da direção do
	-- corpo (o `.Yaw` de um rotator deitado), e some agora que o
	-- getBodyForwardYaw faz a conta vetorial. Um comportamento só, um campo só.
	--
	-- O empurrão é sempre HORIZONTAL (o vetor girado tem Z = 0), então nem aqui
	-- nem em lugar nenhum ele mexe na inclinação do corpo.
	local offset = configui.getValue("body_headCameraOffset")
	if offset ~= nil then
		local ox = offset.x or offset.X or 0
		local oy = offset.y or offset.Y or 0

		if ox ~= 0 or oy ~= 0 then
			-- Ficar sem corpo para referenciar não deveria acontecer (a câmera
			-- só está ligada com o corpo criado), mas se acontecer vale o
			-- comportamento antigo — direção do olhar, sem janela — em vez de
			-- perder o ajuste.
			local dirYaw, factor = rotation.y, 1
			local bodyYawNow = getBodyForwardYaw()
			if bodyYawNow ~= nil then
				dirYaw = bodyYawNow
				factor = eyeArcFactor(rotation.y - bodyYawNow)
			end

			if factor > 0 then
				local rotated = kismet_math_library:RotateAngleAxis(
					uevrUtils.vector(ox * factor, oy * factor, 0), dirYaw, uevrUtils.vector(0, 0, 1))
				x, y = x + rotated.X, y + rotated.Y
			end
		end

		-- altura sempre inteira: a janela é só do empurrão horizontal, e o Z
		-- vale a pé e montado
		z = z + (offset.z or offset.Z or 0)
	end

	position.x = x
	position.y = y
	position.z = z
end

local headCameraRegistered = false

local function registerHeadCamera()
	if headCameraRegistered then return end
	headCameraRegistered = true

	uevr.params.sdk.callbacks.on_early_calculate_stereo_view_offset(
		function(device, view_index, world_to_meters, position, rotation, is_double)
			-- pcall obrigatório: isto roda dentro do caminho da câmera, uma vez
			-- por olho. Um erro solto aqui derruba a renderização.
			local ok, err = pcall(applyHeadCamera, position, rotation)
			if not ok then
				log("Falha na camera da cabeca: " .. tostring(err), LogLevel.Warning)
			end
		end)

	logMilestone("Camera atracada a cabeca: callback registrado")
end

--------------------------------------------------------------------------
-- 4. Tronco acompanhando a visão
--
-- O corpo é filho do RootComponent do pawn, então ele gira com o PAWN. Só que
-- este perfil usa decoupled yaw: virar a cabeça não vira o pawn. O corpo ficava
-- para trás e dava o tranco quando o pawn finalmente alinhava.
--
-- No Silent Hill f isso não aparece porque lá o shf.lua zera o InputTurn e
-- mantém o pawn sempre alinhado com o HMD (não há yaw desacoplado). Como aqui o
-- yaw desacoplado é proposital, usamos o libs/body_yaw.lua da uevrlib, que é
-- feito para isto: gira o corpo em direção ao yaw do HMD com lerp e uma zona
-- morta, para giros pequenos de cabeça não arrastarem o corpo.
--------------------------------------------------------------------------

-- Por que a posição precisa ser recalculada todo frame:
--
-- A câmera deste perfil não fica no pawn. O main.lua:130 faz
--     camera = pawnPos + RotateAngleAxis(playerOffset(19,-3,70), yawDaVisão)
-- ou seja, ela ORBITA a origem do pawn num raio de ~19 cm. Virar 180° com yaw
-- desacoplado move a câmera uns 38 cm. O corpo, preso ao RootComponent com um
-- deslocamento fixo, não acompanhava essa órbita — daí ele aparecer mais para
-- frente ou mais para trás dependendo de para onde você estava olhando.
--
-- Em vez de repetir a fórmula do main.lua (que ainda depende do offset de
-- montaria), medimos direto onde o HMD está em relação ao pawn e usamos isso
-- como base horizontal do corpo. Isso cobre a órbita da câmera, o roomscale e
-- as montarias de uma vez só.
--
-- Só X e Y. O Z continua sendo do tick do ik.lua (prioridade 0, logo antes
-- desta função), que é o valor que você ajusta em "Posicao".

-- Para onde o corpo olha. É uma variável NOSSA e nunca é lida de volta do
-- componente — ler de volta era o caminho por onde o analógico virava o corpo:
--
-- o corpo é filho do RootComponent, e o jogo gira o pawn na direção do
-- movimento (empurrar o analógico para trás vira o personagem 180°). Essa
-- rotação acontece no tick do motor, que roda DEPOIS deste callback e arrasta
-- junto tudo que está preso ao root. No frame seguinte,
-- mesh:K2_GetComponentRotation().Yaw já vinha girado pelo pawn, o
-- bodyYaw.update lia aquilo como "o corpo está virado para lá" e ia atrás — o
-- corpo acabava seguindo a direção do analógico em vez da do headset.
--
-- Com o estado próprio, a direção do corpo depende só do HMD. O que o pawn faz
-- com a própria rotação deixa de importar, porque escrevemos a rotação em
-- mundo todo frame.
local bodyYawState = nil

local function updateBodyTransform(engine, delta)
	if not isEnabled() or currentRig == nil or #bodyMeshes == 0 then return end
	if isBodyHidden() then return end

	local followView = configui.getValue("body_followView") ~= false
	local followPosition = configui.getValue("body_followPosition") ~= false
	-- Não há mais saída antecipada com os dois desligados: a correção de altura
	-- da seção 2 vale sempre. Com os dois desligados, o X/Y calculado abaixo dá
	-- exatamente o meshLocationOffset, que é o que o ik.lua já tinha escrito.
	--
	-- SOMENTE BRAÇOS: os braços penduram na SUA cabeça, não no chão (10/08/2026).
	--
	-- O sintoma era "o braço está lá embaixo", e a causa está no ik.lua:624-633:
	-- para esconder o corpo ele encolhe o ESQUELETO — a raiz vai para escala
	-- 0,001 e só do ombro em diante volta a ser tamanho normal. Com a raiz
	-- encolhida, todos os ossos desabam para a ORIGEM DO COMPONENTE, e é dali
	-- que os ombros brotam. Só que a origem do componente está nos PÉS: o Z que
	-- o ik.lua escreve no tick (ik.lua:417) vale −capsula, porque foi calibrado
	-- com o corpo inteiro, para os pés encostarem no chão. Resultado: ombros na
	-- altura dos tornozelos e braços esticados para cima até os controles.
	--
	-- Sem tronco não existe "onde o corpo está": existe só onde os ombros têm de
	-- ficar, e isso é logo abaixo da sua cabeça. Então neste modo a posição toda
	-- (X, Y e Z) sai do HMD, e "Altura dos bracos" é a distância dos olhos até os
	-- ombros. É o mesmo efeito do `parent_type = 2` (prender ao HMD) que os
	-- perfis de braços usam, sem trocar o parentesco do componente nem mexer no
	-- caminho do corpo inteiro.
	--
	-- Não é realimentação como a "trava de cabeça" removida antes: aquilo lia o
	-- HMD com a câmera atracada à cabeça (a câmera movia o HMD, que movia o
	-- corpo, que movia a câmera). Aqui não há cabeça para a câmera atracar —
	-- headCameraActive() já devolve false com este modo ligado —, então o HMD é
	-- medida independente.
	local onlyArms = configui.getValue("body_onlyArms") == true

	local rootComponent = uevrUtils.getValid(pawn, {"RootComponent"})
	if rootComponent == nil then return end
	-- Montado, o `pawn` global é A CRIATURA, mas o corpo está preso ao
	-- RootComponent do PERSONAGEM (updateRigPawn / ik.setPawn) — e é contra esse
	-- pai que RelativeLocation é medido. Só "somente bracos" chega aqui montado;
	-- todo o resto sai no bloco logo abaixo, que escreve em MUNDO e não se
	-- importa com quem é o pai. A pé isto é um no-op: getMountPawn devolve o
	-- próprio pawn.
	if onlyArms and not mounts.isWalking() then
		local rigRoot = uevrUtils.getValid(mounts.getMountPawn(pawn), {"RootComponent"})
		if rigRoot ~= nil then rootComponent = rigRoot end
	end
	local mesh = bodyMeshes[1]
	if uevrUtils.getValid(mesh) == nil then return end

	--------------------------------------------------------------------------
	-- MONTARIA (vassoura, hipogrifo): o corpo copia a malha do jogo.
	--
	-- Todo o posicionamento normal daqui pressupõe alguém EM PÉ: X/Y vêm de um
	-- offset ajustado a pé, o Z sai da altura da cápsula, e a rotação é só de
	-- yaw — corpo sempre na vertical. Na vassoura nada disso vale: o jogo deita
	-- o personagem sobre ela e a vassoura inclina (pitch e roll), coisa que este
	-- código nem trata. Daí o corpo aparecer numa posição completamente
	-- diferente, em vez de em cima da vassoura.
	--
	-- Aqui a conta é abandonada e o corpo simplesmente vai para onde está a
	-- malha do jogo, com a rotação dela inteira — pitch e roll inclusive. É uma
	-- cópia de uma transform que o motor já calculou, não uma perseguição: não
	-- há erro para acumular.
	--
	-- Em MUNDO, e não em relativo, para não depender de a malha do jogo estar
	-- pendurada no mesmo pai que a nossa cópia — no hipogrifo o personagem passa
	-- a ser o RiderCharacter, que é outro ator.
	--------------------------------------------------------------------------
	-- Montado, "somente bracos" não entra aqui: copiar a malha do jogo é o que
	-- põe o TRONCO na sela, e neste modo não há tronco — só ombros, que
	-- continuam tendo de ficar debaixo da sua cabeça, montado ou a pé. Cair
	-- neste bloco deixaria os braços na altura dos pés do personagem sentado.
	if not mounts.isWalking() and not onlyArms then
		local source = getSourceMesh()
		if uevrUtils.getValid(source) ~= nil and source.K2_GetComponentLocation ~= nil then
			local srcLoc = source:K2_GetComponentLocation()
			local srcRot = source:K2_GetComponentRotation()
			if srcLoc ~= nil and srcRot ~= nil then
				-- Posição e rotação são as da malha do jogo, sem ajuste nenhum.
				--
				-- Existiu aqui um "Ajuste na montaria", e ele nunca foi
				-- calibragem: era compensação de um defeito. Enquanto o quadril
				-- ficava preso na altura de quem está DE PÉ (ver seção 1), o
				-- tronco flutuava acima da sela e o campo empurrava tudo 42 cm
				-- para baixo. A prova veio da vassoura, que já não usava o
				-- campo e estava certa, enquanto o hipogrifo, que usava, ficou
				-- baixo demais assim que o quadril passou a ser copiado inteiro.
				--
				-- Cópia e malha do jogo têm o mesmo esqueleto e a mesma origem,
				-- então copiar é o bastante — não há o que corrigir.
				for _, component in ipairs(bodyMeshes) do
					if uevrUtils.getValid(component) ~= nil and component.K2_SetWorldLocation ~= nil then
						component:K2_SetWorldLocation(
							uevrUtils.vector(srcLoc.X, srcLoc.Y, srcLoc.Z, true),
							false, reusable_hit_result, false)
						component:K2_SetWorldRotation(
							uevrUtils.rotator(srcRot.Pitch, srcRot.Yaw, srcRot.Roll),
							false, reusable_hit_result, false)
					end
				end

				-- o yaw livre do corpo perde o sentido montado; recomeça do pawn
				-- quando você desmontar
				bodyYawState = nil
				return
			end
		end
	end

	local hmd = controllers.getController(2)
	local pawnYaw = rootComponent:K2_GetComponentRotation().Yaw
	-- O offset de Yaw faz parte da rotação da malha, não da direção para onde o
	-- corpo "olha", então entra e sai da conta. Lido do rig (Mesh Rotation
	-- Offset, no IK Dev Config) e não de um campo daqui: havia um campo em cada
	-- painel gravando no mesmo parâmetro, cada um com a sua cópia salva, e o
	-- valor voltava sozinho.
	local meshYawOffset = 0
	if currentRig ~= nil and currentRig.meshRotationOffset ~= nil then
		meshYawOffset = currentRig.meshRotationOffset.Yaw or 0
	end

	-- 1) para onde o corpo olha
	local newYaw = pawnYaw
	if followView then
		if bodyYawState == nil then bodyYawState = pawnYaw end
		newYaw = bodyYawState
		if uevrUtils.getValid(hmd) ~= nil and delta ~= nil and delta > 0 then
			newYaw = bodyYaw.update(newYaw, hmd:K2_GetComponentRotation().Yaw, delta) or newYaw
		end
		bodyYawState = newYaw
	else
		-- desligado: o corpo volta a girar com o pawn, e na próxima vez que for
		-- ligado começa de onde o pawn estiver
		bodyYawState = nil
	end

	-- 2) posição horizontal: base embaixo do HMD + o ajuste do painel.
	-- O ajuste é medido no espaço do CORPO (X = para onde o corpo olha), então
	-- ele gira junto com o corpo; sem isso, "um pouco para trás" viraria "um
	-- pouco para frente" assim que você se virasse.
	local x, y = 0, 0
	local offset = currentRig.meshLocationOffset
	if offset ~= nil then
		local rotated = kismet_math_library:RotateAngleAxis(
			uevrUtils.vector(offset.X, offset.Y, 0), newYaw - pawnYaw, uevrUtils.vector(0, 0, 1))
		x, y = rotated.X, rotated.Y
	end

	-- "Somente bracos" mede tudo a partir do HMD, inclusive o ajuste do painel,
	-- que é medido no espaço do CORPO (X para onde o corpo olha) como todos os
	-- outros ajustes daqui — assim "um pouco para trás" continua sendo para trás
	-- depois de você se virar.
	local armsOffset = nil
	if onlyArms then
		local value = configui.getValue("body_armsOffset")
		if value ~= nil then
			local rotated = kismet_math_library:RotateAngleAxis(
				uevrUtils.vector(value.x or value.X or 0, value.y or value.Y or 0, 0),
				newYaw - pawnYaw, uevrUtils.vector(0, 0, 1))
			x, y = x + rotated.X, y + rotated.Y
			armsOffset = value.z or value.Z or 0
		else
			armsOffset = 0
		end
	end

	-- Com a câmera atracada à cabeça, quem se move é a câmera, não o corpo.
	-- Manter os dois ligados seria o corpo perseguir a câmera que persegue o
	-- corpo — realimentação. Então este modo tem prioridade.
	--
	-- Em "somente bracos" a base é sempre o HMD, com "Corpo segue a posicao da
	-- cabeca" ligado ou não: sem tronco nem pernas, ficar preso ao pawn deixaria
	-- os ombros de lado quando a câmera orbitasse (main.lua:130).
	local armsZ = nil
	if (onlyArms or (followPosition and not headCameraActive())) and uevrUtils.getValid(hmd) ~= nil then
		local hmdLoc = hmd:K2_GetComponentLocation()
		local rootLoc = rootComponent:K2_GetComponentLocation()
		-- diferença em mundo -> espaço do pawn, que é onde RelativeLocation vive
		local inPawnSpace = kismet_math_library:RotateAngleAxis(
			uevrUtils.vector(hmdLoc.X - rootLoc.X, hmdLoc.Y - rootLoc.Y, 0),
			-pawnYaw, uevrUtils.vector(0, 0, 1))
		x = x + inPawnSpace.X
		y = y + inPawnSpace.Y
		if armsOffset ~= nil then
			-- Altura relativa ao pawn, que é o espaço do RelativeLocation. Nada
			-- da conta da cápsula do ik.lua entra aqui: ela vale para o corpo
			-- inteiro, cujos pés precisam encostar no chão.
			armsZ = (hmdLoc.Z - rootLoc.Z) + armsOffset
		end
	end

	-- 3) altura (ver seção 2). Sobrou só o agachamento real, que vem desligado.
	-- O ik.lua reescreve RelativeLocation.Z no tick de prioridade 0, logo antes
	-- deste, então o valor lido abaixo é sempre o dele, limpo — a correção não
	-- se acumula de um frame para o outro.
	-- TENTATIVA REVERTIDA (09/08/2026): tirar a altura da malha do jogo em vez da
	-- cápsula (`z = srcLoc.Z - rootZ + offset.Z`). A conta em si estava certa e
	-- resolvia o corpo afundar ao agachar, MAS ela rebase o significado do Z de
	-- "Posicao" — o valor calibrado (-98.5, que é menos a altura da cápsula em
	-- pé) passa a valer ~0, e isso escancarou os corpos fantasmas.
	--
	-- A altura, aqui, é inteiramente do ik.lua: lemos o que ele acabou de
	-- escrever e devolvemos igual. NADA que venha do HMD entra nesta conta — ver
	-- o bloco "REMOVIDO" da seção 2.
	--
	-- ÚNICA EXCEÇÃO, "somente bracos" (armsZ): lá não há corpo para calibrar
	-- contra o chão, os ossos todos desabam na origem do componente e a conta da
	-- cápsula do ik.lua deixa de descrever qualquer coisa. A proibição de usar o
	-- HMD nasceu da realimentação com a câmera atracada à cabeça, e esse modo
	-- desliga a câmera na cabeça (headCameraActive), então o laço não existe.
	for _, component in ipairs(bodyMeshes) do
		if uevrUtils.getValid(component) ~= nil and component.K2_SetRelativeLocation ~= nil then
			local z = armsZ
			if z == nil then
				z = component.RelativeLocation ~= nil and component.RelativeLocation.Z or 0
			end
			component:K2_SetRelativeLocation(
				uevrUtils.vector(x, y, z, true), false, reusable_hit_result, false)
		end
	end

	-- Em "somente bracos" a rotação é escrita sempre: montado, o bloco que
	-- copiava a rotação da malha do jogo não roda mais (acima), e sem escrever
	-- nada aqui os ombros ficariam com a rotação que sobrou da criatura.
	if followView or onlyArms then
		local rotation = uevrUtils.rotator(0, newYaw + meshYawOffset, 0)
		for _, component in ipairs(bodyMeshes) do
			if uevrUtils.getValid(component) ~= nil and component.K2_SetWorldRotation ~= nil then
				component:K2_SetWorldRotation(rotation, false, reusable_hit_result, false)
			end
		end
	end
end

--------------------------------------------------------------------------
-- SOMENTE BRAÇOS: repor o corpo escondido depois que o ik.lua copia a pose
--
-- Neste modo o corpo não está escondido por visibilidade: o ik.lua ENCOLHE o
-- esqueleto (raiz em escala 0,001, ombros de volta a 1 — ik.lua:624-633). Ou
-- seja, o "esconder" mora na ESCALA DOS OSSOS, e há dois pontos do ik.lua que
-- reescrevem osso com escala junto:
--
--   * `animateFromMesh` (ik.lua:677) — `CopyPoseFromSkeletalComponent` copia a
--     pose INTEIRA da malha do jogo, que está em escala 1. O encolhimento some
--     e um corpo inteiro aparece pendurado na sua cabeça;
--   * `setInitialTransform` (ik.lua:440), no frame em que essa animação acaba —
--     `SetBoneTransformByName` leva a escala junto (é o mesmo motivo pelo qual
--     ele desfaz o "esconder a cabeça").
--
-- Quem liga isso é o montage: `is_hands_animating_from_mesh` (montage.lua:950)
-- responde por magia, gesto e objeto na mão, e enquanto responde `true` o
-- ik.lua nem chama os solvers (ik.lua:435). Se esse estado oscilar — e ele
-- oscila —, o resultado é o corpo aparecendo e sumindo, parado, sem nada mais
-- acontecendo.
--
-- A reposição é barata (quatro escalas por malha) e roda só nos frames em que
-- houve cópia de pose, mais UM depois, que é o do setInitialTransform.
local reapplyCount = 0
local wasAnimatingLast = false

local function reapplyHiddenBodyScales()
	if currentRig == nil or #bodyMeshes == 0 then return end
	if configui.getValue("body_onlyArms") ~= true then
		wasAnimatingLast = false
		return
	end

	local animating = currentRig.wasAnimating == true
	-- nada aconteceu neste frame nem no anterior
	if not animating and not wasAnimatingLast then return end
	wasAnimatingLast = animating

	if currentRig.updateBonesVisibility == nil then return end
	currentRig:updateBonesVisibility()
	-- a cabeça é escondida do mesmo jeito (escala do osso), então cai junto
	applyHeadVisibility()

	reapplyCount = reapplyCount + 1
	-- Marco no log, mas só nas primeiras vezes: se o pisca for isto, o log mostra
	-- a rajada; se não for, ficam duas linhas e pronto. Sem isso, um pisca a
	-- 90 Hz encheria o log.txt.
	if reapplyCount <= 5 then
		logMilestone("Somente bracos: pose do jogo copiada, corpo escondido reposto (" .. reapplyCount .. ")")
	end
end

-- Prioridade -10 = roda DEPOIS do tick do ik.lua, para a rotação final do corpo
-- ser a nossa. Continua no pré-tick: escrever transform no pós-tick foi o que
-- fez o corpo piscar da outra vez.
uevrUtils.registerPreEngineTickCallback(function(engine, delta)
	-- escalas primeiro: se o corpo acabou de voltar ao tamanho normal, os ossos
	-- que o posicionamento e os solvers usam já estão certos neste mesmo frame
	local okScale, errScale = pcall(reapplyHiddenBodyScales)
	if not okScale then
		logTickFailure("Falha ao repor o corpo escondido", errScale)
	end

	local ok, err = pcall(updateBodyTransform, engine, delta)
	if not ok then
		log("Falha ao posicionar o corpo: " .. tostring(err), LogLevel.Warning)
	end
end, -10)

--------------------------------------------------------------------------
-- Criação do rig
--------------------------------------------------------------------------

-- Reconstruir o corpo também reconstrói a varinha. Ela é presa na criação — ao
-- controle (connectToController) ou ao socket da mão (connectToSocket) — e esse
-- vínculo não sobrevive ao rig novo: a varinha fica para trás, presa a uma mão
-- que não existe mais.
--
-- Só DESCONECTAMOS. Quem reconecta é o poll do próprio main.lua (linha 1009:
-- "if isFP and not isWandDisabled and not isInCinematic and not
-- wand.isConnected() then connectWand()"), que roda a cada frame e já monta a
-- varinha no estado certo, com o corpo novo no lugar. Refazer a conexão daqui
-- duplicaria essa lógica e correria o risco de rodar antes do corpo existir.
--
-- pcall obrigatório: chamamos isto de dentro de callbacks e timers, e os timers
-- do uevr_utils rodam SEM proteção (uevr_utils:1123) — um erro aqui derrubaria
-- os outros timers do perfil no mesmo frame.
local function rebuildWand()
	if type(_G.disconnectWand) ~= "function" then return end
	local ok, err = pcall(_G.disconnectWand)
	if ok then
		log("Varinha desconectada para reconectar junto com o corpo")
	else
		log("Falha ao reconectar a varinha: " .. tostring(err), LogLevel.Warning)
	end
end

--------------------------------------------------------------------------
-- CORPOS FANTASMAS (09/08/2026)
--
-- Sintoma: dois corpos, e antes disso um "piscando" que era z-fighting entre
-- duas cópias no mesmo lugar. O log mostrava "Corpo criado com 8 malha(s)" sete
-- vezes em três minutos.
--
-- NÃO são dois rigs. Só existe um lugar no perfil inteiro que cria rig
-- (ik.lua:2530, dentro do tryAutoCreateArms) e ele é protegido por
-- `not M.exists()`. O que sobra é o outro lado: componente que não morre no
-- destroy. O `M.destroy` chama `uevrUtils.destroyComponent(mesh, true, true)`,
-- que destrói pelo dono (`actor:K2_DestroyComponent`) — e as nossas cópias são
-- criadas SEM parent (é o único jeito que não estoura exceção neste jogo, ver o
-- comentário da criação) e presas depois com K2_AttachTo. Quando essa destruição
-- não pega, a cópia velha fica no mundo, órfã: ninguém mais escreve a transform
-- dela e ela congela onde estava.
--
-- Como o rig é destruído e recriado com frequência (montar, desmontar, trocar
-- malha, e qualquer mudança de `parent_type` ou `hide_body`, que caem no
-- destroyAll do ik.lua:894 e :900), cada falha dessas empilha mais uma cópia.
--
-- Roda em dois momentos, e os dois são precisos:
--
--   * depois do nosso destroyAll (rebuild), quando nenhuma cópia legítima
--     deveria ter sobrado — ali `keep` é vazio e tudo que houver é lixo;
--   * na CRIAÇÃO do corpo novo, passando as malhas dele em `keep`. Este é o que
--     cobre os destroyAll que o próprio ik.lua dispara sozinho (ik.lua:894 e
--     :900, em `parent_type` e `hide_body = false`), que não passam por nós.
--
-- Comparar componente com `==` é confiável aqui: é o que o getSourceMesh já faz
-- para achar a malha de origem (`template.mesh == reference`).
--
-- Desce pela árvore porque montado a cópia não fica direto no root: com
-- coupling = 2 o ik.lua a pendura num SpringArm (ik.lua:556).
--
-- `destroyOwner = false`, sempre: o dono aqui é o PAWN.
--------------------------------------------------------------------------
-- Todas as cópias PoseableMesh penduradas no pawn, cada uma marcada com `mine`
-- (está em `keep`, ou seja, é do corpo de agora) ou não. A varredura é separada
-- da destruição porque o diagnóstico precisa LISTAR as duas coisas: uma cópia
-- órfã parada noutro lugar e uma briga de escrita dão o mesmo sintoma na tela
-- ("está em outra posição, piscando") e se distinguem exatamente aqui — se
-- houver mais de uma cópia, é fantasma; se houver só uma, é briga.
local function collectPoseableCopies(keep)
	local found = {}

	local rootComponent = uevrUtils.getValid(pawn, {"RootComponent"})
	if rootComponent == nil then return found end

	local poseableClass = uevrUtils.get_class("Class /Script/Engine.PoseableMeshComponent")
	if poseableClass == nil then return found end

	local isMine = {}
	for _, mesh in ipairs(keep or {}) do isMine[mesh] = true end

	local function collect(component, depth)
		if depth > 4 then return end
		local children = component.AttachChildren
		if children == nil then return end
		for i = 1, #children do
			local child = children[i]
			if uevrUtils.getValid(child) ~= nil then
				if child.is_a ~= nil and child:is_a(poseableClass) then
					table.insert(found, { component = child, mine = isMine[child] == true })
				end
				collect(child, depth + 1)
			end
		end
	end
	collect(rootComponent, 0)

	return found
end

local function destroyGhostBodies(keep)
	-- com o corpo desligado o perfil volta às mãos antigas, que também podem ser
	-- PoseableMesh — não é hora de varrer nada
	if not isEnabled() then return end

	local ghosts = {}
	for _, entry in ipairs(collectPoseableCopies(keep)) do
		if not entry.mine then table.insert(ghosts, entry.component) end
	end

	if #ghosts == 0 then return end
	for _, ghost in ipairs(ghosts) do
		pcall(uevrUtils.destroyComponent, ghost, false, true)
	end
	logMilestone("Corpos fantasmas removidos: " .. #ghosts)
end

local function rebuild()
	ik.destroyAll()
	-- o que sobrou de PoseableMesh no pawn agora é fantasma
	pcall(destroyGhostBodies)
	currentRig = nil
	bodyMeshes = {}
	bodyYawState = nil
	resetHeightCalibration()
	rebuildWand()
end

-- Aplica um parâmetro do rig e grava em data/ik_parameters.json.
--
-- Sem fila de espera: os únicos parâmetros que valia a pena enfileirar eram a
-- posição e a rotação da malha, e esses saíram daqui — quem manda neles é o
-- painel IK Dev Config. O que sobrou ("hide_body") não pode esperar mesmo,
-- porque desligá-lo faz o próprio módulo IK reconstruir o rig.
local function setRigParam(key, value)
	if currentRig ~= nil then
		currentRig:setConfigParameter(key, value, true)
	end
end

ik.registerOnMeshCreatedCallback(function(meshList, rig)
	currentRig = rig
	bodyMeshes = meshList or {}
	if #bodyMeshes == 0 then
		log("Nenhuma malha foi criada para o corpo", LogLevel.Warning)
		return
	end

	-- Limpa cópias que sobreviveram a algum destroy anterior. Aqui é o único
	-- ponto por onde passam TODOS os caminhos de criação, inclusive os que o
	-- ik.lua dispara sozinho — por isso a varredura mora nos dois lugares.
	pcall(destroyGhostBodies, bodyMeshes)

	-- Confere os nomes de osso contra a malha real. Se algum estava errado, os
	-- solvers deste rig já nasceram mortos: grava os corretos e reconstrói.
	-- Na reconstrução os nomes já batem, então isso acontece uma vez só.
	--
	-- MONTADO, NÃO. Esta detecção GRAVA em data/ik_parameters.json
	-- (setConfigParameter com persist = true). Se o corpo tiver nascido do
	-- esqueleto errado — e montado é justamente quando isso pode acontecer —, o
	-- que ela grava são os ossos da criatura por cima dos seus, junto com os
	-- offsets ajustados em jogo. Aconteceu em 06/08/2026: `wing_elbow_left`,
	-- `wing_wrist_right`, `wing_clavicle_left`. A pé, com o personagem certo em
	-- mãos, ela volta a rodar normalmente.
	if not mounts.isWalking() then
		rig.bodyBonesChecked = true
	end
	if configui.getValue("body_autoDetectBones") ~= false and not rig.bodyBonesChecked then
		rig.bodyBonesChecked = true
		if detectBones(rig, false) then
			log("Ossos corrigidos — reconstruindo o corpo")
			uevrUtils.delay(200, rebuild) -- fora do callback de criação
			return
		end
	end

	applyShadowSetting()
	applyHeadVisibility()
	keepSourceMeshesAnimating(rig)
	detectLegBones(bodyMeshes[1])
	-- o valor de fábrica do Z automático, para devolver ao desmontar (seção 1b)
	rigCoupling = rig.coupling or 1
	-- depois das pernas: a cintura é achada excluindo os ossos delas (seção 1c)
	detectWaistBone(bodyMeshes[1])
	detectDiagArmBones(bodyMeshes[1])

	-- reaproveita as poses de dedo do perfil nas mãos do corpo
	rig:setAnimationsFromHandsParametersFile(buildAnimationTable())
	rig:initHandAnimations(rig.meshTemplates)

	logMilestone("Corpo criado com " .. #bodyMeshes .. " malha(s)")

	-- e a varinha volta junto. Aqui cobre também os caminhos que não passam pelo
	-- botão "Reconstruir corpo": troca de malhas, redetecção de ossos e a
	-- criação automática no começo do nível.
	rebuildWand()
end)

ik.registerOnDestroyCallback(function()
	currentRig = nil
	bodyMeshes = {}
end)

--------------------------------------------------------------------------
-- As mãos antigas (presas aos controles) e o corpo não podem coexistir:
-- as duas usariam os mesmos IDs de animação e as mãos ficariam duplicadas.
--------------------------------------------------------------------------

-- Quem decide se as mãos existem é a variável global showHands, lida pelo
-- main.lua a cada poll. Mexemos direto nela e nas malhas, e repetimos de tempos
-- em tempos para o caso de algum outro caminho recriar as mãos. NÃO chamamos
-- configui.setValue("showHands", ...): isso dispara o onUpdate do main.lua, que
-- roda disconnectWand() + gesturesModule.reset() + disconnectHands(). Chamar
-- essas funções num momento arbitrário (tela de load, menu) pode dar erro, e um
-- erro aqui é grave: o uevr_utils executa os timers sem pcall (uevr_utils:1123),
-- então a exceção derruba os outros timers do perfil no mesmo frame.
-- Efeito colateral aceito: o checkbox "Show Hands" continua marcado na tela
-- mesmo com as mãos desligadas.
local function enforceHandsOff()
	if not isEnabled() then return end
	if configui.getValue("body_replaceHands") == false then return end

	if _G.showHands ~= false then
		_G.showHands = false
		log("'Show Hands' desligado — as mãos agora vêm do corpo")
	end

	if hands.exists() then
		log("Destruindo as mãos antigas presas aos controles")
		hands.destroyHands()
		hands.reset()
	end
end

-- Quando o corpo é desligado, devolve as mãos do perfil.
local function restoreHands()
	if _G.showHands == false then
		log("Religando 'Show Hands'")
		_G.showHands = true
	end
end

uevrUtils.setInterval(2000, function()
	local ok, err = pcall(enforceHandsOff)
	if not ok then
		log("Falha ao desligar as mãos: " .. tostring(err), LogLevel.Warning)
	end
end)

--------------------------------------------------------------------------
-- Refazer o corpo ao mexer no inventário (para a roupa nova aparecer)
--
-- REMOVIDO daqui o "Refazer o corpo ao montar e ao desmontar" (10/08/2026, a
-- pedido do Renan, depois de testado em jogo sem ele). O que segurava a
-- montaria não era a reconstrução e sim o que continua no arquivo: o
-- `updateRigPawn` (o ik.lua passa a ler raiz e cápsula do PERSONAGEM, não da
-- criatura), o `coupling = 2` e o giro/postura da cintura. O personagem montado
-- é o mesmo ator, com as mesmas malhas, então a cópia continua valendo.
--
-- O que entra no lugar: o corpo VR é uma CÓPIA das malhas do personagem, tirada
-- quando o rig nasce. Trocar de roupa no jogo troca as malhas do personagem, não
-- a cópia — a túnica nova aparecia em todo mundo menos em você. É o mesmo
-- problema que o perfil já tratava para as luvas (main.lua, no
-- `ExitFieldGuideWithReason`: "always updating hands here until we can find a
-- specific call for glove changes"), e a solução é a mesma: refazer o corpo
-- quando a tela de equipamento vai e volta.
--
-- SEM OPÇÃO NO PAINEL, a pedido do Renan.
--
-- A tela é reconhecida pelo UIManager do jogo, do mesmo jeito que o
-- `inMenuMode` do main.lua (main.lua:703): UI na tela + o widget do Guia de
-- Campo aberto na ABA 1, que é a do equipamento — a mesma que o main.lua já
-- trata à parte "so that the avatar appears" (main.lua:896). Com isso o corpo
-- não é refeito toda vez que você abre o mapa (aba 6) ou uma conversa.
--
-- Refaz nas DUAS bordas. Ao ENTRAR foi o pedido; ao SAIR é o que faz a coisa
-- funcionar, porque a roupa nova só existe depois de você trocá-la lá dentro.
-- Dentro do menu ninguém vê o corpo sumir, então o custo é zero.
--------------------------------------------------------------------------
local uiManagerCache = nil
local lastInGearScreen = false

local function isInGearScreen()
	if uevrUtils.getValid(uiManagerCache) == nil then
		uiManagerCache = uevrUtils.find_first_of("Class /Script/Phoenix.UIManager")
	end
	local uiManager = uevrUtils.getValid(uiManagerCache)
	if uiManager == nil then return false end
	if uiManager.GetIsUIShown == nil or uiManager:GetIsUIShown() ~= true then return false end

	local widget = uevrUtils.getValid(uiManager.FieldGuideWidget)
	if widget == nil then return false end
	return widget.CurrentTabIndex == 1
end

uevrUtils.setInterval(200, function()
	local ok, err = pcall(function()
		local inGear = isInGearScreen()
		if inGear == lastInGearScreen then return end
		lastInGearScreen = inGear

		-- corpo desligado ou ainda não criado: não há o que refazer, e o
		-- temporizador do ik.lua criaria um do zero de qualquer jeito
		if not isEnabled() or currentRig == nil then return end

		logMilestone(inGear and "Equipamento aberto: refazendo o corpo"
			or "Equipamento fechado: refazendo o corpo com a roupa nova")
		rebuild()
	end)
	if not ok then
		log("Falha ao refazer o corpo no inventario: " .. tostring(err), LogLevel.Warning)
	end
end)

--------------------------------------------------------------------------
-- Painel de configuração
--------------------------------------------------------------------------

-- "Ativar corpo VR" arrasta "Usar as maos do corpo" junto (10/08/2026).
--
-- As duas nunca foram independentes: as mãos do corpo são as mãos DO CORPO. Com
-- o corpo desligado, o checkbox continuava marcado enquanto o código já tinha
-- devolvido o Show Hands — o painel mostrava um estado que não existia, e
-- remarcar qualquer coisa ali podia deixar você sem mão nenhuma.
--
-- Agora o segundo checkbox acompanha o primeiro nos dois sentidos: desligar o
-- corpo desmarca "Usar as maos do corpo" (as mãos do perfil voltam), religar o
-- corpo marca de novo (as mãos voltam a ser as do corpo). O handler do
-- body_replaceHands é quem faz o restoreHands/enforceHandsOff, então aqui só
-- escrevemos o valor — o configui dispara o callback dele.
--
-- A ligação vale NOS DOIS SENTIDOS (o Renan pediu o segundo em 10/08/2026):
-- desmarcar "Usar as maos do corpo" desmarca "Ativar corpo VR" também. Faz
-- sentido pelo mesmo motivo: as mãos do corpo são a razão de o corpo estar
-- ligado neste perfil, então desligar uma coisa sem a outra deixava metade do
-- estado valendo.
--
-- Sem laço infinito, e sem depender do guarda de reentrância do configui
-- (que é por widget, configui:454): cada função só escreve quando o valor é
-- DIFERENTE do que já está lá, então a segunda volta da corrente para sozinha.
local function syncReplaceHands(enabled)
	if configui.getValue("body_replaceHands") == enabled then return end
	configui.setValue("body_replaceHands", enabled)
end

local function syncBodyEnabled(enabled)
	if configui.getValue("body_enabled") == enabled then return end
	configui.setValue("body_enabled", enabled)
end

configui.onCreateOrUpdate("body_enabled", function(value)
	ik.setAutoCreateArms(value == true)
	syncReplaceHands(value == true)
	if value ~= true then
		rebuild()
		restoreHands()
	else
		uevrUtils.delay(1000, enforceHandsOff)
	end
end)

configui.onCreateOrUpdate("body_replaceHands", function(value)
	syncBodyEnabled(value == true)
	if value == false then
		restoreHands()
	else
		uevrUtils.delay(1000, enforceHandsOff)
	end
end)

configui.onCreateOrUpdate("body_meshMode", function(value)
	if currentRig ~= nil then rebuild() end
end)

configui.onCreateOrUpdate("body_shadow", function(value)
	applyShadowSetting()
end)

configui.onCreateOrUpdate("body_followViewDeadzone", function(value)
	bodyYaw.setMinAngularDeviation(value)
end)

-- Os três abaixo usam onUpdate (e não onCreateOrUpdate) de propósito: quem manda
-- na posição do corpo é data/ik_parameters.json, lido pelo IK a cada criação.
-- O painel só grava por cima quando o jogador realmente mexe no controle.
configui.onUpdate("body_onlyArms", function(value)
	setRigParam("hide_body", value == true)

	-- DESMARCAR cai no `hide_body == false` do ik.lua:899, que chama destroyAll()
	-- e deixa o rig para o temporizador de 1 s recriar. É justamente o caminho
	-- que empilha cópia órfã (ver destroyGhostBodies), e desta vez a órfã fica
	-- num lugar bem diferente da viva — os braços deste modo ficam na cabeça, e
	-- a cópia velha congela onde estava.
	--
	-- A varredura espera o corpo novo existir: com `bodyMeshes` vazio, tudo o que
	-- estivesse pendurado no pawn seria considerado lixo, inclusive um rig
	-- recém-criado. Se ainda não houver corpo, não faz nada — a criação já varre
	-- sozinha (registerOnMeshCreatedCallback).
	uevrUtils.delay(1500, function()
		if currentRig == nil or #bodyMeshes == 0 then return end
		pcall(destroyGhostBodies, bodyMeshes)
	end)
end)

configui.onUpdate("body_rebuild", function()
	log("Reconstruindo o corpo")
	rebuild()
end)

-- Fique de pé, na altura em que você joga, e clique. As duas linhas de
-- referência da seção 2 são recapturadas no frame seguinte.
configui.onUpdate("body_recalibrate", function()
	resetHeightCalibration()
	logMilestone("Altura recalibrada")
end)

configui.onUpdate("body_detectBones", function()
	if currentRig == nil then
		log("Corpo não está criado", LogLevel.Warning)
		return
	end
	if detectBones(currentRig, true) then
		log("Ossos redetectados — reconstruindo o corpo")
		uevrUtils.delay(200, rebuild)
	else
		applyHeadVisibility()
	end
end)

-- Despeja no log.txt o estado que interessa quando a câmera ou a altura do
-- corpo estão erradas. Vai como Error de propósito (ver logMilestone): é para
-- ser lido depois, no arquivo.
local function logDiagnostics()
	local function fmt(v)
		if v == nil then return "nil" end
		return string.format("(%.1f, %.1f, %.1f)", v.X or v.x or 0, v.Y or v.y or 0, v.Z or v.z or 0)
	end

	logMilestone("--- diagnostico ---")
	logMilestone("corpo criado: " .. tostring(currentRig ~= nil) .. ", malhas: " .. #bodyMeshes
		.. ", escondido (filtrado): " .. tostring(isBodyHidden())
		.. ", escondido (cru): " .. tostring(shouldHideBody()))
	logMilestone("headCamera marcado: " .. tostring(configui.getValue("body_headCamera"))
		.. ", ativo agora: " .. tostring(headCameraActive()))
	logMilestone("montaria: tipo=" .. tostring(mounts.getMountType())
		.. ", voando=" .. tostring(mounts.getIsFlying()))

	-- SOMENTE BRAÇOS. Estas quatro linhas separam as três causas possíveis do
	-- "está noutra posição e pisca":
	--   * mais de uma cópia na lista  -> corpo fantasma (a órfã congela onde
	--     estava, e neste modo a viva fica na cabeça, bem longe dela);
	--   * coupling ~= 2               -> o ik.lua ainda está escrevendo o Z da
	--     cápsula por frame, disputando a posição com a gente;
	--   * reposições > 0              -> o jogo está copiando a pose por cima
	--     (montage), o que desfaz o encolhimento e mostra o corpo inteiro.
	logMilestone("somente bracos: " .. tostring(configui.getValue("body_onlyArms"))
		.. ", coupling=" .. tostring(currentRig ~= nil and currentRig.coupling or "?")
		.. ", animando pela malha=" .. tostring(currentRig ~= nil and currentRig.wasAnimating == true)
		.. ", reposicoes do corpo escondido=" .. reapplyCount)

	local copies = collectPoseableCopies(bodyMeshes)
	logMilestone("copias PoseableMesh no pawn: " .. #copies .. " (esperado: " .. #bodyMeshes .. ")")
	for _, entry in ipairs(copies) do
		local loc = entry.component.K2_GetComponentLocation ~= nil
			and entry.component:K2_GetComponentLocation() or nil
		logMilestone("  " .. (entry.mine and "[do corpo] " or "[FANTASMA] ")
			.. shortName(entry.component) .. " em " .. fmt(loc))
	end

	local rootComponent = uevrUtils.getValid(pawn, {"RootComponent"})
	if rootComponent ~= nil then
		logMilestone("pawn root: " .. fmt(rootComponent:K2_GetComponentLocation())
			.. ", CapsuleHalfHeight: " .. tostring(rootComponent.CapsuleHalfHeight))
	end

	local hmd = controllers.getController(2)
	if uevrUtils.getValid(hmd) ~= nil then
		logMilestone("HMD: " .. fmt(hmd:K2_GetComponentLocation()))
	end

	logMilestone("altura: quadril abaixado=" .. string.format("%.1f", hipDrop)
		.. ", deslocamento do quadril=" .. string.format("%.1f", hipShift.Z)
		.. ", quadril de pe (origem)=" .. (standingSourceHipZ and string.format("%.1f", standingSourceHipZ) or "nil")
		.. ", quadril na pose de referencia=" .. (referenceHip and string.format("%.1f", referenceHip.Z) or "nil"))

	local source = getSourceMesh()
	if uevrUtils.getValid(source) ~= nil then
		logMilestone("malha de origem no mundo: " .. fmt(source:K2_GetComponentLocation()))
		-- É desta rotação que sai a reclinada do tronco na montaria, e é ela que
		-- o "Endireitar a coluna" desfaz. Se o pitch e o roll aqui estiverem
		-- perto de zero enquanto o corpo aparece deitado, a inclinação vem de
		-- outro lugar e é o "Ajuste fino" que resolve, não o controle.
		local srcRot = source:K2_GetComponentRotation()
		if srcRot ~= nil then
			logMilestone(string.format(
				"rotacao da malha de origem: pitch=%.1f, yaw=%.1f, roll=%.1f",
				srcRot.Pitch, srcRot.Yaw, srcRot.Roll))
		end
	end

	logMilestone("coluna: endireitar=" .. tostring(configui.getValue("body_mountSpineUpright"))
		.. ", lateral=" .. tostring(configui.getValue("body_mountSpineRoll"))
		.. ", ajuste fino=" .. tostring(configui.getValue("body_mountSpineTrim"))
		.. ", corrigindo agora=" .. tostring(computeSpineCorrection() ~= nil))

	local mesh = bodyMeshes[1]
	if uevrUtils.getValid(mesh) ~= nil then
		logMilestone("corpo relativo: " .. fmt(mesh.RelativeLocation)
			.. ", mundo: " .. fmt(mesh:K2_GetComponentLocation()))

		-- Alturas lado a lado, para separar "o corpo está no lugar errado" de "há
		-- mais de um corpo". A malha do jogo é a referência de onde os pés do
		-- personagem realmente estão.
		if rootComponent ~= nil and uevrUtils.getValid(source) ~= nil then
			local srcLoc = source:K2_GetComponentLocation()
			local rootLoc = rootComponent:K2_GetComponentLocation()
			if srcLoc ~= nil and rootLoc ~= nil then
				logMilestone(string.format("altura: malha do jogo-root=%.1f, corpo-root=%.1f, Z de Posicao=%s",
					srcLoc.Z - rootLoc.Z,
					mesh:K2_GetComponentLocation().Z - rootLoc.Z,
					tostring(currentRig ~= nil and currentRig.meshLocationOffset ~= nil
						and currentRig.meshLocationOffset.Z or "?")))
			end
		end

		-- DOIS CORPOS. O ik.lua guarda os rigs numa LISTA (ik.lua:24) e o
		-- getCurrentMesh devolve o do ÚLTIMO criado; o body.lua rastreia o que
		-- veio no callback de criação. Se os dois não forem a MESMA malha, há
		-- mais de um rig vivo — e o que não é rastreado fica sendo posicionado
		-- só pela fórmula da cápsula do ik.lua, longe do outro.
		local ikMesh = ik.getCurrentMesh and ik.getCurrentMesh(1) or nil
		local ikName = uevrUtils.getValid(ikMesh) ~= nil and shortName(ikMesh) or "nil"
		logMilestone("rig rastreado x rig do ik.lua: " .. shortName(mesh) .. " / " .. ikName
			.. ", sao o mesmo: " .. tostring(ikMesh == mesh))
		logMilestone("osso da cabeca '" .. headBone .. "' no mundo: " .. fmt(getHeadWorldLocation()))

		-- Quadril: na malha de origem é a pose animada do jogo. Com "Corpo
		-- acompanha o agachamento" LIGADO os dois têm que bater (é o que a
		-- cópia da translação faz); DESLIGADO, a cópia fica na pose de
		-- referência e a diferença mostra o quanto o personagem agachou.
		if legAnchorFName ~= nil and currentRig ~= nil then
			if uevrUtils.getValid(source) ~= nil then
				local sourceHip = source:GetSocketTransform(legAnchorFName, RTS_COMPONENT)
				local targetHip = mesh:GetBoneTransformByName(legAnchorFName, EBoneSpaces.ComponentSpace)
				if sourceHip ~= nil and targetHip ~= nil then
					logMilestone("quadril (espaco de componente) origem: " .. fmt(sourceHip.Translation)
						.. ", copia: " .. fmt(targetHip.Translation))
				end
			end
		end
	end
	logMilestone("--- fim ---")
end

configui.onUpdate("body_diagnostics", function()
	local ok, err = pcall(logDiagnostics)
	if not ok then
		log("Falha no diagnostico: " .. tostring(err), LogLevel.Warning)
	end
end)

configui.onUpdate("body_logBones", function()
	local mesh = bodyMeshes[1]
	if uevrUtils.getValid(mesh) == nil then
		log("Corpo não está criado", LogLevel.Warning)
		return
	end
	animation.logBoneNames(mesh)
end)

configui.create({
	{
		panelLabel = "Corpo VR",
		saveFile = "config_body",
		layout = {
			{ widgetType = "text", label = "Corpo completo em primeira pessoa (tronco, bracos, maos, pernas e pes)." },
			{ widgetType = "spacing" },
			{ widgetType = "checkbox", id = "body_enabled", label = "Ativar corpo VR", initialValue = true },
			{ widgetType = "checkbox", id = "body_replaceHands", label = "Usar as maos do corpo (desliga Show Hands)", initialValue = true },
			{ widgetType = "checkbox", id = "body_shadow", label = "Corpo projeta sombra", initialValue = true },
			{ widgetType = "checkbox", id = "body_onlyArms", label = "Somente bracos (esconde tronco e pernas)", initialValue = false },
			{ widgetType = "text", label = "  Neste modo os ombros ficam presos a SUA cabeca: 'Posicao' e a altura da capsula" },
			{ widgetType = "text", label = "  nao valem (elas poem os pes no chao, e aqui nao ha pes). Calibre so o campo abaixo." },
			{
				widgetType = "drag_float3",
				id = "body_armsOffset",
				label = "  Altura dos bracos (X frente, Y direita, Z altura) — so em 'Somente bracos'",
				speed = 0.5,
				range = { -100, 100 },
				initialValue = { 0, 0, -25 },
			},
			{ widgetType = "text", label = "    Z e a distancia dos seus olhos ate os ombros; mais negativo desce os bracos." },
			{ widgetType = "spacing" },
			{
				widgetType = "checkbox",
				id = "body_animate",
				label = "Animar as pernas pelo jogo",
				initialValue = true,
			},
			{ widgetType = "text", label = "  So da cintura para baixo. Tronco, cabeca e dedos continuam como estavam." },
			{
				widgetType = "checkbox",
				id = "body_followCrouch",
				label = "Corpo acompanha o agachamento do jogo",
				initialValue = true,
			},
			{ widgetType = "text", label = "  Sem isso, agachar levanta os pes em vez de baixar o corpo." },
			{
				widgetType = "checkbox",
				id = "body_followPosition",
				label = "Corpo segue a posicao da cabeca",
				initialValue = true,
			},
			{ widgetType = "text", label = "  Sem isso o corpo fica preso ao pawn, e a camera deste perfil orbita o pawn." },
			{ widgetType = "spacing" },
			{
				widgetType = "checkbox",
				id = "body_headCamera",
				label = "Camera atracada a cabeca do corpo",
				initialValue = false,
			},
			{ widgetType = "text", label = "  A camera vai ate a cabeca em vez de o corpo ir atras da camera. Vale a pe e" },
			{ widgetType = "text", label = "  em toda montaria: montado ela vai direto ao osso da cabeca, sem ajuste." },
			{ widgetType = "text", label = "  A rotacao continua sendo do headset. Substitui o 'Corpo segue a posicao da cabeca'." },
			{
				widgetType = "drag_float3",
				id = "body_headCameraOffset",
				label = "  Ajuste dos olhos (X frente, Y direita, Z altura) — vale a pe e montado",
				speed = 0.5,
				range = { -100, 100 },
				initialValue = { 6, 0, 4 },
			},
			{ widgetType = "text", label = "    X e Y sao medidos na frente DO CORPO, nao na direcao do olhar: olhar em volta" },
			{ widgetType = "text", label = "    nao mexe mais a camera, entao o valor calibrado vale para qualquer direcao." },
			{ widgetType = "text", label = "    O empurrao para a frente so vale olhando dentro de 120 graus (60 para cada" },
			{ widgetType = "text", label = "    lado); dos 45 aos 60 ele cai suave ate zero." },
			{ widgetType = "text", label = "    Vale igual a pe, na vassoura e em criatura: a direcao do corpo e medida por" },
			{ widgetType = "text", label = "    vetor, entao a pose deitada da vassoura nao atrapalha mais a conta." },
			{
				widgetType = "checkbox",
				id = "body_followView",
				label = "Corpo acompanha a visao (giro)",
				initialValue = true,
			},
			{
				widgetType = "slider_int",
				id = "body_followViewDeadzone",
				label = "  Angulo para o corpo comecar a virar",
				speed = 1.0,
				range = { 1, 90 },
				initialValue = 40,
			},
			{
				widgetType = "combo",
				id = "body_meshMode",
				label = "Malhas",
				selections = { "Corpo + roupas", "Somente Pawn.Mesh" },
				initialValue = 1,
				width = 220,
			},
			{ widgetType = "spacing" },
			{ widgetType = "text", label = "Pernas: empurra coxa, canela, pe e dedos juntos (X frente, Y direita, Z altura)" },
			{
				widgetType = "drag_float3",
				id = "body_legOffset",
				label = "Ajuste das pernas",
				speed = 0.5,
				range = { -100, 100 },
				initialValue = { 0, 0, 0 },
			},
			{ widgetType = "spacing" },
			{ widgetType = "text", label = "Montado, o corpo copia a malha do jogo (posicao e rotacao, com pitch e roll)," },
			{ widgetType = "text", label = "sem ajuste nenhum e igual em vassoura e criatura." },
			{
				widgetType = "checkbox",
				id = "body_mountArmsIK",
				label = "  Na montaria, bracos pelo IK",
				initialValue = true,
			},
			{ widgetType = "text", label = "    O ik.lua reescreve a altura do corpo pela capsula do pawn todo frame, e no" },
			{ widgetType = "text", label = "    hipogrifo o pawn e A CRIATURA (capsula enorme): o alvo saia do alcance do braco" },
			{ widgetType = "text", label = "    e a mao congelava. Ligado, essa altura automatica fica quieta enquanto montado." },
			{
				widgetType = "checkbox",
				id = "body_mountHipAlign",
				label = "  Na montaria, tronco acompanha o headset (so criaturas)",
				initialValue = true,
			},
			{ widgetType = "text", label = "    Gira o osso da cintura, logo acima do quadril. Nada se move de lugar — nem voce," },
			{ widgetType = "text", label = "    nem a criatura, nem o corpo. As pernas ficam onde a animacao as pos. Vassoura nao entra." },
			{
				widgetType = "slider_float",
				id = "body_mountHipSensitivity",
				label = "    Sensibilidade",
				speed = 0.01,
				range = { 0, 1 },
				initialValue = 0.5,
			},
			{
				widgetType = "slider_int",
				id = "body_mountHipDeadzone",
				label = "    Angulo para comecar a girar",
				speed = 1.0,
				range = { 0, 60 },
				initialValue = 15,
			},
			{
				widgetType = "slider_int",
				id = "body_mountHipMaxYaw",
				label = "    Limite do giro (graus)",
				speed = 1.0,
				range = { 0, 90 },
				initialValue = 60,
			},
			{ widgetType = "spacing" },
			{ widgetType = "text", label = "  Postura na montaria (so criaturas; vassoura nao entra)" },
			{ widgetType = "text", label = "    Montado, o corpo copia a rotacao da malha do jogo inteira, e ela vem deitada" },
			{ widgetType = "text", label = "    para tras — e o tronco vai junto. Isto gira SO a cintura de volta, entao as" },
			{ widgetType = "text", label = "    pernas ficam onde a animacao as pos, nos estribos." },
			{
				widgetType = "slider_float",
				id = "body_mountSpineUpright",
				label = "    Endireitar a coluna",
				speed = 0.01,
				range = { 0, 1 },
				initialValue = 0,
			},
			{ widgetType = "text", label = "      0 = pose original do jogo.  1 = coluna na vertical do mundo." },
			{
				widgetType = "checkbox",
				id = "body_mountSpineRoll",
				label = "      Endireitar tambem a inclinacao lateral",
				initialValue = true,
			},
			{ widgetType = "text", label = "        Desligue para continuar deitando junto com a criatura nas curvas." },
			{
				widgetType = "slider_float",
				id = "body_mountSpineTrim",
				label = "    Ajuste fino (graus)",
				speed = 0.5,
				range = { -45, 45 },
				initialValue = 0,
			},
			{ widgetType = "text", label = "      Positivo deita para tras, negativo inclina para a frente. Vale sozinho," },
			{ widgetType = "text", label = "      mesmo com o controle de cima em 0." },
			{ widgetType = "text", label = "    A cabeca e osso da coluna e sobe junto, entao a camera sobe junto com ela." },
			{ widgetType = "text", label = "    Reposicione a vista pelo 'Ajuste dos olhos na montaria', mais acima." },
			{ widgetType = "spacing" },
			{
				widgetType = "checkbox",
				id = "body_autoDetectBones",
				label = "Detectar ossos automaticamente",
				initialValue = true,
			},
			{ widgetType = "text", label = "  Corrige nomes de osso que nao existem na malha. Nomes que ja funcionam nao sao alterados." },
			{ widgetType = "spacing" },
			{ widgetType = "button", id = "body_recalibrate", label = "Recalibrar altura" },
			{ widgetType = "same_line" },
			{ widgetType = "button", id = "body_rebuild", label = "Reconstruir corpo" },
			{ widgetType = "same_line" },
			{ widgetType = "button", id = "body_detectBones", label = "Detectar ossos agora" },
			{ widgetType = "same_line" },
			{ widgetType = "button", id = "body_logBones", label = "Listar ossos no log" },
			{ widgetType = "same_line" },
			{ widgetType = "button", id = "body_diagnostics", label = "Diagnostico no log" },
			{ widgetType = "spacing" },
			{ widgetType = "text", label = "Ajuste fino de bracos e maos: aba 'IK Dev Config'.", wrapped = true },
		},
	},
})

ik.init(SHOW_DEV_UI, LogLevel.Info)

-- O registro da câmera precisa acontecer depois que o main.lua registrou o
-- dele (ver a seção 2), e qualquer callback de tick já satisfaz isso: o
-- UEVRReady do main.lua roda durante o carregamento dos scripts, antes do
-- primeiro tick. O delay é só para não disputar o frame de inicialização.
uevrUtils.delay(2000, registerHeadCamera)

-- Se o perfil for carregado já dentro de um nível, o corpo é criado sozinho
-- pelo temporizador interno do módulo IK (1x por segundo, enquanto não existir).
uevrUtils.registerLevelChangeCallback(function()
	uevrUtils.delay(3000, applyHandsSetting)
	registerHeadCamera() -- protegido por flag: registra uma vez só
end)
